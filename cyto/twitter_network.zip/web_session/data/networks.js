var networks = {"twitter_network.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.8.0",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "twitter_network.csv",
    "name" : "twitter_network.csv",
    "SUID" : 61,
    "__Annotations" : [ "" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "936",
        "ClosenessCentrality" : 0.2884012539184953,
        "Eccentricity" : 4,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "genereaux2019",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "genereaux2019",
        "SelfLoops" : 0,
        "SUID" : 936,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 3.467391304347826,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1327.4759228839189,
        "y" : -3108.922070235719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "ClosenessCentrality" : 0.4008810572687225,
        "Eccentricity" : 3,
        "Outdegree" : 22,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 2730,
        "shared_name" : "HarleyRouda",
        "BetweennessCentrality" : 0.016440237028472325,
        "EdgeCount" : 23,
        "Indegree" : 1,
        "name" : "HarleyRouda",
        "SelfLoops" : 0,
        "SUID" : 935,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.4945054945054945,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.1304347826086956
      },
      "position" : {
        "x" : -1371.8154919757158,
        "y" : -3019.295178145875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "934",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "eqtr8er",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "eqtr8er",
        "SelfLoops" : 0,
        "SUID" : 934,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1261.398057283333,
        "y" : -3117.8823973841563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RedReader5252",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "RedReader5252",
        "SelfLoops" : 0,
        "SUID" : 933,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1540.8193524493486,
        "y" : -3001.7027709193126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "932",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "davidpsdem",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "davidpsdem",
        "SelfLoops" : 0,
        "SUID" : 932,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1486.0265362872392,
        "y" : -2951.4231993861094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SuMoh7",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SuMoh7",
        "SelfLoops" : 0,
        "SUID" : 931,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1248.931260408333,
        "y" : -2993.208965987672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "930",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "GVForsyth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "GVForsyth",
        "SelfLoops" : 0,
        "SUID" : 930,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1280.6167157305986,
        "y" : -2936.988079757203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "janggolan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "janggolan",
        "SelfLoops" : 0,
        "SUID" : 929,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1544.339738191536,
        "y" : -2939.3169676966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "928",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JuliaKGeorge",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JuliaKGeorge",
        "SelfLoops" : 0,
        "SUID" : 928,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1483.569688142708,
        "y" : -2883.8833739466563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HBnole",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HBnole",
        "SelfLoops" : 0,
        "SUID" : 927,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1338.7395032061845,
        "y" : -3168.950146407594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "926",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bjcrochet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bjcrochet",
        "SelfLoops" : 0,
        "SUID" : 926,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1363.8652203692704,
        "y" : -2916.006298751344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BetteKayOR",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BetteKayOR",
        "SelfLoops" : 0,
        "SUID" : 925,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1503.231095613411,
        "y" : -3059.8568236536876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "924",
        "ClosenessCentrality" : 0.5073529411764706,
        "Eccentricity" : 2,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 46092,
        "shared_name" : "All435Reps",
        "BetweennessCentrality" : 0.2775690128631305,
        "EdgeCount" : 4,
        "Indegree" : 2,
        "name" : "All435Reps",
        "SelfLoops" : 0,
        "SUID" : 924,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9710144927536233,
        "selected" : false,
        "NeighborhoodConnectivity" : 38.0
      },
      "position" : {
        "x" : -866.6469586505204,
        "y" : -2975.7486998743907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "333Cassandra",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "333Cassandra",
        "SelfLoops" : 0,
        "SUID" : 923,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1407.878800691536,
        "y" : -3120.444531173219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "922",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bloolee98",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bloolee98",
        "SelfLoops" : 0,
        "SUID" : 922,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1251.645730318001,
        "y" : -3055.297131270875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RichardLBond1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "RichardLBond1",
        "SelfLoops" : 0,
        "SUID" : 921,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1427.750382722786,
        "y" : -2926.153759688844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mitchellscomet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mitchellscomet",
        "SelfLoops" : 0,
        "SUID" : 920,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1565.6982281817704,
        "y" : -3060.852490157594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kristine_kenyon",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kristine_kenyon",
        "SelfLoops" : 0,
        "SUID" : 919,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1409.4499371661454,
        "y" : -3183.5445677943126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "918",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "travelingalexis",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "travelingalexis",
        "SelfLoops" : 0,
        "SUID" : 918,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1410.9213421954423,
        "y" : -2858.650158614625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HarleyVicQuinn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HarleyVicQuinn",
        "SelfLoops" : 0,
        "SUID" : 917,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1469.9943402423173,
        "y" : -3013.4102294154063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "916",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BKiddo0725",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BKiddo0725",
        "SelfLoops" : 0,
        "SUID" : 916,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1463.2165997638017,
        "y" : -3097.4134642786876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SocialCivility",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SocialCivility",
        "SelfLoops" : 0,
        "SUID" : 915,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1319.1263135089189,
        "y" : -2872.6285826868907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "socallance",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "socallance",
        "SelfLoops" : 0,
        "SUID" : 914,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1476.7807171954423,
        "y" : -3166.7117430872813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "marymredoutey",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "marymredoutey",
        "SelfLoops" : 0,
        "SUID" : 913,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -1530.5832074298173,
        "y" : -3122.3521239466563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "912",
        "ClosenessCentrality" : 0.494949494949495,
        "Eccentricity" : 4,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CarrieHKelly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 0,
        "name" : "CarrieHKelly",
        "SelfLoops" : 0,
        "SUID" : 912,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.020408163265306,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : 929.5487505779952,
        "y" : -2900.4558245844737
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "ClosenessCentrality" : 0.9400000000000001,
        "Eccentricity" : 3,
        "Outdegree" : 45,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 5029,
        "shared_name" : "OCDAToddSpitzer",
        "BetweennessCentrality" : 0.3581398661159379,
        "EdgeCount" : 46,
        "Indegree" : 1,
        "name" : "OCDAToddSpitzer",
        "SelfLoops" : 0,
        "SUID" : 911,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0638297872340425,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.065217391304348
      },
      "position" : {
        "x" : 760.6198260174483,
        "y" : -2626.0602233118907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "910",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "msicefan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "msicefan",
        "SelfLoops" : 0,
        "SUID" : 910,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.5
      },
      "position" : {
        "x" : 1086.1764513836592,
        "y" : -3144.978466720094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RigoReporting",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "RigoReporting",
        "SelfLoops" : 0,
        "SUID" : 909,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 761.2040850506514,
        "y" : -2823.194622725953
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "908",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rolandvanking",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rolandvanking",
        "SelfLoops" : 0,
        "SUID" : 908,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 671.6916949139327,
        "y" : -2676.9335143275157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "G2G_Wavey",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "G2G_Wavey",
        "SelfLoops" : 0,
        "SUID" : 907,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 636.6796099529952,
        "y" : -2791.789631576051
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "906",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TheDiegoOrtega",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TheDiegoOrtega",
        "SelfLoops" : 0,
        "SUID" : 906,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 820.8361956463546,
        "y" : -2751.2987487025157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "camanowa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "camanowa",
        "SelfLoops" : 0,
        "SUID" : 905,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 890.7817522869796,
        "y" : -2461.0257079310313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "904",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dlp59801",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dlp59801",
        "SelfLoops" : 0,
        "SUID" : 904,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 839.5798785076827,
        "y" : -2494.1436278529063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "1Marsha9988",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "1Marsha9988",
        "SelfLoops" : 0,
        "SUID" : 903,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 615.2032915936202,
        "y" : -2680.7969329066173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DianneMChilds03",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DianneMChilds03",
        "SelfLoops" : 0,
        "SUID" : 902,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 782.6639239178389,
        "y" : -2709.5032317347423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LindaClendennen",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LindaClendennen",
        "SelfLoops" : 0,
        "SUID" : 901,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 558.3152300701827,
        "y" : -2578.3151061243907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "900",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kelzmatelz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kelzmatelz",
        "SelfLoops" : 0,
        "SUID" : 900,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 735.3881365643233,
        "y" : -2525.757336349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hufco60",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "hufco60",
        "SelfLoops" : 0,
        "SUID" : 899,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 713.5886980877608,
        "y" : -2709.4259001917735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "898",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AmberP__",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AmberP__",
        "SelfLoops" : 0,
        "SUID" : 898,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 944.5382372723311,
        "y" : -2642.820111007203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TheGreatFeather",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TheGreatFeather",
        "SelfLoops" : 0,
        "SUID" : 897,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 793.6629473553389,
        "y" : -2527.690228194703
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LGKITTEN",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LGKITTEN",
        "SelfLoops" : 0,
        "SUID" : 896,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 881.6989886151046,
        "y" : -2771.6941954798594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MargotCult45n46",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MargotCult45n46",
        "SelfLoops" : 0,
        "SUID" : 895,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 559.0751177654952,
        "y" : -2690.6158415980235
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "894",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ASylvie7",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ASylvie7",
        "SelfLoops" : 0,
        "SUID" : 894,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 760.3093706951827,
        "y" : -2767.0611846156016
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ActualDM",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ActualDM",
        "SelfLoops" : 0,
        "SUID" : 893,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 557.0303179608077,
        "y" : -2633.839550704469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "892",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "robdetf",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "robdetf",
        "SelfLoops" : 0,
        "SUID" : 892,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 779.757216154167,
        "y" : -2414.916790694703
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LitlemissDotty",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LitlemissDotty",
        "SelfLoops" : 0,
        "SUID" : 891,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 841.8142229901046,
        "y" : -2645.066662520875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "partynxs",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "partynxs",
        "SelfLoops" : 0,
        "SUID" : 890,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 926.8097979412764,
        "y" : -2721.7699095911876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pjgirl74",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pjgirl74",
        "SelfLoops" : 0,
        "SUID" : 889,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 883.9774920330733,
        "y" : -2541.3184325404063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "888",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Nunya1230",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Nunya1230",
        "SelfLoops" : 0,
        "SUID" : 888,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 834.3090350018233,
        "y" : -2436.4088256068126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JaneneSimon10",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JaneneSimon10",
        "SelfLoops" : 0,
        "SUID" : 887,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 770.593641935417,
        "y" : -2471.2337462611094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "886",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EsmeOh96",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "EsmeOh96",
        "SelfLoops" : 0,
        "SUID" : 886,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 586.8015581951827,
        "y" : -2744.9108245081798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "socialpower",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "socialpower",
        "SelfLoops" : 0,
        "SUID" : 885,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 835.6641680584639,
        "y" : -2571.356487960328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "evelynj_45",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "evelynj_45",
        "SelfLoops" : 0,
        "SUID" : 884,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 694.4360186444014,
        "y" : -2819.448269576539
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "moby_c43",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "moby_c43",
        "SelfLoops" : 0,
        "SUID" : 883,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 610.3558184490889,
        "y" : -2470.9501158900157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "882",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "princessvivvian",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "princessvivvian",
        "SelfLoops" : 0,
        "SUID" : 882,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 698.7574908123702,
        "y" : -2765.288601607789
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "janicecampos_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "janicecampos_",
        "SelfLoops" : 0,
        "SUID" : 881,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 624.9551836834639,
        "y" : -2562.8771178431407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "880",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "alma49451161",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "alma49451161",
        "SelfLoops" : 0,
        "SUID" : 880,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 578.0618121014327,
        "y" : -2525.6172911829844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kristipuhl",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kristipuhl",
        "SelfLoops" : 0,
        "SUID" : 879,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 890.5083453045577,
        "y" : -2601.944561690797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MissinginCalif",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MissinginCalif",
        "SelfLoops" : 0,
        "SUID" : 878,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 822.7364031658858,
        "y" : -2808.1988188929454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "andreamontillaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "andreamontillaa",
        "SelfLoops" : 0,
        "SUID" : 877,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 720.3374468670577,
        "y" : -2421.3719908900157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "876",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "briannamariee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "briannamariee",
        "SelfLoops" : 0,
        "SUID" : 876,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 685.8479449139327,
        "y" : -2558.100353927125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DavidSM_24",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DavidSM_24",
        "SelfLoops" : 0,
        "SUID" : 875,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 927.2251726971358,
        "y" : -2512.690228194703
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "874",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "xrod99",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "xrod99",
        "SelfLoops" : 0,
        "SUID" : 874,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 645.7631670819014,
        "y" : -2736.2352416224376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "eneiraaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "eneiraaa",
        "SelfLoops" : 0,
        "SUID" : 873,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 612.5214678631514,
        "y" : -2617.8429076380626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.16666666666666666,
        "Stress" : 426,
        "shared_name" : "_BrittanyMun",
        "BetweennessCentrality" : 0.030337558752314482,
        "EdgeCount" : 3,
        "Indegree" : 2,
        "name" : "_BrittanyMun",
        "SelfLoops" : 0,
        "SUID" : 872,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 19.666666666666668
      },
      "position" : {
        "x" : 1043.099714933464,
        "y" : -2656.1143309779063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "maverickgangg",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "maverickgangg",
        "SelfLoops" : 0,
        "SUID" : 871,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 705.2742449627608,
        "y" : -2479.5377623743907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "870",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "92_kherrera",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "92_kherrera",
        "SelfLoops" : 0,
        "SUID" : 870,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 664.6337725506514,
        "y" : -2439.2737853236094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SantaAnaPD",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SantaAnaPD",
        "SelfLoops" : 0,
        "SUID" : 869,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 896.897352872917,
        "y" : -2668.968716353883
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "868",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "captaindaveyp",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "captaindaveyp",
        "SelfLoops" : 0,
        "SUID" : 868,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 672.3491045819014,
        "y" : -2614.4488646693126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ABC7JulieSone",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ABC7JulieSone",
        "SelfLoops" : 0,
        "SUID" : 867,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 860.1455828533858,
        "y" : -2710.9539763636485
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BrittneyMB21",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BrittneyMB21",
        "SelfLoops" : 0,
        "SUID" : 866,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 650.6198565350264,
        "y" : -2511.0200926966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "WaymakersOC",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "WaymakersOC",
        "SelfLoops" : 0,
        "SUID" : 865,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 949.4476763592452,
        "y" : -2577.763653487672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "864",
        "ClosenessCentrality" : 0.2916666666666667,
        "Eccentricity" : 5,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "megagamer5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "megagamer5",
        "SelfLoops" : 0,
        "SUID" : 864,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 3.4285714285714284,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 1281.355345426628,
        "y" : -3283.7235228724376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "ClosenessCentrality" : 0.39705882352941174,
        "Eccentricity" : 4,
        "Outdegree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 1026,
        "shared_name" : "cityofbrea",
        "BetweennessCentrality" : 0.07306651474148981,
        "EdgeCount" : 9,
        "Indegree" : 1,
        "name" : "cityofbrea",
        "SelfLoops" : 0,
        "SUID" : 863,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.5185185185185186,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.3333333333333333
      },
      "position" : {
        "x" : 1254.275210081169,
        "y" : -3388.1614501185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "862",
        "ClosenessCentrality" : 0.46341463414634143,
        "Eccentricity" : 3,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 1425,
        "shared_name" : "EvanCarey86",
        "BetweennessCentrality" : 0.10148127047429141,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "EvanCarey86",
        "SelfLoops" : 0,
        "SUID" : 862,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.1578947368421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : 1108.4485995159835,
        "y" : -3405.807171554078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BreaPD",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BreaPD",
        "SelfLoops" : 0,
        "SUID" : 861,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 1348.1515337811202,
        "y" : -3470.8507201380626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ARobertSilva",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ARobertSilva",
        "SelfLoops" : 0,
        "SUID" : 860,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 1361.7185656414717,
        "y" : -3333.1056029505626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BreaEM",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BreaEM",
        "SelfLoops" : 0,
        "SUID" : 859,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 1385.3230883465499,
        "y" : -3409.203839034547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "858",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sarno456",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sarno456",
        "SelfLoops" : 0,
        "SUID" : 858,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 1207.4950472698897,
        "y" : -3499.1758544154063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "milfvolcom",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "milfvolcom",
        "SelfLoops" : 0,
        "SUID" : 857,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : 1284.999403654167,
        "y" : -3514.4407469935313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "856",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "davidmartinson",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "davidmartinson",
        "SelfLoops" : 0,
        "SUID" : 856,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.5
      },
      "position" : {
        "x" : 1412.4868761883467,
        "y" : -3565.703808516969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "ClosenessCentrality" : 0.8181818181818181,
        "Eccentricity" : 2,
        "Outdegree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.003676470588235294,
        "Stress" : 5346,
        "shared_name" : "City_of_Irvine",
        "BetweennessCentrality" : 0.3807149978635522,
        "EdgeCount" : 17,
        "Indegree" : 3,
        "name" : "City_of_Irvine",
        "SelfLoops" : 0,
        "SUID" : 855,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.2222222222222223,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.5294117647058822
      },
      "position" : {
        "x" : 944.6285998211592,
        "y" : -3409.721478194703
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "854",
        "ClosenessCentrality" : 0.504,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "00sh4a_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "00sh4a_",
        "SelfLoops" : 0,
        "SUID" : 854,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9841269841269842,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2304.702498136589,
        "y" : -3482.504833907594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 62,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 558,
        "shared_name" : "ClickThatFollow",
        "BetweennessCentrality" : 0.14285714285714285,
        "EdgeCount" : 63,
        "Indegree" : 1,
        "name" : "ClickThatFollow",
        "SelfLoops" : 0,
        "SUID" : 853,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : 2325.584578214714,
        "y" : -3721.6695677943126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "852",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DujjAT",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DujjAT",
        "SelfLoops" : 0,
        "SUID" : 852,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2439.566481290886,
        "y" : -3795.805615157594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Boyingtonfr",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Boyingtonfr",
        "SelfLoops" : 0,
        "SUID" : 851,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2215.96598690612,
        "y" : -3511.5416075892344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "850",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "genuineyes",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "genuineyes",
        "SelfLoops" : 0,
        "SUID" : 850,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2101.954207120964,
        "y" : -3649.043225020875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Am_muhairi",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Am_muhairi",
        "SelfLoops" : 0,
        "SUID" : 849,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2413.1515948162764,
        "y" : -3727.95606681775
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pakmee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pakmee",
        "SelfLoops" : 0,
        "SUID" : 848,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2331.96794003112,
        "y" : -3806.765148849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "favvvvma",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "favvvvma",
        "SelfLoops" : 0,
        "SUID" : 847,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2279.55778378112,
        "y" : -3836.9891478724376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "846",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sayhello",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sayhello",
        "SelfLoops" : 0,
        "SUID" : 846,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2219.950117765495,
        "y" : -3924.9810301966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JacksBurner",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JacksBurner",
        "SelfLoops" : 0,
        "SUID" : 845,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2436.712996183464,
        "y" : -3569.1625182337657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "844",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "3abm_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "3abm_",
        "SelfLoops" : 0,
        "SUID" : 844,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2271.0908038006514,
        "y" : -3891.7901122279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "zezoghandurah",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "zezoghandurah",
        "SelfLoops" : 0,
        "SUID" : 843,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2339.8010088787764,
        "y" : -3585.563214034547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Yasminmn_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Yasminmn_",
        "SelfLoops" : 0,
        "SUID" : 842,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2486.9738299236983,
        "y" : -3890.7510497279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ChubberGuard",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ChubberGuard",
        "SelfLoops" : 0,
        "SUID" : 841,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2474.0566241131514,
        "y" : -3835.4407469935313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "840",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "abdulrhmanmas",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "abdulrhmanmas",
        "SelfLoops" : 0,
        "SUID" : 840,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2388.88639706237,
        "y" : -3841.606701583375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "7omoudrajab",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "7omoudrajab",
        "SelfLoops" : 0,
        "SUID" : 839,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2541.690321622917,
        "y" : -3632.536633224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "838",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "danielford77",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "danielford77",
        "SelfLoops" : 0,
        "SUID" : 838,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2432.64030331237,
        "y" : -3871.5962035365
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "spaekman",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "spaekman",
        "SelfLoops" : 0,
        "SUID" : 837,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2234.058211027214,
        "y" : -3701.548535079469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ChadDavis_1992",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ChadDavis_1992",
        "SelfLoops" : 0,
        "SUID" : 836,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2216.8882281170577,
        "y" : -3745.6981322474376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "thisiskwangg",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "thisiskwangg",
        "SelfLoops" : 0,
        "SUID" : 835,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2224.942976652214,
        "y" : -3863.637402266969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "834",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "0llyMelancholy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "0llyMelancholy",
        "SelfLoops" : 0,
        "SUID" : 834,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2169.0915972576827,
        "y" : -3890.6099974818126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BluePicker90",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BluePicker90",
        "SelfLoops" : 0,
        "SUID" : 833,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2209.926680265495,
        "y" : -3631.293896407594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "832",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "vjradiance",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "vjradiance",
        "SelfLoops" : 0,
        "SUID" : 832,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2500.416151701042,
        "y" : -3571.327099532594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "geryfesalvo",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "geryfesalvo",
        "SelfLoops" : 0,
        "SUID" : 831,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2356.570418058464,
        "y" : -3956.3765380091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "830",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Aaron_____Davis",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Aaron_____Davis",
        "SelfLoops" : 0,
        "SUID" : 830,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2460.4741350994796,
        "y" : -3746.9085814661876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Christo50881821",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Christo50881821",
        "SelfLoops" : 0,
        "SUID" : 829,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2329.72672909362,
        "y" : -3640.0477721400157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "828",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "maggiejuang1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "maggiejuang1",
        "SelfLoops" : 0,
        "SUID" : 828,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2181.6996905194014,
        "y" : -3671.040539474
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rf_hypatia",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "rf_hypatia",
        "SelfLoops" : 0,
        "SUID" : 827,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2235.462019620964,
        "y" : -3587.9452025599376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "826",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JoshHoltz7",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JoshHoltz7",
        "SelfLoops" : 0,
        "SUID" : 826,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2188.8325640545577,
        "y" : -3585.191448897828
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bebi_lovely",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bebi_lovely",
        "SelfLoops" : 0,
        "SUID" : 825,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2177.556990324089,
        "y" : -3772.296093673219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "PattyWitrado",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "PattyWitrado",
        "SelfLoops" : 0,
        "SUID" : 824,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2363.27018612487,
        "y" : -3498.945599288453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Scrrubsss",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Scrrubsss",
        "SelfLoops" : 0,
        "SUID" : 823,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2553.775221525261,
        "y" : -3697.8333861536876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "822",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Xarathos",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Xarathos",
        "SelfLoops" : 0,
        "SUID" : 822,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2333.98405331237,
        "y" : -3862.003124923219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "divinestride",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "divinestride",
        "SelfLoops" : 0,
        "SUID" : 821,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2158.073652921745,
        "y" : -3721.6975829310313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "820",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cryptoyogi108",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "cryptoyogi108",
        "SelfLoops" : 0,
        "SUID" : 820,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2428.9727007733077,
        "y" : -3624.051068038453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KarylynParsons",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KarylynParsons",
        "SelfLoops" : 0,
        "SUID" : 819,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2312.2287432537764,
        "y" : -3541.001263350953
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "818",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DemetriusDjc",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DemetriusDjc",
        "SelfLoops" : 0,
        "SUID" : 818,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2500.5061480389327,
        "y" : -3675.0103270716563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hapapanda_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "hapapanda_",
        "SelfLoops" : 0,
        "SUID" : 817,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2127.1960894451827,
        "y" : -3787.764599532594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "816",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "NishaniAlways",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "NishaniAlways",
        "SelfLoops" : 0,
        "SUID" : 816,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2504.701246915886,
        "y" : -3785.183361739625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TammyBl06054784",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TammyBl06054784",
        "SelfLoops" : 0,
        "SUID" : 815,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2533.7848650799483,
        "y" : -3833.6531493372813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "814",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ArayAromaz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ArayAromaz",
        "SelfLoops" : 0,
        "SUID" : 814,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2556.180769620964,
        "y" : -3759.2083251185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "godzillo_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "godzillo_",
        "SelfLoops" : 0,
        "SUID" : 813,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2286.657087980339,
        "y" : -3598.355267257203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FromTheShadow16",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FromTheShadow16",
        "SelfLoops" : 0,
        "SUID" : 812,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2379.722548185417,
        "y" : -3900.6346556849376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "schristine2315",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "schristine2315",
        "SelfLoops" : 0,
        "SUID" : 811,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2229.1985308514327,
        "y" : -3804.792492599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "810",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ArnesonGuides",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ArnesonGuides",
        "SelfLoops" : 0,
        "SUID" : 810,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2095.02262753112,
        "y" : -3744.16993400525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LcvPw",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LcvPw",
        "SelfLoops" : 0,
        "SUID" : 809,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2272.92350643737,
        "y" : -3774.805126876344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "808",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FbayareaS",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FbayareaS",
        "SelfLoops" : 0,
        "SUID" : 808,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2279.8830401287764,
        "y" : -3952.1517455286876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "danielwhelan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "danielwhelan",
        "SelfLoops" : 0,
        "SUID" : 807,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2180.360701261589,
        "y" : -3829.458264083375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rogerma46478074",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rogerma46478074",
        "SelfLoops" : 0,
        "SUID" : 806,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2150.947615324089,
        "y" : -3557.248974532594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "spmarx",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "spmarx",
        "SelfLoops" : 0,
        "SUID" : 805,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2388.8991228924483,
        "y" : -3785.7742430872813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "804",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MantraToday",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MantraToday",
        "SelfLoops" : 0,
        "SUID" : 804,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2111.92741268737,
        "y" : -3696.796581954469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "yangabbard",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "yangabbard",
        "SelfLoops" : 0,
        "SUID" : 803,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2125.037459074089,
        "y" : -3843.728283614625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "802",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Chandlergt",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Chandlergt",
        "SelfLoops" : 0,
        "SUID" : 802,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2386.5468279705733,
        "y" : -3592.2103392786876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HankAnd96259025",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HankAnd96259025",
        "SelfLoops" : 0,
        "SUID" : 801,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2264.0076128826827,
        "y" : -3535.6387450404063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "326kanav",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "326kanav",
        "SelfLoops" : 0,
        "SUID" : 800,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2446.0717608319014,
        "y" : -3519.773968429078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ToroDelMar1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ToroDelMar1",
        "SelfLoops" : 0,
        "SUID" : 799,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2322.48258846862,
        "y" : -3912.763867110719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "798",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Hebrewsaurusre1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Hebrewsaurusre1",
        "SelfLoops" : 0,
        "SUID" : 798,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2259.4121538983077,
        "y" : -3655.267529220094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "vanguardreview",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "vanguardreview",
        "SelfLoops" : 0,
        "SUID" : 797,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2480.7848955975264,
        "y" : -3622.468792647828
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "796",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "badjulio",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "badjulio",
        "SelfLoops" : 0,
        "SUID" : 796,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2443.8249956951827,
        "y" : -3677.6888549036876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "austinm419",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "austinm419",
        "SelfLoops" : 0,
        "SUID" : 795,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2429.448836027214,
        "y" : -3929.950939864625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CaptnAtheist",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CaptnAtheist",
        "SelfLoops" : 0,
        "SUID" : 794,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2386.106550870964,
        "y" : -3659.998486251344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Emsatthedisco",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Emsatthedisco",
        "SelfLoops" : 0,
        "SUID" : 793,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2139.2817217694014,
        "y" : -3622.430645675172
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "792",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sloppyjoehotdog",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sloppyjoehotdog",
        "SelfLoops" : 0,
        "SUID" : 792,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2504.108290372917,
        "y" : -3725.799511641969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KamWah888",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KamWah888",
        "SelfLoops" : 0,
        "SUID" : 791,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 63.0
      },
      "position" : {
        "x" : 2386.561842619011,
        "y" : -3539.97852775525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "790",
        "ClosenessCentrality" : 0.51,
        "Eccentricity" : 3,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "NaattuVarthakal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 0,
        "name" : "NaattuVarthakal",
        "SelfLoops" : 0,
        "SUID" : 790,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9607843137254901,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -1657.011369050911,
        "y" : -790.4031035609141
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "ClosenessCentrality" : 0.9629629629629629,
        "Eccentricity" : 2,
        "Outdegree" : 25,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0015384615384615385,
        "Stress" : 1222,
        "shared_name" : "TheSCANFndtn",
        "BetweennessCentrality" : 0.4607843137254902,
        "EdgeCount" : 26,
        "Indegree" : 1,
        "name" : "TheSCANFndtn",
        "SelfLoops" : 0,
        "SUID" : 789,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0384615384615385,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.1923076923076923
      },
      "position" : {
        "x" : -1415.6682522906572,
        "y" : -599.8051879115001
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 583,
        "shared_name" : "TrevorGriffey",
        "BetweennessCentrality" : 0.2198340874811463,
        "EdgeCount" : 13,
        "Indegree" : 2,
        "name" : "TrevorGriffey",
        "SelfLoops" : 0,
        "SUID" : 788,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.1538461538461537
      },
      "position" : {
        "x" : -1665.2915814532548,
        "y" : -1055.2529341883555
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 517,
        "shared_name" : "alexsapps",
        "BetweennessCentrality" : 0.194947209653092,
        "EdgeCount" : 12,
        "Indegree" : 1,
        "name" : "alexsapps",
        "SelfLoops" : 0,
        "SUID" : 787,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.1666666666666667
      },
      "position" : {
        "x" : -1904.847276033333,
        "y" : -722.0480467982188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "786",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.16666666666666666,
        "Stress" : 93,
        "shared_name" : "Dr_Gretch",
        "BetweennessCentrality" : 0.03506787330316742,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "Dr_Gretch",
        "SelfLoops" : 0,
        "SUID" : 786,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.666666666666666
      },
      "position" : {
        "x" : -1268.8567212237626,
        "y" : -460.4750487513438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SeniorTypes",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SeniorTypes",
        "SelfLoops" : 0,
        "SUID" : 785,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1345.3401921405107,
        "y" : -681.6891600794688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "784",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "InaJaffeNPR",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "InaJaffeNPR",
        "SelfLoops" : 0,
        "SUID" : 784,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1454.3905842913896,
        "y" : -486.22092887829695
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "NORCNews",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "NORCNews",
        "SelfLoops" : 0,
        "SUID" : 783,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1246.5631726397783,
        "y" : -650.5936400599376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HollywdHealth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HollywdHealth",
        "SelfLoops" : 0,
        "SUID" : 782,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1279.491479219368,
        "y" : -705.8564116663829
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DrJasonLee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DrJasonLee",
        "SelfLoops" : 0,
        "SUID" : 781,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1329.8063290728837,
        "y" : -497.68958732556257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "780",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "johnahartford",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "johnahartford",
        "SelfLoops" : 0,
        "SUID" : 780,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1320.792260469368,
        "y" : -565.316387862672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "posttaseniors",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "posttaseniors",
        "SelfLoops" : 0,
        "SUID" : 779,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1413.4145892276078,
        "y" : -703.2426421351329
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "778",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FamDocDon",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FamDocDon",
        "SelfLoops" : 0,
        "SUID" : 778,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1567.946412385872,
        "y" : -546.8765074915782
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DrAnkurB",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DrAnkurB",
        "SelfLoops" : 0,
        "SUID" : 777,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1488.0678341998369,
        "y" : -437.3785826868907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AdiraFound",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AdiraFound",
        "SelfLoops" : 0,
        "SUID" : 776,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1243.3376019610673,
        "y" : -586.5288207240001
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CentersSenior",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CentersSenior",
        "SelfLoops" : 0,
        "SUID" : 775,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1332.2449505938798,
        "y" : -744.8056151575938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "774",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SFTechCouncil",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SFTechCouncil",
        "SelfLoops" : 0,
        "SUID" : 774,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1545.1139691485673,
        "y" : -680.3665282435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "capolenick",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "capolenick",
        "SelfLoops" : 0,
        "SUID" : 773,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1486.2141430987626,
        "y" : -688.8626219935313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "772",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.5,
        "Stress" : 0,
        "shared_name" : "iamamyherr",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "iamamyherr",
        "SelfLoops" : 0,
        "SUID" : 772,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.5
      },
      "position" : {
        "x" : -1360.9647687091142,
        "y" : -440.9596373743907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MaryDNaylor",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MaryDNaylor",
        "SelfLoops" : 0,
        "SUID" : 771,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1513.095208467415,
        "y" : -604.9376952357188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "PennNCTH",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "PennNCTH",
        "SelfLoops" : 0,
        "SUID" : 770,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1395.1519835604936,
        "y" : -498.49131462048445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "The_PPAL",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "The_PPAL",
        "SelfLoops" : 0,
        "SUID" : 769,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1395.2828686847001,
        "y" : -764.5229766077891
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "768",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DrBruce_TSF",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DrBruce_TSF",
        "SelfLoops" : 0,
        "SUID" : 768,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1304.9009640826494,
        "y" : -628.2124144740001
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MichaelWinship",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MichaelWinship",
        "SelfLoops" : 0,
        "SUID" : 767,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1542.0222027911454,
        "y" : -481.9144713587657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "766",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ThatVDOVault",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ThatVDOVault",
        "SelfLoops" : 0,
        "SUID" : 766,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1418.6966279162675,
        "y" : -419.8640563197032
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Yoloaging",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Yoloaging",
        "SelfLoops" : 0,
        "SUID" : 765,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1498.8836758746415,
        "y" : -533.4273192591563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "WestHealth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "WestHealth",
        "SelfLoops" : 0,
        "SUID" : 764,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1573.758424104622,
        "y" : -616.8260619349376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "shelleylyford",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "shelleylyford",
        "SelfLoops" : 0,
        "SUID" : 763,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1469.4476292742997,
        "y" : -750.4244658656016
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mari_nicholson",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mari_nicholson",
        "SelfLoops" : 0,
        "SUID" : 762,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -1266.2516492022783,
        "y" : -530.4389769740001
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "amymyork2",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "amymyork2",
        "SelfLoops" : 0,
        "SUID" : 761,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -1179.821656526497,
        "y" : -366.3558776087657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "760",
        "ClosenessCentrality" : 0.25757575757575757,
        "Eccentricity" : 6,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "harrisonplam",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "harrisonplam",
        "SelfLoops" : 0,
        "SUID" : 760,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 3.8823529411764706,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 1499.1856219158858,
        "y" : -2298.4573485560313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "ClosenessCentrality" : 0.32653061224489793,
        "Eccentricity" : 5,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 256,
        "shared_name" : "UCIrvineSOM",
        "BetweennessCentrality" : 0.01823102122204814,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "UCIrvineSOM",
        "SelfLoops" : 0,
        "SUID" : 759,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 3.0625,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.6666666666666667
      },
      "position" : {
        "x" : 1405.253767667839,
        "y" : -2379.8426634974376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "UCIrvineSurgery",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "UCIrvineSurgery",
        "SelfLoops" : 0,
        "SUID" : 758,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 1397.4394060955733,
        "y" : -2256.218945235719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "ClosenessCentrality" : 0.42424242424242425,
        "Eccentricity" : 4,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.16666666666666666,
        "Stress" : 434,
        "shared_name" : "ucinursing",
        "BetweennessCentrality" : 0.03090727816550349,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "ucinursing",
        "SelfLoops" : 0,
        "SUID" : 757,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.357142857142857,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.333333333333333
      },
      "position" : {
        "x" : 1338.2755877361983,
        "y" : -2520.753643722047
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "756",
        "ClosenessCentrality" : 0.6499999999999999,
        "Eccentricity" : 3,
        "Outdegree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.03333333333333333,
        "Stress" : 504,
        "shared_name" : "UCIrvineHealth",
        "BetweennessCentrality" : 0.035892323030907274,
        "EdgeCount" : 10,
        "Indegree" : 1,
        "name" : "UCIrvineHealth",
        "SelfLoops" : 0,
        "SUID" : 756,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.5384615384615385,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.9
      },
      "position" : {
        "x" : 1259.4974696026534,
        "y" : -2696.4369017786876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Stress" : 0,
        "shared_name" : "ucipeds",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 3,
        "Indegree" : 3,
        "name" : "ucipeds",
        "SelfLoops" : 0,
        "SUID" : 755,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.333333333333333
      },
      "position" : {
        "x" : 1247.633421598503,
        "y" : -2573.283734054078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "754",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Stress" : 279,
        "shared_name" : "UCI_OVCHA",
        "BetweennessCentrality" : 0.01986896453496653,
        "EdgeCount" : 3,
        "Indegree" : 2,
        "name" : "UCI_OVCHA",
        "SelfLoops" : 0,
        "SUID" : 754,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.333333333333333
      },
      "position" : {
        "x" : 1163.4692065106124,
        "y" : -2636.8824584193126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ucimath",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ucimath",
        "SelfLoops" : 0,
        "SUID" : 753,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 1393.6746508465499,
        "y" : -2699.604229659547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "ClosenessCentrality" : 0.5714285714285714,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 648,
        "shared_name" : "UCIrvine",
        "BetweennessCentrality" : 0.04614727246830935,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "UCIrvine",
        "SelfLoops" : 0,
        "SUID" : 752,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.75,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.5
      },
      "position" : {
        "x" : 1231.9132334576339,
        "y" : -2935.350935668458
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nowvoyagertravl",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "nowvoyagertravl",
        "SelfLoops" : 0,
        "SUID" : 751,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 1326.850477872917,
        "y" : -2600.7212645716563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "750",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CoyoteDucks54",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CoyoteDucks54",
        "SelfLoops" : 0,
        "SUID" : 750,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 1389.0242297039717,
        "y" : -2631.421642989625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "q22q17",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "q22q17",
        "SelfLoops" : 0,
        "SUID" : 749,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 1366.649794279167,
        "y" : -2766.0413939661876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "748",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "GoDucks910",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "GoDucks910",
        "SelfLoops" : 0,
        "SUID" : 748,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 1288.805197416374,
        "y" : -2805.2774321741954
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "ClosenessCentrality" : 0.28503937007874014,
        "Eccentricity" : 6,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Csomethingelse",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "Csomethingelse",
        "SelfLoops" : 0,
        "SUID" : 747,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 3.5082872928176796,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -116.15339785950482,
        "y" : -2340.524624557008
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "ClosenessCentrality" : 0.39647577092511016,
        "Eccentricity" : 5,
        "Outdegree" : 58,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 56120,
        "shared_name" : "RepBarragan",
        "BetweennessCentrality" : 0.33061136002312475,
        "EdgeCount" : 60,
        "Indegree" : 2,
        "name" : "RepBarragan",
        "SelfLoops" : 1,
        "SUID" : 746,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.522222222222222,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.1206896551724137
      },
      "position" : {
        "x" : -195.40620547669232,
        "y" : -2228.2926451868907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "PoliticalBee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "PoliticalBee",
        "SelfLoops" : 0,
        "SUID" : 745,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -337.39845401184857,
        "y" : -2145.4744994349376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "744",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MesMitch",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MesMitch",
        "SelfLoops" : 0,
        "SUID" : 744,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -294.3990033282548,
        "y" : -2211.98926994275
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SLT_3",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SLT_3",
        "SelfLoops" : 0,
        "SUID" : 743,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -277.24061709778607,
        "y" : -2062.1329772181407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "742",
        "ClosenessCentrality" : 0.391304347826087,
        "Eccentricity" : 4,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.05,
        "Stress" : 35322,
        "shared_name" : "tomasrabago1",
        "BetweennessCentrality" : 0.19804162451221277,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "tomasrabago1",
        "SelfLoops" : 0,
        "SUID" : 742,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.5555555555555554,
        "selected" : false,
        "NeighborhoodConnectivity" : 18.4
      },
      "position" : {
        "x" : -57.72187930481732,
        "y" : -2568.061909408082
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EnergyCommerce",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "EnergyCommerce",
        "SelfLoops" : 0,
        "SUID" : 741,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -24.87214785950482,
        "y" : -2178.6880004115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DanLimmert",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DanLimmert",
        "SelfLoops" : 0,
        "SUID" : 740,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -343.13124209778607,
        "y" : -2366.7918822474376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "delgadodaphne",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "delgadodaphne",
        "SelfLoops" : 0,
        "SUID" : 739,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -69.75618106262982,
        "y" : -2016.2223021693126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "738",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DaraLieb",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DaraLieb",
        "SelfLoops" : 0,
        "SUID" : 738,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -306.7249310626298,
        "y" : -2103.934033126344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "minter01",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "minter01",
        "SelfLoops" : 0,
        "SUID" : 737,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -41.29475528137982,
        "y" : -2125.415722579469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "736",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Evcoc54",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Evcoc54",
        "SelfLoops" : 0,
        "SUID" : 736,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -280.04493838684857,
        "y" : -2159.8890807337657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "clandersen",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "clandersen",
        "SelfLoops" : 0,
        "SUID" : 735,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -401.37269717591107,
        "y" : -2231.9888426966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "UniteBlue",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "UniteBlue",
        "SelfLoops" : 0,
        "SUID" : 734,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -269.22206241028607,
        "y" : -2403.98048088025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "joy31608",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "joy31608",
        "SelfLoops" : 0,
        "SUID" : 733,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -162.34938174622357,
        "y" : -2375.9193694300548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "732",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "oregon_zoe",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "oregon_zoe",
        "SelfLoops" : 0,
        "SUID" : 732,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -115.46223575012982,
        "y" : -2210.184826583375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pelon_0914",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pelon_0914",
        "SelfLoops" : 0,
        "SUID" : 731,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : 36.13761776549518,
        "y" : -2266.7400786585704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "730",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BusyBes",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BusyBes",
        "SelfLoops" : 0,
        "SUID" : 730,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -382.80262881653607,
        "y" : -2298.079342574586
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CocoaSwann",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CocoaSwann",
        "SelfLoops" : 0,
        "SUID" : 729,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -58.07563907044232,
        "y" : -2336.965603560914
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RepBonnie",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "RepBonnie",
        "SelfLoops" : 0,
        "SUID" : 728,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -237.27760440247357,
        "y" : -2311.0289733118907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Djama18291981",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Djama18291981",
        "SelfLoops" : 0,
        "SUID" : 727,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -327.67091494934857,
        "y" : -2309.3777892298594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "726",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JanuaryHandl",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JanuaryHandl",
        "SelfLoops" : 0,
        "SUID" : 726,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : 9.525923429557679,
        "y" : -2094.312237472047
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SpoaSteph",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SpoaSteph",
        "SelfLoops" : 0,
        "SUID" : 725,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -15.136918367317321,
        "y" : -2228.274853438844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "724",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "juant_info",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "juant_info",
        "SelfLoops" : 0,
        "SUID" : 724,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -248.93843203919232,
        "y" : -2106.74415275525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DahHipster",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DahHipster",
        "SelfLoops" : 0,
        "SUID" : 723,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -353.6076214923173,
        "y" : -2196.239941329469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "IMPEACH_putin",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "IMPEACH_putin",
        "SelfLoops" : 0,
        "SUID" : 722,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -196.14906436341107,
        "y" : -2425.9631697840587
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JuanHinojosAZ",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JuanHinojosAZ",
        "SelfLoops" : 0,
        "SUID" : 721,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -373.2775433673173,
        "y" : -2101.721142501344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "720",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sabinenamba",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sabinenamba",
        "SelfLoops" : 0,
        "SUID" : 720,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -76.84675723450482,
        "y" : -2172.9605834193126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dumpbloatus",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dumpbloatus",
        "SelfLoops" : 0,
        "SUID" : 719,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -343.1507123126298,
        "y" : -2250.918682784547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "eeyoresmother",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "eeyoresmother",
        "SelfLoops" : 0,
        "SUID" : 718,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -187.54200869934857,
        "y" : -1994.9730651087657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Viccimn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Viccimn",
        "SelfLoops" : 0,
        "SUID" : 717,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -339.16175967591107,
        "y" : -2055.266827315797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "chelbeans",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "chelbeans",
        "SelfLoops" : 0,
        "SUID" : 716,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -403.2377484454423,
        "y" : -2162.420849532594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "aliskander81",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "aliskander81",
        "SelfLoops" : 0,
        "SUID" : 715,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -102.64668399231732,
        "y" : -2130.4584166712657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "714",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AhnJungGeun888",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AhnJungGeun888",
        "SelfLoops" : 0,
        "SUID" : 714,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -173.27449160950482,
        "y" : -2046.4276854700938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "IncanSusan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "IncanSusan",
        "SelfLoops" : 0,
        "SUID" : 713,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -147.83363467591107,
        "y" : -2155.382336349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "712",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MelindaTolley",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MelindaTolley",
        "SelfLoops" : 0,
        "SUID" : 712,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -67.07270938294232,
        "y" : -2233.679974288453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JaymieRose",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JaymieRose",
        "SelfLoops" : 0,
        "SUID" : 711,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -173.42683535950482,
        "y" : -2318.5062377161876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JakeSpectre89",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JakeSpectre89",
        "SelfLoops" : 0,
        "SUID" : 710,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -282.1734173907548,
        "y" : -2348.2486693568126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LucyMFel",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LucyMFel",
        "SelfLoops" : 0,
        "SUID" : 709,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : 38.18925350768268,
        "y" : -2203.2953307337657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Violetkim",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Violetkim",
        "SelfLoops" : 0,
        "SUID" : 708,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -131.72737246887982,
        "y" : -2281.3011138148204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Blur15357148",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Blur15357148",
        "SelfLoops" : 0,
        "SUID" : 707,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -191.64357119934857,
        "y" : -2112.312481612672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "706",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RepBobbyRush",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "RepBobbyRush",
        "SelfLoops" : 0,
        "SUID" : 706,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : 24.14359921080768,
        "y" : -2147.858685225953
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DavidOCarterCA",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DavidOCarterCA",
        "SelfLoops" : 0,
        "SUID" : 705,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -281.9954388751298,
        "y" : -2270.906948775758
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "prime_bee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "prime_bee",
        "SelfLoops" : 0,
        "SUID" : 704,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -142.20643741028607,
        "y" : -2096.662640304078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "penndragonArt",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "penndragonArt",
        "SelfLoops" : 0,
        "SUID" : 703,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -294.4232953204423,
        "y" : -2012.1155211634532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "702",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Chercher08",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Chercher08",
        "SelfLoops" : 0,
        "SUID" : 702,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -224.00416690247357,
        "y" : -2058.803753585328
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "m0nicuuhh",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "m0nicuuhh",
        "SelfLoops" : 0,
        "SUID" : 701,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -1.457597078254821,
        "y" : -2337.4705931849376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "700",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DefendOurFuture",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DefendOurFuture",
        "SelfLoops" : 0,
        "SUID" : 700,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -116.48835879700482,
        "y" : -2049.1983458704844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JHF719",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JHF719",
        "SelfLoops" : 0,
        "SUID" : 699,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -59.69905215637982,
        "y" : -2387.0980803675548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ecowarrior350",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ecowarrior350",
        "SelfLoops" : 0,
        "SUID" : 698,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -222.74830752747357,
        "y" : -2369.9846389002696
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SEEC",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SEEC",
        "SelfLoops" : 0,
        "SUID" : 697,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -130.03932315247357,
        "y" : -1990.9558531947032
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "696",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dwatchnews",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dwatchnews",
        "SelfLoops" : 0,
        "SUID" : 696,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -17.04377871887982,
        "y" : -2285.5100676722423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "harviolet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "harviolet",
        "SelfLoops" : 0,
        "SUID" : 695,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -116.47126895325482,
        "y" : -2405.532467574586
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "694",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AnnaMHargrave",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AnnaMHargrave",
        "SelfLoops" : 0,
        "SUID" : 694,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -227.87031680481732,
        "y" : -2159.554424972047
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pinky_or_brain",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pinky_or_brain",
        "SelfLoops" : 0,
        "SUID" : 693,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -239.56044131653607,
        "y" : -2002.2689940638438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SayHere1st_Last",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SayHere1st_Last",
        "SelfLoops" : 0,
        "SUID" : 692,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -30.44636660950482,
        "y" : -2055.6385008997813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MattDernoga",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MattDernoga",
        "SelfLoops" : 0,
        "SUID" : 691,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -76.31306582825482,
        "y" : -2084.4492919154063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "690",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Starbright489",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Starbright489",
        "SelfLoops" : 0,
        "SUID" : 690,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 58.0
      },
      "position" : {
        "x" : -74.98677188294232,
        "y" : -2286.963848800172
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 65,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 45500,
        "shared_name" : "katieporteroc",
        "BetweennessCentrality" : 0.27400395047453874,
        "EdgeCount" : 67,
        "Indegree" : 2,
        "name" : "katieporteroc",
        "SelfLoops" : 0,
        "SUID" : 689,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.044776119402985
      },
      "position" : {
        "x" : -1082.4253857745439,
        "y" : -3709.798535079469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "688",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 2034,
        "shared_name" : "RepGilCisneros",
        "BetweennessCentrality" : 0.01224887989593872,
        "EdgeCount" : 4,
        "Indegree" : 2,
        "name" : "RepGilCisneros",
        "SelfLoops" : 0,
        "SUID" : 688,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.75
      },
      "position" : {
        "x" : -976.9213421954423,
        "y" : -2944.6724669642344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "ClosenessCentrality" : 0.4266666666666667,
        "Eccentricity" : 4,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lbpd_volunteers",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "lbpd_volunteers",
        "SelfLoops" : 0,
        "SUID" : 687,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.34375,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -869.6601117266923,
        "y" : -2590.408283919801
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "ClosenessCentrality" : 0.7209302325581395,
        "Eccentricity" : 3,
        "Outdegree" : 23,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 4650,
        "shared_name" : "LBHealthDept",
        "BetweennessCentrality" : 0.0280026015320133,
        "EdgeCount" : 24,
        "Indegree" : 1,
        "name" : "LBHealthDept",
        "SelfLoops" : 0,
        "SUID" : 686,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.3870967741935485,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.3333333333333333
      },
      "position" : {
        "x" : -729.2111371173173,
        "y" : -2512.2293402857676
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LBDisasterPrep",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LBDisasterPrep",
        "SelfLoops" : 0,
        "SUID" : 685,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -687.0285809649736,
        "y" : -2422.111035079469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Southland_CU",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Southland_CU",
        "SelfLoops" : 0,
        "SUID" : 684,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -818.6760113848954,
        "y" : -2646.489788741578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JRsagittarius",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JRsagittarius",
        "SelfLoops" : 0,
        "SUID" : 683,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -644.6948407305986,
        "y" : -2379.647701949586
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "McBealism1024",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "McBealism1024",
        "SelfLoops" : 0,
        "SUID" : 682,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -843.0082257403642,
        "y" : -2400.301510543336
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "longbeachcall",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "longbeachcall",
        "SelfLoops" : 0,
        "SUID" : 681,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -641.3459332598954,
        "y" : -2559.177517623414
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "natalierdrgzxx",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "natalierdrgzxx",
        "SelfLoops" : 0,
        "SUID" : 680,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -731.6908734454423,
        "y" : -2612.220814437379
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LBTV3",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LBTV3",
        "SelfLoops" : 0,
        "SUID" : 679,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -616.1363690509111,
        "y" : -2450.238621444215
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "678",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "yjmpix",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "yjmpix",
        "SelfLoops" : 0,
        "SUID" : 678,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -901.3498852862626,
        "y" : -2518.5340697474376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AlvcaKris",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AlvcaKris",
        "SelfLoops" : 0,
        "SUID" : 677,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -801.975694002083,
        "y" : -2586.6901747889415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "676",
        "ClosenessCentrality" : 0.625,
        "Eccentricity" : 2,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 1490,
        "shared_name" : "RoseParkLB",
        "BetweennessCentrality" : 0.008972876619935444,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "RoseParkLB",
        "SelfLoops" : 0,
        "SUID" : 676,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.6,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : -608.6109173907548,
        "y" : -2765.7256896204844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jrentro7",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jrentro7",
        "SelfLoops" : 0,
        "SUID" : 675,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -839.2918255938798,
        "y" : -2530.6302725977794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "NerdFajuto",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "NerdFajuto",
        "SelfLoops" : 0,
        "SUID" : 674,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -618.9414227618486,
        "y" : -2613.583882064332
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KirkNason",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KirkNason",
        "SelfLoops" : 0,
        "SUID" : 673,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -760.7436688555986,
        "y" : -2409.847897262086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "672",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LBMayorsFund4Ed",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LBMayorsFund4Ed",
        "SelfLoops" : 0,
        "SUID" : 672,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -721.4296429766923,
        "y" : -2352.2322814173594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lara_adam_m",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lara_adam_m",
        "SelfLoops" : 0,
        "SUID" : 671,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -797.2829754962236,
        "y" : -2356.699001998414
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "670",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hzlalice",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "hzlalice",
        "SelfLoops" : 0,
        "SUID" : 670,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -816.9859784259111,
        "y" : -2458.952763289918
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bames_jrolin",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "bames_jrolin",
        "SelfLoops" : 0,
        "SUID" : 669,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.5
      },
      "position" : {
        "x" : -413.49806338684857,
        "y" : -2676.734142989625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "ClosenessCentrality" : 0.75,
        "Eccentricity" : 2,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.05,
        "Stress" : 6870,
        "shared_name" : "LongBeachCity",
        "BetweennessCentrality" : 0.02502167943344414,
        "EdgeCount" : 5,
        "Indegree" : 3,
        "name" : "LongBeachCity",
        "SelfLoops" : 0,
        "SUID" : 668,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.3333333333333333,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.4
      },
      "position" : {
        "x" : -351.93007022278607,
        "y" : -2653.3008391566173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "PhoenixArielle",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "PhoenixArielle",
        "SelfLoops" : 0,
        "SUID" : 667,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 98.0
      },
      "position" : {
        "x" : -1215.9343655719072,
        "y" : -2083.6119506068126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AGuzmanLopez",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AGuzmanLopez",
        "SelfLoops" : 0,
        "SUID" : 666,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -885.2830365313798,
        "y" : -2451.1712577052012
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LBSchoolNurses",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LBSchoolNurses",
        "SelfLoops" : 0,
        "SUID" : 665,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -594.1079266680986,
        "y" : -2516.535370559205
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Mrsjayknee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Mrsjayknee",
        "SelfLoops" : 0,
        "SUID" : 664,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -753.8810895098954,
        "y" : -2671.480435103883
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CounselorHamlet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CounselorHamlet",
        "SelfLoops" : 0,
        "SUID" : 663,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 24.0
      },
      "position" : {
        "x" : -680.9633954180986,
        "y" : -2647.724407882203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "ClosenessCentrality" : 0.36697247706422015,
        "Eccentricity" : 4,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.3333333333333333,
        "Stress" : 3620,
        "shared_name" : "LBEconDev",
        "BetweennessCentrality" : 0.010899937370525607,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "LBEconDev",
        "SelfLoops" : 0,
        "SUID" : 662,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.725,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : -165.94911319153607,
        "y" : -2676.4829833216563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "ClosenessCentrality" : 0.5342465753424658,
        "Eccentricity" : 3,
        "Outdegree" : 15,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.007352941176470588,
        "Stress" : 38515,
        "shared_name" : "LongBeachMayor",
        "BetweennessCentrality" : 0.22103989015753722,
        "EdgeCount" : 17,
        "Indegree" : 2,
        "name" : "LongBeachMayor",
        "SelfLoops" : 0,
        "SUID" : 661,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8717948717948718,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.3529411764705883
      },
      "position" : {
        "x" : -65.12642032044232,
        "y" : -2808.290295333375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "660",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 6225,
        "shared_name" : "SupJaniceHahn",
        "BetweennessCentrality" : 0.037487353663824254,
        "EdgeCount" : 7,
        "Indegree" : 2,
        "name" : "SupJaniceHahn",
        "SelfLoops" : 0,
        "SUID" : 660,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.5714285714285714
      },
      "position" : {
        "x" : 226.79386776549518,
        "y" : -2521.690233916749
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 5430,
        "shared_name" : "RobertGarciaLB",
        "BetweennessCentrality" : 0.03269981211157682,
        "EdgeCount" : 7,
        "Indegree" : 1,
        "name" : "RobertGarciaLB",
        "SelfLoops" : 0,
        "SUID" : 659,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.5714285714285714
      },
      "position" : {
        "x" : -196.82283145325482,
        "y" : -2741.584225387086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "658",
        "ClosenessCentrality" : 0.27272727272727276,
        "Eccentricity" : 5,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BlinstrubJ",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "BlinstrubJ",
        "SelfLoops" : 0,
        "SUID" : 658,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 3.6666666666666665,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 998.224730192253,
        "y" : -3845.1273314661876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "ClosenessCentrality" : 0.359375,
        "Eccentricity" : 4,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 1288,
        "shared_name" : "IUSD",
        "BetweennessCentrality" : 0.09172482552342971,
        "EdgeCount" : 5,
        "Indegree" : 1,
        "name" : "IUSD",
        "SelfLoops" : 0,
        "SUID" : 657,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.782608695652174,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.2
      },
      "position" : {
        "x" : 1063.3020007000655,
        "y" : -3741.7767455286876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "ClosenessCentrality" : 0.46341463414634143,
        "Eccentricity" : 3,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 2109,
        "shared_name" : "daybird77",
        "BetweennessCentrality" : 0.15019228030195128,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "daybird77",
        "SelfLoops" : 0,
        "SUID" : 656,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.1578947368421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1008.414915739128,
        "y" : -3591.2830321497813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "IHSVaqueros",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "IHSVaqueros",
        "SelfLoops" : 0,
        "SUID" : 655,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 1150.5138384686202,
        "y" : -3673.764111251344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "654",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DrBrentFreeze",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DrBrentFreeze",
        "SelfLoops" : 0,
        "SUID" : 654,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 1175.9745680676192,
        "y" : -3788.5427977747813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jwilliamsiusd",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jwilliamsiusd",
        "SelfLoops" : 0,
        "SUID" : 653,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 1106.1808916912764,
        "y" : -3860.467968673219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HHAlexanderSC",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HHAlexanderSC",
        "SelfLoops" : 0,
        "SUID" : 649,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 343.3664996014327,
        "y" : -940.6928755946055
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FlamingGary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FlamingGary",
        "SelfLoops" : 0,
        "SUID" : 647,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 429.1509539471358,
        "y" : -864.968373031129
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "reneedora",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "reneedora",
        "SelfLoops" : 0,
        "SUID" : 645,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 360.9470965252608,
        "y" : -879.2648513026134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mswright247",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mswright247",
        "SelfLoops" : 0,
        "SUID" : 641,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 374.6518084393233,
        "y" : -825.563832015504
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jferraro5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jferraro5",
        "SelfLoops" : 0,
        "SUID" : 638,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 402.9004351483077,
        "y" : -922.316517562379
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "elemteach3r",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "elemteach3r",
        "SelfLoops" : 0,
        "SUID" : 635,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 293.3794390545577,
        "y" : -1075.2198264307872
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "634",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jetwoman29",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jetwoman29",
        "SelfLoops" : 0,
        "SUID" : 634,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 386.2489458904952,
        "y" : -989.7258193201915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KimHarding5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KimHarding5",
        "SelfLoops" : 0,
        "SUID" : 632,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 275.39707821471393,
        "y" : -1016.5056349940196
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MrsV4nd3r",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MrsV4nd3r",
        "SelfLoops" : 0,
        "SUID" : 631,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 412.7869097576827,
        "y" : -1068.642891616334
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CMcLain2",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CMcLain2",
        "SelfLoops" : 0,
        "SUID" : 626,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 439.27427548033893,
        "y" : -807.6904799647227
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MrSalazar_4th",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MrSalazar_4th",
        "SelfLoops" : 0,
        "SUID" : 623,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 321.66197079283893,
        "y" : -1128.6858327097789
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "622",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "_vanes_f",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "_vanes_f",
        "SelfLoops" : 0,
        "SUID" : 622,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 368.1728960858077,
        "y" : -1176.1208998865977
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LetsPlayPreK",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LetsPlayPreK",
        "SelfLoops" : 0,
        "SUID" : 621,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 352.38343685729205,
        "y" : -1061.580475539674
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nplace1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "nplace1",
        "SelfLoops" : 0,
        "SUID" : 619,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 303.7949969158858,
        "y" : -889.9843795008555
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "iteachspedK5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "iteachspedK5",
        "SelfLoops" : 0,
        "SUID" : 617,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 443.9461962567061,
        "y" : -1128.6588132090465
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "616",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Mrs_RitzesPreK",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Mrs_RitzesPreK",
        "SelfLoops" : 0,
        "SUID" : 616,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 383.8457781658858,
        "y" : -1120.4344100661174
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rileylibrary",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "rileylibrary",
        "SelfLoops" : 0,
        "SUID" : 615,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 426.9530321942061,
        "y" : -1187.1520659632579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "busymom_74",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "busymom_74",
        "SelfLoops" : 0,
        "SUID" : 613,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 333.6337115154952,
        "y" : -1006.0661284632579
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "612",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Yliliana21",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Yliliana21",
        "SelfLoops" : 0,
        "SUID" : 612,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 283.2543475018233,
        "y" : -954.5603072352305
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MaestraFowler",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MaestraFowler",
        "SelfLoops" : 0,
        "SUID" : 611,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : 467.43694943053424,
        "y" : -912.475224227418
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "610",
        "ClosenessCentrality" : 0.5060240963855421,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JanFrye",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "JanFrye",
        "SelfLoops" : 0,
        "SUID" : 610,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9761904761904763,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -785.6104443682939,
        "y" : -1127.1610686488048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 41,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 861,
        "shared_name" : "SquireJames",
        "BetweennessCentrality" : 0.5,
        "EdgeCount" : 42,
        "Indegree" : 1,
        "name" : "SquireJames",
        "SelfLoops" : 0,
        "SUID" : 609,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0
      },
      "position" : {
        "x" : -876.1874402179033,
        "y" : -1005.2823953337565
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EMIBORINGYOU",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "EMIBORINGYOU",
        "SelfLoops" : 0,
        "SUID" : 608,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -893.6237805499345,
        "y" : -804.4143798060313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "godless2020",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "godless2020",
        "SelfLoops" : 0,
        "SUID" : 607,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1010.7736218585283,
        "y" : -853.2986571497813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "606",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "weshouldallcare",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "weshouldallcare",
        "SelfLoops" : 0,
        "SUID" : 606,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -804.2877820147783,
        "y" : -877.7271849818126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JerseyKidPicks",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JerseyKidPicks",
        "SelfLoops" : 0,
        "SUID" : 605,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -981.539674104622,
        "y" : -899.3378798670665
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "604",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "edgar_eduarte",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "edgar_eduarte",
        "SelfLoops" : 0,
        "SUID" : 604,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -735.8445752276689,
        "y" : -1151.084210128297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "suznu",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "suznu",
        "SelfLoops" : 0,
        "SUID" : 603,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1028.0377820147783,
        "y" : -1137.9073455042735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HOOPSnix",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HOOPSnix",
        "SelfLoops" : 0,
        "SUID" : 602,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -933.222779573372,
        "y" : -1067.868347854127
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "monstro_fan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "monstro_fan",
        "SelfLoops" : 0,
        "SUID" : 601,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -793.8837597979814,
        "y" : -1192.127423018922
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FBattels",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FBattels",
        "SelfLoops" : 0,
        "SUID" : 600,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -726.0490124835283,
        "y" : -1006.5710379786387
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bazookajoet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bazookajoet",
        "SelfLoops" : 0,
        "SUID" : 599,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -920.031617463997,
        "y" : -1202.205334395875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Jmontel99",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Jmontel99",
        "SelfLoops" : 0,
        "SUID" : 598,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1072.0266736163408,
        "y" : -969.2045676417247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DeplorableMi17",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DeplorableMi17",
        "SelfLoops" : 0,
        "SUID" : 597,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -965.438844026497,
        "y" : -1120.2812697596446
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Gregory__Adams",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Gregory__Adams",
        "SelfLoops" : 0,
        "SUID" : 596,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -990.035523713997,
        "y" : -1065.7759291834727
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "yung817lo",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "yung817lo",
        "SelfLoops" : 0,
        "SUID" : 595,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -760.1017468585283,
        "y" : -835.1042601771251
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "594",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SorinaDurante",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SorinaDurante",
        "SelfLoops" : 0,
        "SUID" : 594,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -871.3291638507158,
        "y" : -910.2894713587657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "trinketchase",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "trinketchase",
        "SelfLoops" : 0,
        "SUID" : 593,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -674.1842358722001,
        "y" : -978.390169829835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Angie74720660",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Angie74720660",
        "SelfLoops" : 0,
        "SUID" : 592,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -936.5360730304033,
        "y" : -934.0945174403087
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "beaglebabe48",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "beaglebabe48",
        "SelfLoops" : 0,
        "SUID" : 591,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -968.4670422686845,
        "y" : -1000.256664008607
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "betty_rindal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "betty_rindal",
        "SelfLoops" : 0,
        "SUID" : 590,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -877.0808728350908,
        "y" : -1098.3787505335704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "UGHExpressions",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "UGHExpressions",
        "SelfLoops" : 0,
        "SUID" : 589,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -694.4977429522783,
        "y" : -916.9612242884532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "gonshorowski",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "gonshorowski",
        "SelfLoops" : 0,
        "SUID" : 588,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -843.1999524249345,
        "y" : -1148.044445724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "contentguru69",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "contentguru69",
        "SelfLoops" : 0,
        "SUID" : 587,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -703.636597932747,
        "y" : -1101.2460143275157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Eagleriver4J",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Eagleriver4J",
        "SelfLoops" : 0,
        "SUID" : 586,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -806.8007519854814,
        "y" : -936.1883055872813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Sheindie",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Sheindie",
        "SelfLoops" : 0,
        "SUID" : 585,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1079.821656526497,
        "y" : -1036.1669776148692
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pedsscrub",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pedsscrub",
        "SelfLoops" : 0,
        "SUID" : 584,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -858.9091809405595,
        "y" : -1205.2749755091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TradingInCB1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TradingInCB1",
        "SelfLoops" : 0,
        "SUID" : 583,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -924.914429963997,
        "y" : -867.8843047327891
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Wewoka3",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Wewoka3",
        "SelfLoops" : 0,
        "SUID" : 582,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -956.2173474444658,
        "y" : -820.0677764124766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "herewegokids7",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "herewegokids7",
        "SelfLoops" : 0,
        "SUID" : 581,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -751.6599743975908,
        "y" : -1068.0783698267833
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Avaguesenseofun",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Avaguesenseofun",
        "SelfLoops" : 0,
        "SUID" : 580,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -747.125123323372,
        "y" : -893.4315917200938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AWKathy11",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AWKathy11",
        "SelfLoops" : 0,
        "SUID" : 579,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -911.0230115069658,
        "y" : -1145.6504637904063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "vearleavni",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "vearleavni",
        "SelfLoops" : 0,
        "SUID" : 578,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1053.7570813311845,
        "y" : -908.0471770472423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "enlightnup",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "enlightnup",
        "SelfLoops" : 0,
        "SUID" : 577,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -815.140748323372,
        "y" : -1078.0280501551524
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "576",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "radar210",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "radar210",
        "SelfLoops" : 0,
        "SUID" : 576,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -861.2207654132158,
        "y" : -854.9842345423594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sharbycreek",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sharbycreek",
        "SelfLoops" : 0,
        "SUID" : 575,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -978.615845979622,
        "y" : -1178.4043547816173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MDYankeefan1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MDYankeefan1",
        "SelfLoops" : 0,
        "SUID" : 574,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -680.6503613604814,
        "y" : -1046.4059912867442
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JoPhinney2",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JoPhinney2",
        "SelfLoops" : 0,
        "SUID" : 573,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -748.6496594561845,
        "y" : -952.9952399439708
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "NovemberMatters",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "NovemberMatters",
        "SelfLoops" : 0,
        "SUID" : 572,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -784.7350781573564,
        "y" : -1011.0503480143443
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AmandaE02423971",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AmandaE02423971",
        "SelfLoops" : 0,
        "SUID" : 571,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1043.9574597491533,
        "y" : -1082.605366439332
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Missy_Kidd",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Missy_Kidd",
        "SelfLoops" : 0,
        "SUID" : 570,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -823.7266247882158,
        "y" : -811.0962187952891
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BooyahBoyz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BooyahBoyz",
        "SelfLoops" : 0,
        "SUID" : 569,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1007.7182629718095,
        "y" : -950.3465125269786
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "568",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "unitedintreble",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "unitedintreble",
        "SelfLoops" : 0,
        "SUID" : 568,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -1026.0302746905595,
        "y" : -1012.1210968203441
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "ClosenessCentrality" : 0.47058823529411764,
        "Eccentricity" : 4,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CSUDHNSO",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "CSUDHNSO",
        "SelfLoops" : 0,
        "SUID" : 567,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.125,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -422.56497317688763,
        "y" : -699.9758441157237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "ClosenessCentrality" : 0.8333333333333334,
        "Eccentricity" : 3,
        "Outdegree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 330,
        "shared_name" : "DominguezHills",
        "BetweennessCentrality" : 0.1916376306620209,
        "EdgeCount" : 14,
        "Indegree" : 1,
        "name" : "DominguezHills",
        "SelfLoops" : 0,
        "SUID" : 566,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.2,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.2857142857142858
      },
      "position" : {
        "x" : -296.511353792122,
        "y" : -626.3674895472423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ASICSUDH",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ASICSUDH",
        "SelfLoops" : 0,
        "SUID" : 565,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -307.91497928040326,
        "y" : -525.9349791712657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "csudhteddytoro",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "csudhteddytoro",
        "SelfLoops" : 0,
        "SUID" : 564,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -217.43826419251263,
        "y" : -517.9350707240001
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "ClosenessCentrality" : 0.5714285714285714,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 90,
        "shared_name" : "majackmon",
        "BetweennessCentrality" : 0.05226480836236934,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "majackmon",
        "SelfLoops" : 0,
        "SUID" : 563,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.75,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : -371.4634717120439,
        "y" : -484.25303337048445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "chuybaca",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "chuybaca",
        "SelfLoops" : 0,
        "SUID" : 562,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -273.3969739093095,
        "y" : -472.4357573695079
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Toni_Molle",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "Toni_Molle",
        "SelfLoops" : 0,
        "SUID" : 561,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : -398.81253177063763,
        "y" : -539.013668746461
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "calstate",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "calstate",
        "SelfLoops" : 0,
        "SUID" : 560,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 9.0
      },
      "position" : {
        "x" : -447.8310254229814,
        "y" : -573.152226180543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CSUDHExRel",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CSUDHExRel",
        "SelfLoops" : 0,
        "SUID" : 559,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -172.25033694641888,
        "y" : -566.6041915125743
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "558",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "theekbradshaw",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "theekbradshaw",
        "SelfLoops" : 0,
        "SUID" : 558,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -216.57830935852826,
        "y" : -707.8900725550548
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "yDominguezHills",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "yDominguezHills",
        "SelfLoops" : 0,
        "SUID" : 557,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -172.2993176593095,
        "y" : -636.7787024683848
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "556",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "esmeralina3",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "esmeralina3",
        "SelfLoops" : 0,
        "SUID" : 556,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -412.50491458313763,
        "y" : -636.5517317957774
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CSUDHCalFresh",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CSUDHCalFresh",
        "SelfLoops" : 0,
        "SUID" : 555,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -291.15216189759076,
        "y" : -747.0021598048106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "adaycsu",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "adaycsu",
        "SelfLoops" : 0,
        "SUID" : 554,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -362.4021924151689,
        "y" : -735.8764311976329
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sea_science_sam",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "sea_science_sam",
        "SelfLoops" : 0,
        "SUID" : 553,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 20.0
      },
      "position" : {
        "x" : -149.435181917122,
        "y" : -822.5288665003673
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "552",
        "ClosenessCentrality" : 0.5454545454545455,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LACountyDHR",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "LACountyDHR",
        "SelfLoops" : 0,
        "SUID" : 552,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8333333333333333,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 369.0165240154952,
        "y" : -2483.978391379823
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "qniteowl",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "qniteowl",
        "SelfLoops" : 0,
        "SUID" : 551,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 278.9923540936202,
        "y" : -2405.4615142054454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "socalifrose",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "socalifrose",
        "SelfLoops" : 0,
        "SUID" : 550,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 339.1186968670577,
        "y" : -2594.7812850184337
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hennylion",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "hennylion",
        "SelfLoops" : 0,
        "SUID" : 549,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 371.9604937420577,
        "y" : -2546.36341926526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LACountyBOS",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LACountyBOS",
        "SelfLoops" : 0,
        "SUID" : 548,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 343.4355913983077,
        "y" : -2426.701611251344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CoachDenele",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CoachDenele",
        "SelfLoops" : 0,
        "SUID" : 547,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : 277.9222857342452,
        "y" : -2629.3031127161876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ccald1014",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ccald1014",
        "SelfLoops" : 0,
        "SUID" : 546,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -13.031571687629821,
        "y" : -2963.1016967005626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EvaMa02543471",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "EvaMa02543471",
        "SelfLoops" : 0,
        "SUID" : 545,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 98.77897518737018,
        "y" : -2775.586682052125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "544",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jennpruitt3",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jennpruitt3",
        "SelfLoops" : 0,
        "SUID" : 544,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -13.892167390754821,
        "y" : -2698.5677001185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 11957,
        "shared_name" : "LBSchools",
        "BetweennessCentrality" : 0.07200582935877053,
        "EdgeCount" : 12,
        "Indegree" : 1,
        "name" : "LBSchools",
        "SelfLoops" : 0,
        "SUID" : 543,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.3333333333333335
      },
      "position" : {
        "x" : 289.0557085858077,
        "y" : -2957.7892272181407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 10870,
        "shared_name" : "longbeachbobby",
        "BetweennessCentrality" : 0.06545984487160958,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "longbeachbobby",
        "SelfLoops" : 0,
        "SUID" : 542,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 14.0
      },
      "position" : {
        "x" : -93.50312930481732,
        "y" : -3048.980419845094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Alma_LBC",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Alma_LBC",
        "SelfLoops" : 0,
        "SUID" : 541,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -85.71516543762982,
        "y" : -2949.723431319703
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RaCuevas",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "RaCuevas",
        "SelfLoops" : 0,
        "SUID" : 540,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 52.41386288268268,
        "y" : -2925.6975829310313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ReynoldsDoGood",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ReynoldsDoGood",
        "SelfLoops" : 0,
        "SUID" : 539,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 94.78507870299518,
        "y" : -2850.0413939661876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TimMajka",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TimMajka",
        "SelfLoops" : 0,
        "SUID" : 538,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 32.89066952330768,
        "y" : -2864.0157286829844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LawleyWindy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LawleyWindy",
        "SelfLoops" : 0,
        "SUID" : 537,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 37.99381893737018,
        "y" : -2786.6253783411876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kathrynwith5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kathrynwith5",
        "SelfLoops" : 0,
        "SUID" : 536,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 51.75627010924518,
        "y" : -2714.6966826624766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "trigonis30",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "trigonis30",
        "SelfLoops" : 0,
        "SUID" : 535,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -138.05049258606732,
        "y" : -2914.5236022181407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "534",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mstaylorboone",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mstaylorboone",
        "SelfLoops" : 0,
        "SUID" : 534,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : -27.89058047669232,
        "y" : -2903.1373412318126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LBCityAuditor",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LBCityAuditor",
        "SelfLoops" : 0,
        "SUID" : 494,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : -446.2292035235673,
        "y" : -2589.411114425172
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 2402,
        "shared_name" : "TheCCLB",
        "BetweennessCentrality" : 0.009015031073854604,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "TheCCLB",
        "SelfLoops" : 0,
        "SUID" : 493,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -259.1564496173173,
        "y" : -2605.5912291712657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MrsLongBeachLB",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MrsLongBeachLB",
        "SelfLoops" : 0,
        "SUID" : 492,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 443.0038287029952,
        "y" : -3023.1197631068126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cgomez61D",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "cgomez61D",
        "SelfLoops" : 0,
        "SUID" : 491,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 391.2690874920577,
        "y" : -3093.253430099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "shopgirlatsando",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "shopgirlatsando",
        "SelfLoops" : 0,
        "SUID" : 490,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 386.0166460858077,
        "y" : -2858.485821456422
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "senorhdz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "senorhdz",
        "SelfLoops" : 0,
        "SUID" : 489,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 435.8251177654952,
        "y" : -2895.181866378297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SBStitching",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SBStitching",
        "SelfLoops" : 0,
        "SUID" : 488,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 262.7566363201827,
        "y" : -3094.0930907435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "myrnasword17",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "myrnasword17",
        "SelfLoops" : 0,
        "SUID" : 487,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 374.7501665936202,
        "y" : -3030.5933348841563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "486",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LeonerPerez",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LeonerPerez",
        "SelfLoops" : 0,
        "SUID" : 486,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 214.44633358580768,
        "y" : -3042.0830809779063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LBSchoolsTV",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LBSchoolsTV",
        "SelfLoops" : 0,
        "SUID" : 485,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 310.9281451092452,
        "y" : -2845.0955626673594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "484",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "megankerr",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "megankerr",
        "SelfLoops" : 0,
        "SUID" : 484,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 324.1797320233077,
        "y" : -3092.4215209193126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SteinbergJinky",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SteinbergJinky",
        "SelfLoops" : 0,
        "SUID" : 483,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 391.9300982342452,
        "y" : -2951.5250365443126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AcademyPowell",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AcademyPowell",
        "SelfLoops" : 0,
        "SUID" : 482,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : 457.0303179608077,
        "y" : -2961.790783614625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 15003,
        "shared_name" : "LBCityCollege",
        "BetweennessCentrality" : 0.09034903887845065,
        "EdgeCount" : 11,
        "Indegree" : 2,
        "name" : "LBCityCollege",
        "SelfLoops" : 0,
        "SUID" : 481,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.1818181818181819
      },
      "position" : {
        "x" : -131.58357364075482,
        "y" : -3255.8140990443126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "480",
        "ClosenessCentrality" : 0.5014577259475219,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ancydana",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ancydana",
        "SelfLoops" : 0,
        "SUID" : 480,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.994186046511628,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1989.4270184649736,
        "y" : -1463.3705565638438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 171,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 43947,
        "shared_name" : "toozurnt",
        "BetweennessCentrality" : 0.26465168376933085,
        "EdgeCount" : 172,
        "Indegree" : 1,
        "name" : "toozurnt",
        "SelfLoops" : 0,
        "SUID" : 479,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.005813953488372
      },
      "position" : {
        "x" : -1721.8747113360673,
        "y" : -1652.941662520875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "perla_flores_pf",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "perla_flores_pf",
        "SelfLoops" : 0,
        "SUID" : 478,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1486.884660066536,
        "y" : -1813.1766478724376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ghostliegh",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ghostliegh",
        "SelfLoops" : 0,
        "SUID" : 477,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1502.7404339923173,
        "y" : -1613.327648849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ariana_papi",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ariana_papi",
        "SelfLoops" : 0,
        "SUID" : 476,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1690.698624910286,
        "y" : -1507.5098998255626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HeyMrKarma",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HeyMrKarma",
        "SelfLoops" : 0,
        "SUID" : 475,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1800.4850628985673,
        "y" : -1544.5399291224376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mayrapollo4",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mayrapollo4",
        "SelfLoops" : 0,
        "SUID" : 474,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1710.854142488411,
        "y" : -1828.1566283411876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "k0nnichiwaneko",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "k0nnichiwaneko",
        "SelfLoops" : 0,
        "SUID" : 473,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1568.0843976153642,
        "y" : -1474.3734862513438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "472",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "youarelovely95",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "youarelovely95",
        "SelfLoops" : 0,
        "SUID" : 472,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1612.8672345294267,
        "y" : -1778.7967040247813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ncityquin",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ncityquin",
        "SelfLoops" : 0,
        "SUID" : 471,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1716.4299481524736,
        "y" : -1474.3213622279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lilyyxm",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lilyyxm",
        "SelfLoops" : 0,
        "SUID" : 470,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1985.5907757891923,
        "y" : -1699.275646895875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sydneyrfrank",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sydneyrfrank",
        "SelfLoops" : 0,
        "SUID" : 469,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1550.8549054278642,
        "y" : -1552.9356810755626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "468",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DrewTosch",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DrewTosch",
        "SelfLoops" : 0,
        "SUID" : 468,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1757.8638470782548,
        "y" : -1464.3076903529063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Shes_RuRuu",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Shes_RuRuu",
        "SelfLoops" : 0,
        "SUID" : 467,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1812.4400189532548,
        "y" : -1954.5355345911876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "466",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KaitlynMelgoza",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KaitlynMelgoza",
        "SelfLoops" : 0,
        "SUID" : 466,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1427.1769574298173,
        "y" : -1739.461682052125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "knuckifyoubuckb",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "knuckifyoubuckb",
        "SelfLoops" : 0,
        "SUID" : 465,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1634.490128816536,
        "y" : -1450.8815428919688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sol_pythonissam",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sol_pythonissam",
        "SelfLoops" : 0,
        "SUID" : 464,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1645.848985017708,
        "y" : -1879.3223387904063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rejuvenatedcat",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "rejuvenatedcat",
        "SelfLoops" : 0,
        "SUID" : 463,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1400.3809521807939,
        "y" : -1688.607678145875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DanteSignorelli",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DanteSignorelli",
        "SelfLoops" : 0,
        "SUID" : 462,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1596.6240399493486,
        "y" : -1440.2495848841563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "caite_coal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "caite_coal",
        "SelfLoops" : 0,
        "SUID" : 461,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1721.075822175911,
        "y" : -1546.9358641810313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "blinkotwinko",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "blinkotwinko",
        "SelfLoops" : 0,
        "SUID" : 460,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -2019.111710847786,
        "y" : -1513.6741454310313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MissObtas",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MissObtas",
        "SelfLoops" : 0,
        "SUID" : 459,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1638.4931805743486,
        "y" : -1333.8075682825938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "claudiat1997",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "claudiat1997",
        "SelfLoops" : 0,
        "SUID" : 458,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1611.4513714923173,
        "y" : -1942.4066893763438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kieleevans",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kieleevans",
        "SelfLoops" : 0,
        "SUID" : 457,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1446.798936189583,
        "y" : -1583.727307052125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Rayperez88",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Rayperez88",
        "SelfLoops" : 0,
        "SUID" : 456,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1894.779191316536,
        "y" : -1497.2418334193126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Iridescent_Rose",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Iridescent_Rose",
        "SelfLoops" : 0,
        "SUID" : 455,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1797.7091839923173,
        "y" : -1589.6819579310313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AB_Owl",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AB_Owl",
        "SelfLoops" : 0,
        "SUID" : 454,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1929.7187665118486,
        "y" : -1796.9143798060313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SophieStarshine",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SophieStarshine",
        "SelfLoops" : 0,
        "SUID" : 453,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1916.209611238411,
        "y" : -1622.657726974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "reneeweeenie",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "reneeweeenie",
        "SelfLoops" : 0,
        "SUID" : 452,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1663.4505170001298,
        "y" : -1416.2943846888438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "curlytoplex",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "curlytoplex",
        "SelfLoops" : 0,
        "SUID" : 451,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1690.958634675911,
        "y" : -1875.4149291224376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ayemevo",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ayemevo",
        "SelfLoops" : 0,
        "SUID" : 450,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1892.1214154376298,
        "y" : -1822.7401244349376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ayelookitsBRADY",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ayelookitsBRADY",
        "SelfLoops" : 0,
        "SUID" : 449,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1759.7372601641923,
        "y" : -1905.22462150525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "maniawentz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "maniawentz",
        "SelfLoops" : 0,
        "SUID" : 448,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1733.7492840899736,
        "y" : -1342.7354247279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jheiny_doeyy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jheiny_doeyy",
        "SelfLoops" : 0,
        "SUID" : 447,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1502.1426556720048,
        "y" : -1480.5474974818126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "iqranoor1D",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "iqranoor1D",
        "SelfLoops" : 0,
        "SUID" : 446,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1686.3567059649736,
        "y" : -1325.7564208216563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KNOWASONG",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KNOWASONG",
        "SelfLoops" : 0,
        "SUID" : 445,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1492.1028607501298,
        "y" : -1866.9324462122813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "laylay123123",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "laylay123123",
        "SelfLoops" : 0,
        "SUID" : 444,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1839.846574129036,
        "y" : -1568.1948973841563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rowzee_b",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "rowzee_b",
        "SelfLoops" : 0,
        "SUID" : 443,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1558.5329754962236,
        "y" : -1916.8905760950938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "livdelro10",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "livdelro10",
        "SelfLoops" : 0,
        "SUID" : 442,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1900.435197175911,
        "y" : -1373.2981688685313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "NostalgicVinyls",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "NostalgicVinyls",
        "SelfLoops" : 0,
        "SUID" : 441,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1713.4219525470048,
        "y" : -1910.9569213099376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "atrocioous",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "atrocioous",
        "SelfLoops" : 0,
        "SUID" : 440,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1834.398820222786,
        "y" : -1433.5976073450938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Aestheticbangt4",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Aestheticbangt4",
        "SelfLoops" : 0,
        "SUID" : 439,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1932.7106488360673,
        "y" : -1563.3256346888438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ElfGrove",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ElfGrove",
        "SelfLoops" : 0,
        "SUID" : 438,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1877.6223309649736,
        "y" : -1702.6510131068126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "brown_enchilada",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "brown_enchilada",
        "SelfLoops" : 0,
        "SUID" : 437,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1863.4243329180986,
        "y" : -1407.0373046107188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bmorrisseyxo",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bmorrisseyxo",
        "SelfLoops" : 0,
        "SUID" : 436,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1493.4352887286454,
        "y" : -1565.58985588025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jennperez828",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jennperez828",
        "SelfLoops" : 0,
        "SUID" : 435,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1836.074845613411,
        "y" : -1612.5341307825938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wild_flowerbaby",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "wild_flowerbaby",
        "SelfLoops" : 0,
        "SUID" : 434,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1908.498429597786,
        "y" : -1903.5883910365
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Mighterbump",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Mighterbump",
        "SelfLoops" : 0,
        "SUID" : 433,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1902.1023114337236,
        "y" : -1744.1778685755626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dudeitsrosie_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dudeitsrosie_",
        "SelfLoops" : 0,
        "SUID" : 432,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1624.939072908333,
        "y" : -1497.1209227747813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kylaakakess",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kylaakakess",
        "SelfLoops" : 0,
        "SUID" : 431,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1857.572404207161,
        "y" : -1748.9505736536876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DALIZZZL",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DALIZZZL",
        "SelfLoops" : 0,
        "SUID" : 430,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1461.9918988360673,
        "y" : -1526.4360472865
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "melonpuerto",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "melonpuerto",
        "SelfLoops" : 0,
        "SUID" : 429,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1475.6416180743486,
        "y" : -1443.2416503138438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dani_miyerah98",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dani_miyerah98",
        "SelfLoops" : 0,
        "SUID" : 428,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1438.8081219805986,
        "y" : -1483.8727538294688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "janinearratia",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "janinearratia",
        "SelfLoops" : 0,
        "SUID" : 427,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1633.6747296466142,
        "y" : -1589.7374999232188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "THEEBrittney",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "THEEBrittney",
        "SelfLoops" : 0,
        "SUID" : 426,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1434.3935406817704,
        "y" : -1662.219494552125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "xoxo_ayleenn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "xoxo_ayleenn",
        "SelfLoops" : 0,
        "SUID" : 425,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1614.4811871661454,
        "y" : -1729.5609862513438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Chon_95",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Chon_95",
        "SelfLoops" : 0,
        "SUID" : 424,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1977.1303265704423,
        "y" : -1848.6087767786876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kate_zendejas",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kate_zendejas",
        "SelfLoops" : 0,
        "SUID" : 423,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1952.8271649493486,
        "y" : -1597.8286254115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "azhanique__",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "azhanique__",
        "SelfLoops" : 0,
        "SUID" : 422,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1851.7819378985673,
        "y" : -1482.3878295130626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "josepalma127",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "josepalma127",
        "SelfLoops" : 0,
        "SUID" : 421,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1499.611466707161,
        "y" : -1698.5037352747813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "coolcatcaro",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "coolcatcaro",
        "SelfLoops" : 0,
        "SUID" : 420,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1939.9821942462236,
        "y" : -1466.1352050013438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dumbomato",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dumbomato",
        "SelfLoops" : 0,
        "SUID" : 419,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1699.9112103595048,
        "y" : -1437.1736571497813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Ninjanyiah16",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Ninjanyiah16",
        "SelfLoops" : 0,
        "SUID" : 418,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1739.6997235430986,
        "y" : -1507.8326537318126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Xo_Jenzziee_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Xo_Jenzziee_",
        "SelfLoops" : 0,
        "SUID" : 417,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1437.139512361458,
        "y" : -1800.6720702357188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "catbroooks",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "catbroooks",
        "SelfLoops" : 0,
        "SUID" : 416,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1530.5690777911454,
        "y" : -1781.2738768763438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "maexrene",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "maexrene",
        "SelfLoops" : 0,
        "SUID" : 415,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1576.3882306231767,
        "y" : -1659.209240645875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mistyhennelly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mistyhennelly",
        "SelfLoops" : 0,
        "SUID" : 414,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1545.2488568438798,
        "y" : -1733.391369552125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "meilaniyatco",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "meilaniyatco",
        "SelfLoops" : 0,
        "SUID" : 413,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1458.0204632891923,
        "y" : -1623.9556395716563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "briannugh14",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "briannugh14",
        "SelfLoops" : 0,
        "SUID" : 412,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1415.4165509356767,
        "y" : -1545.3303954310313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ohmymonteen",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ohmymonteen",
        "SelfLoops" : 0,
        "SUID" : 411,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1803.8191693438798,
        "y" : -1909.84864494275
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "_LXVIII",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "_LXVIII",
        "SelfLoops" : 0,
        "SUID" : 410,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1759.978898347786,
        "y" : -1829.093029708375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "msangiesegura",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "msangiesegura",
        "SelfLoops" : 0,
        "SUID" : 409,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1585.320176423958,
        "y" : -1854.9766967005626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "S__Clough",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "S__Clough",
        "SelfLoops" : 0,
        "SUID" : 408,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1801.582902254036,
        "y" : -1458.3655516810313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jackie_r08",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jackie_r08",
        "SelfLoops" : 0,
        "SUID" : 407,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1621.8977521075517,
        "y" : -1830.919689864625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ngleon95",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ngleon95",
        "SelfLoops" : 0,
        "SUID" : 406,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1992.5902875079423,
        "y" : -1613.8001830286876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "swanfaery",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "swanfaery",
        "SelfLoops" : 0,
        "SUID" : 405,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -2050.3608563555986,
        "y" : -1671.0237548060313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "teabyrosie",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "teabyrosie",
        "SelfLoops" : 0,
        "SUID" : 404,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1622.866807283333,
        "y" : -1643.9733397669688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ewwitsirina",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ewwitsirina",
        "SelfLoops" : 0,
        "SUID" : 403,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1819.6740277423173,
        "y" : -1388.2709471888438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "inmanlauren",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "inmanlauren",
        "SelfLoops" : 0,
        "SUID" : 402,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1669.726212800911,
        "y" : -1839.8793456263438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "victorheras352",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "victorheras352",
        "SelfLoops" : 0,
        "SUID" : 401,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1707.9008343829423,
        "y" : -1737.8185546107188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "_abigail_irene_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "_abigail_irene_",
        "SelfLoops" : 0,
        "SUID" : 400,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1932.1851361407548,
        "y" : -1514.237072677125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "VILNILLA",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "VILNILLA",
        "SelfLoops" : 0,
        "SUID" : 399,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -2030.083390535286,
        "y" : -1721.0584838099376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EARBlSCUlTS",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "EARBlSCUlTS",
        "SelfLoops" : 0,
        "SUID" : 398,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1751.303849519661,
        "y" : -1960.2192504115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ohhhh_nicole",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ohhhh_nicole",
        "SelfLoops" : 0,
        "SUID" : 397,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1577.9685834063798,
        "y" : -1762.5229003138438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sh0vonn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sh0vonn",
        "SelfLoops" : 0,
        "SUID" : 396,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1940.9597943438798,
        "y" : -1753.9270751185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "braxtynn_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "braxtynn_",
        "SelfLoops" : 0,
        "SUID" : 395,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1831.890763582161,
        "y" : -1790.0138671107188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nyacosmet",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "nyacosmet",
        "SelfLoops" : 0,
        "SUID" : 394,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1789.8904584063798,
        "y" : -1731.4739501185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SeanMatsukawa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SeanMatsukawa",
        "SelfLoops" : 0,
        "SUID" : 393,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1587.9047711505204,
        "y" : -1519.1791503138438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sarahmccanny",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sarahmccanny",
        "SelfLoops" : 0,
        "SUID" : 392,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1759.356339754036,
        "y" : -1571.1569335169688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Jaaaadeeee18",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Jaaaadeeee18",
        "SelfLoops" : 0,
        "SUID" : 391,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1668.9469769610673,
        "y" : -1711.8963133997813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "OGstussyington",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "OGstussyington",
        "SelfLoops" : 0,
        "SUID" : 390,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1806.350480379036,
        "y" : -1334.5852782435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "McDaPiCk",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "McDaPiCk",
        "SelfLoops" : 0,
        "SUID" : 389,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1492.2038128985673,
        "y" : -1658.3166014857188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "shamsa_samiya",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "shamsa_samiya",
        "SelfLoops" : 0,
        "SUID" : 388,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1740.7270672930986,
        "y" : -1865.2906005091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sarynaaa_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sarynaaa_",
        "SelfLoops" : 0,
        "SUID" : 387,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1693.1875775470048,
        "y" : -1585.5796630091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "browneyedhoneyy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "browneyedhoneyy",
        "SelfLoops" : 0,
        "SUID" : 386,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1457.2078412188798,
        "y" : -1704.4053466029063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rinnieie",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "rinnieie",
        "SelfLoops" : 0,
        "SUID" : 385,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1832.551163972786,
        "y" : -1722.9193846888438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AcaciaEgo",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AcaciaEgo",
        "SelfLoops" : 0,
        "SUID" : 384,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1652.6320050372392,
        "y" : -1797.705334395875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cafedekoya",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "cafedekoya",
        "SelfLoops" : 0,
        "SUID" : 383,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1898.4132855548173,
        "y" : -1662.5489012904063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "yeampp",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "yeampp",
        "SelfLoops" : 0,
        "SUID" : 382,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1694.8412640704423,
        "y" : -1780.1767089075938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "umnayadevushka",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "umnayadevushka",
        "SelfLoops" : 0,
        "SUID" : 381,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1748.3325360430986,
        "y" : -1757.5087401575938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FixxieeYeshh",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FixxieeYeshh",
        "SelfLoops" : 0,
        "SUID" : 380,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1400.9580243243486,
        "y" : -1608.3828856654063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Goon_Donovan23",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Goon_Donovan23",
        "SelfLoops" : 0,
        "SUID" : 379,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1738.966691316536,
        "y" : -1797.4708373255626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "viaxshine_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "viaxshine_",
        "SelfLoops" : 0,
        "SUID" : 378,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1888.6227582110673,
        "y" : -1452.7313964075938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jjlejetpain",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jjlejetpain",
        "SelfLoops" : 0,
        "SUID" : 377,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1782.2720502032548,
        "y" : -1415.9452635950938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "astroreefer",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "astroreefer",
        "SelfLoops" : 0,
        "SUID" : 376,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1912.9709637774736,
        "y" : -1414.2902342982188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Luv_yuhz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Luv_yuhz",
        "SelfLoops" : 0,
        "SUID" : 375,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1635.192521394661,
        "y" : -1531.4773680872813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "taylorjeanexox",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "taylorjeanexox",
        "SelfLoops" : 0,
        "SUID" : 374,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1886.5590985430986,
        "y" : -1586.039318770875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TwoHispanic",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TwoHispanic",
        "SelfLoops" : 0,
        "SUID" : 373,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1796.0613568438798,
        "y" : -1864.1989257044688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tbabii142",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "tbabii142",
        "SelfLoops" : 0,
        "SUID" : 372,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1794.194474519661,
        "y" : -1635.6493041224376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "karlitazway_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "karlitazway_",
        "SelfLoops" : 0,
        "SUID" : 371,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1848.973527254036,
        "y" : -1671.21485588025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "justlynes",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "justlynes",
        "SelfLoops" : 0,
        "SUID" : 370,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1668.8765423907548,
        "y" : -1371.3081786341563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "r_stefany25",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "r_stefany25",
        "SelfLoops" : 0,
        "SUID" : 369,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1876.3727582110673,
        "y" : -1784.6869017786876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "curlyyonce",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "curlyyonce",
        "SelfLoops" : 0,
        "SUID" : 368,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1566.9964154376298,
        "y" : -1407.3859374232188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "samnoefab",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "samnoefab",
        "SelfLoops" : 0,
        "SUID" : 367,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1675.3533490313798,
        "y" : -1546.204846114625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "_elizettg",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "_elizettg",
        "SelfLoops" : 0,
        "SUID" : 366,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1509.8837445391923,
        "y" : -1406.0546385950938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "toriansharri",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "toriansharri",
        "SelfLoops" : 0,
        "SUID" : 365,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -2035.2157757891923,
        "y" : -1565.4452025599376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CadiaAlexander",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CadiaAlexander",
        "SelfLoops" : 0,
        "SUID" : 364,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1695.5301068438798,
        "y" : -1962.51075431775
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "XOXO_Yeni",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "XOXO_Yeni",
        "SelfLoops" : 0,
        "SUID" : 363,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1598.391740144661,
        "y" : -1563.1194579310313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "xsimplyruby",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "xsimplyruby",
        "SelfLoops" : 0,
        "SUID" : 362,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1543.7904828204423,
        "y" : -1627.000744552125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Dy_Lejoi",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Dy_Lejoi",
        "SelfLoops" : 0,
        "SUID" : 361,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1584.6458295001298,
        "y" : -1616.6315428919688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "meraizzlee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "meraizzlee",
        "SelfLoops" : 0,
        "SUID" : 360,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1541.5283368243486,
        "y" : -1365.4966551966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "danaaeelaishaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "danaaeelaishaa",
        "SelfLoops" : 0,
        "SUID" : 359,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1812.0133832110673,
        "y" : -1681.59473869275
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "juliololololol",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "juliololololol",
        "SelfLoops" : 0,
        "SUID" : 358,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1541.8064435138017,
        "y" : -1869.536389083375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KevenG310",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KevenG310",
        "SelfLoops" : 0,
        "SUID" : 357,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1877.8787396563798,
        "y" : -1866.658947677125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ator2403",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ator2403",
        "SelfLoops" : 0,
        "SUID" : 356,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1835.5921185626298,
        "y" : -1879.4732787318126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jaackkayy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jaackkayy",
        "SelfLoops" : 0,
        "SUID" : 355,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1657.2895367755204,
        "y" : -1614.4984862513438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "giselxromero",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "giselxromero",
        "SelfLoops" : 0,
        "SUID" : 354,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1501.7242901934892,
        "y" : -1739.3895384974376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "simplet0nnn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "simplet0nnn",
        "SelfLoops" : 0,
        "SUID" : 353,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1575.6342938555986,
        "y" : -1806.9576537318126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ashlexlameass",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ashlexlameass",
        "SelfLoops" : 0,
        "SUID" : 352,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1959.667863191536,
        "y" : -1651.4533202357188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "axgelaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "axgelaa",
        "SelfLoops" : 0,
        "SUID" : 351,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1795.9344037188798,
        "y" : -1819.1045653529063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jazmyne_17",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jazmyne_17",
        "SelfLoops" : 0,
        "SUID" : 350,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1615.041886629036,
        "y" : -1688.0708129115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "eroj7",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "eroj7",
        "SelfLoops" : 0,
        "SUID" : 349,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -2052.1393597735673,
        "y" : -1611.3252684779063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mo_xuanyun",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mo_xuanyun",
        "SelfLoops" : 0,
        "SUID" : 348,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1976.7556927813798,
        "y" : -1801.5269896693126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ashhh_leeey_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ashhh_leeey_",
        "SelfLoops" : 0,
        "SUID" : 347,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1819.3589032305986,
        "y" : -1502.2106444544688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "myia_papayaaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "myia_papayaaa",
        "SelfLoops" : 0,
        "SUID" : 346,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1982.2016156329423,
        "y" : -1561.2661254115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Laniii_valencia",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Laniii_valencia",
        "SelfLoops" : 0,
        "SUID" : 345,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1937.1244671954423,
        "y" : -1679.1541258997813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "celestiall18",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "celestiall18",
        "SelfLoops" : 0,
        "SUID" : 344,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1857.8672650470048,
        "y" : -1350.4202391810313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bexxalo",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bexxalo",
        "SelfLoops" : 0,
        "SUID" : 343,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1794.4523480548173,
        "y" : -1772.2555052943126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "capracity",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "capracity",
        "SelfLoops" : 0,
        "SUID" : 342,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1536.6298382891923,
        "y" : -1676.8197142786876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "angelicaalexis_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "angelicaalexis_",
        "SelfLoops" : 0,
        "SUID" : 341,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1660.2451336993486,
        "y" : -1928.5216185755626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "deanjoys",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "deanjoys",
        "SelfLoops" : 0,
        "SUID" : 340,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1842.149064363411,
        "y" : -1833.9452025599376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "__Cinnabunns",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "__Cinnabunns",
        "SelfLoops" : 0,
        "SUID" : 339,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -2004.459367097786,
        "y" : -1656.45899650525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "garcia_dessire",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "garcia_dessire",
        "SelfLoops" : 0,
        "SUID" : 338,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1931.7802289141923,
        "y" : -1857.3170287318126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "h2henderson",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "h2henderson",
        "SelfLoops" : 0,
        "SUID" : 337,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1734.4873822345048,
        "y" : -1701.964123458375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DestinyFletch13",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DestinyFletch13",
        "SelfLoops" : 0,
        "SUID" : 336,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1963.9507611407548,
        "y" : -1412.4363524622813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "savannah_frenes",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "savannah_frenes",
        "SelfLoops" : 0,
        "SUID" : 335,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1773.619279207161,
        "y" : -1683.604992599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "WichotheArtist",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "WichotheArtist",
        "SelfLoops" : 0,
        "SUID" : 334,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1654.1013348712236,
        "y" : -1753.491711349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ryuusea_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ryuusea_",
        "SelfLoops" : 0,
        "SUID" : 333,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1530.6731732501298,
        "y" : -1824.2722899622813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FknCrls",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FknCrls",
        "SelfLoops" : 0,
        "SUID" : 332,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1546.4102337970048,
        "y" : -1514.7647826380626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "imanikirksy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "imanikirksy",
        "SelfLoops" : 0,
        "SUID" : 331,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1602.7648175372392,
        "y" : -1895.9856688685313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "elysemariev",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "elysemariev",
        "SelfLoops" : 0,
        "SUID" : 330,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1553.4142315997392,
        "y" : -1586.941174239625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "perfectpree",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "perfectpree",
        "SelfLoops" : 0,
        "SUID" : 329,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1863.1060345782548,
        "y" : -1926.4998290247813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "keywilliamss",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "keywilliamss",
        "SelfLoops" : 0,
        "SUID" : 328,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1537.173692048958,
        "y" : -1446.9134032435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "brendiittaaaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "brendiittaaaa",
        "SelfLoops" : 0,
        "SUID" : 327,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1594.330186189583,
        "y" : -1345.5243651575938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ssimosa_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ssimosa_",
        "SelfLoops" : 0,
        "SUID" : 326,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1767.2908490313798,
        "y" : -1377.2820555872813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "hannah_peskoff5",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "hannah_peskoff5",
        "SelfLoops" : 0,
        "SUID" : 325,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1620.0248273028642,
        "y" : -1394.0684325404063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jorge_huertao",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jorge_huertao",
        "SelfLoops" : 0,
        "SUID" : 324,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1872.5849164141923,
        "y" : -1626.3356444544688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "rebe_duraan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "rebe_duraan",
        "SelfLoops" : 0,
        "SUID" : 323,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1740.0465863360673,
        "y" : -1420.3802001185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "gaymomm",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "gaymomm",
        "SelfLoops" : 0,
        "SUID" : 322,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1851.7772992266923,
        "y" : -1532.5003783411876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "awwdawg",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "awwdawg",
        "SelfLoops" : 0,
        "SUID" : 321,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1897.125871004036,
        "y" : -1541.8722655482188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Ya_sammm",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Ya_sammm",
        "SelfLoops" : 0,
        "SUID" : 320,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1572.314103425911,
        "y" : -1705.0669066615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EL_DUCkYZ",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "EL_DUCkYZ",
        "SelfLoops" : 0,
        "SUID" : 319,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1710.4516766680986,
        "y" : -1384.2965819544688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sunflowersugarx",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sunflowersugarx",
        "SelfLoops" : 0,
        "SUID" : 318,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1472.0951398028642,
        "y" : -1766.4940917200938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "__oatmilk",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "__oatmilk",
        "SelfLoops" : 0,
        "SUID" : 317,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1755.366349519661,
        "y" : -1305.2749755091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "babymaebee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "babymaebee",
        "SelfLoops" : 0,
        "SUID" : 316,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1508.951554597786,
        "y" : -1527.284680099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "_osnapitzjess",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "_osnapitzjess",
        "SelfLoops" : 0,
        "SUID" : 315,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1779.5729535235673,
        "y" : -1507.1881224818126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "desslyy_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "desslyy_",
        "SelfLoops" : 0,
        "SUID" : 314,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1981.7057660235673,
        "y" : -1746.560070724
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bbydiosaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bbydiosaa",
        "SelfLoops" : 0,
        "SUID" : 313,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1663.7595379962236,
        "y" : -1670.108166427125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TheLifeOfMich_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "TheLifeOfMich_",
        "SelfLoops" : 0,
        "SUID" : 312,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1973.794328035286,
        "y" : -1512.874767989625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "cheesymacaroni_",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "cheesymacaroni_",
        "SelfLoops" : 0,
        "SUID" : 311,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -2026.1403363360673,
        "y" : -1778.511486739625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "camacho_248",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "camacho_248",
        "SelfLoops" : 0,
        "SUID" : 310,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1931.6143353595048,
        "y" : -1714.4608885950938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "amayrannni",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "amayrannni",
        "SelfLoops" : 0,
        "SUID" : 309,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 172.0
      },
      "position" : {
        "x" : -1668.303117097786,
        "y" : -1474.8897216029063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 93,
        "shared_name" : "PresConoley",
        "BetweennessCentrality" : 0.05400696864111498,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "PresConoley",
        "SelfLoops" : 0,
        "SUID" : 308,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.75
      },
      "position" : {
        "x" : -486.4649365557939,
        "y" : -460.75816032360945
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CSULB",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CSULB",
        "SelfLoops" : 0,
        "SUID" : 307,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -574.1842358722001,
        "y" : -377.74036857556257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 852,
        "shared_name" : "MaryZendejasLB",
        "BetweennessCentrality" : 0.005130799248446308,
        "EdgeCount" : 3,
        "Indegree" : 1,
        "name" : "MaryZendejasLB",
        "SelfLoops" : 0,
        "SUID" : 306,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -464.69044619934857,
        "y" : -2965.730450362672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 742,
        "shared_name" : "LongBeachFresh",
        "BetweennessCentrality" : 0.004468372115430939,
        "EdgeCount" : 3,
        "Indegree" : 2,
        "name" : "LongBeachFresh",
        "SelfLoops" : 0,
        "SUID" : 305,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.6666666666666667
      },
      "position" : {
        "x" : -640.3701642169267,
        "y" : -2894.1984069056407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "ClosenessCentrality" : 0.5038167938931297,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ToniRagusa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "ToniRagusa",
        "SelfLoops" : 0,
        "SUID" : 304,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9848484848484849,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1107.291570009163,
        "y" : -3596.459179610719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MikePhilbrick2",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MikePhilbrick2",
        "SelfLoops" : 0,
        "SUID" : 303,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1019.7737744464189,
        "y" : -3793.8401610560313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CharlieInUtah",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CharlieInUtah",
        "SelfLoops" : 0,
        "SUID" : 302,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1211.1634610308915,
        "y" : -3920.518505782594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CharlesPumilia",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CharlesPumilia",
        "SelfLoops" : 0,
        "SUID" : 301,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1063.4328320636064,
        "y" : -3631.8223387904063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Stone1ML",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Stone1ML",
        "SelfLoops" : 0,
        "SUID" : 300,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1243.4977429522783,
        "y" : -3765.917919845094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "1jasliz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "1jasliz",
        "SelfLoops" : 0,
        "SUID" : 299,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1007.4071972979814,
        "y" : -3941.2586180872813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AnnieMartin5353",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AnnieMartin5353",
        "SelfLoops" : 0,
        "SUID" : 298,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1090.0034459246904,
        "y" : -3492.663342208375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BradStarks",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BradStarks",
        "SelfLoops" : 0,
        "SUID" : 297,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1006.7766736163408,
        "y" : -3742.5947997279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Kane007",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Kane007",
        "SelfLoops" : 0,
        "SUID" : 296,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1034.3836606158525,
        "y" : -3507.740673751344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "zannerina",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "zannerina",
        "SelfLoops" : 0,
        "SUID" : 295,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -991.1136639727861,
        "y" : -3888.810253829469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "frankie5563",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "frankie5563",
        "SelfLoops" : 0,
        "SUID" : 294,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1012.4610760821611,
        "y" : -3842.642529220094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AaarUci",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AaarUci",
        "SelfLoops" : 0,
        "SUID" : 293,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -940.7600873126298,
        "y" : -3906.6575438685313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "genevieveisgg",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "genevieveisgg",
        "SelfLoops" : 0,
        "SUID" : 292,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -956.8320172442704,
        "y" : -3724.169140548219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "StacyBierlein",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "StacyBierlein",
        "SelfLoops" : 0,
        "SUID" : 291,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1167.3918145312578,
        "y" : -3695.6145751185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DeidreFolkman",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DeidreFolkman",
        "SelfLoops" : 0,
        "SUID" : 290,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -928.6848920001298,
        "y" : -3555.486767501344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HearMeRoar53881",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "HearMeRoar53881",
        "SelfLoops" : 0,
        "SUID" : 289,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1045.1900723590165,
        "y" : -3890.8157469935313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LTSwrite",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LTSwrite",
        "SelfLoops" : 0,
        "SUID" : 288,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1223.276620210579,
        "y" : -3705.995312423219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "halest793",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "halest793",
        "SelfLoops" : 0,
        "SUID" : 287,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -883.2487652911454,
        "y" : -3598.5218016810313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JNicole1979",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JNicole1979",
        "SelfLoops" : 0,
        "SUID" : 286,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1086.7512334002763,
        "y" : -3543.3299071497813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "diamondnill1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "diamondnill1",
        "SelfLoops" : 0,
        "SUID" : 285,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1098.0064786090165,
        "y" : -3915.7967040247813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kerrterrpg",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kerrterrpg",
        "SelfLoops" : 0,
        "SUID" : 284,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -994.242554963997,
        "y" : -3566.0115477747813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "WeTheSisters",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "WeTheSisters",
        "SelfLoops" : 0,
        "SUID" : 283,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -906.840195955208,
        "y" : -3702.269482345094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LolaGLR",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LolaGLR",
        "SelfLoops" : 0,
        "SUID" : 282,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1287.8845379962236,
        "y" : -3608.227490157594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bjack417",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bjack417",
        "SelfLoops" : 0,
        "SUID" : 281,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1158.4450219287187,
        "y" : -3857.2493407435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kellyswanholm",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kellyswanholm",
        "SelfLoops" : 0,
        "SUID" : 280,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1299.3012555255204,
        "y" : -3772.874462813844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "annmorse101",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "annmorse101",
        "SelfLoops" : 0,
        "SUID" : 279,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -911.3519757403642,
        "y" : -3757.4431883997813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BBrynteson",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "BBrynteson",
        "SelfLoops" : 0,
        "SUID" : 278,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1329.6522534503251,
        "y" : -3720.2918212122813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tessady",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "tessady",
        "SelfLoops" : 0,
        "SUID" : 277,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1005.6158612384111,
        "y" : -3676.4339110560313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lynnmarks",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lynnmarks",
        "SelfLoops" : 0,
        "SUID" : 276,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -964.3413556231767,
        "y" : -3787.7036864466563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "NoraWD",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "NoraWD",
        "SelfLoops" : 0,
        "SUID" : 275,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -855.565049470833,
        "y" : -3734.127880782594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "phyllis20",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "phyllis20",
        "SelfLoops" : 0,
        "SUID" : 274,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1142.2067592753679,
        "y" : -3553.089306563844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CindyAcuff",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CindyAcuff",
        "SelfLoops" : 0,
        "SUID" : 273,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -861.1522381915361,
        "y" : -3794.007519454469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lebibyc",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lebibyc",
        "SelfLoops" : 0,
        "SUID" : 272,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1273.8325055255204,
        "y" : -3718.1262938685313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "perrymeade",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "perrymeade",
        "SelfLoops" : 0,
        "SUID" : 271,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1306.7319043292314,
        "y" : -3664.751171798219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "sempercuriosa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "sempercuriosa",
        "SelfLoops" : 0,
        "SUID" : 270,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1173.3511746539384,
        "y" : -3593.9212157435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LoveForAll24",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LoveForAll24",
        "SelfLoops" : 0,
        "SUID" : 269,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1246.9516766680986,
        "y" : -3816.3291747279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DanielRossSala1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DanielRossSala1",
        "SelfLoops" : 0,
        "SUID" : 268,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1100.770531953743,
        "y" : -3869.7530028529063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pscrip",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pscrip",
        "SelfLoops" : 0,
        "SUID" : 267,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -956.0061352862626,
        "y" : -3845.594433516969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MrFrankV",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MrFrankV",
        "SelfLoops" : 0,
        "SUID" : 266,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1136.965771974495,
        "y" : -3954.6072508997813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mattfromCal1",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mattfromCal1",
        "SelfLoops" : 0,
        "SUID" : 265,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -913.8330701007158,
        "y" : -3812.1651122279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "aIysawang",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "aIysawang",
        "SelfLoops" : 0,
        "SUID" : 264,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1199.8310864581376,
        "y" : -3650.4888426966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Gilly79413339",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Gilly79413339",
        "SelfLoops" : 0,
        "SUID" : 263,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -895.5465405597001,
        "y" : -3863.173046798219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mlmetz5612",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mlmetz5612",
        "SelfLoops" : 0,
        "SUID" : 262,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -975.0719159259111,
        "y" : -3515.871533126344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Cali4niaCarolyn",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Cali4niaCarolyn",
        "SelfLoops" : 0,
        "SUID" : 261,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1063.9629071368486,
        "y" : -3956.3765380091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mlighty60",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mlighty60",
        "SelfLoops" : 0,
        "SUID" : 260,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -852.2151044024736,
        "y" : -3676.027294845094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "earthmother634",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "earthmother634",
        "SelfLoops" : 0,
        "SUID" : 259,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1159.9191334857255,
        "y" : -3905.214306563844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "posybunny",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "posybunny",
        "SelfLoops" : 0,
        "SUID" : 258,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -903.121949495247,
        "y" : -3646.1411864466563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "VickySchulte6",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "VickySchulte6",
        "SelfLoops" : 0,
        "SUID" : 257,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1254.193581880501,
        "y" : -3658.639599532594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "GlambertInKY",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "GlambertInKY",
        "SelfLoops" : 0,
        "SUID" : 256,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -956.175904573372,
        "y" : -3664.4766356654063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Lepidolite19",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Lepidolite19",
        "SelfLoops" : 0,
        "SUID" : 255,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1130.3565762652665,
        "y" : -3818.6009032435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lilxicanita",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lilxicanita",
        "SelfLoops" : 0,
        "SUID" : 254,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1005.039674104622,
        "y" : -3621.434765548219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Motherjones38",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Motherjones38",
        "SelfLoops" : 0,
        "SUID" : 253,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1255.765145601204,
        "y" : -3557.3794676966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "nickdean707",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "nickdean707",
        "SelfLoops" : 0,
        "SUID" : 252,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1189.6408742083818,
        "y" : -3806.2649657435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "two_sixty_three",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "two_sixty_three",
        "SelfLoops" : 0,
        "SUID" : 251,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1195.1685536517411,
        "y" : -3750.9617430872813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ForwardAgenda",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ForwardAgenda",
        "SelfLoops" : 0,
        "SUID" : 250,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1202.4208577288896,
        "y" : -3535.033642501344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "plzhelpmypony",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "plzhelpmypony",
        "SelfLoops" : 0,
        "SUID" : 249,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -949.1154645098954,
        "y" : -3607.915478438844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "mchastang84",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "mchastang84",
        "SelfLoops" : 0,
        "SUID" : 248,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1225.0653012408525,
        "y" : -3601.481640548219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "flybone_robin",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "flybone_robin",
        "SelfLoops" : 0,
        "SUID" : 247,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1210.9077580584794,
        "y" : -3860.115429610719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Monkeys2Fly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Monkeys2Fly",
        "SelfLoops" : 0,
        "SUID" : 246,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1082.8256314410478,
        "y" : -3786.778759688844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "pfb360",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "pfb360",
        "SelfLoops" : 0,
        "SUID" : 245,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1153.2799261225969,
        "y" : -3499.313976974
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AdamExler",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AdamExler",
        "SelfLoops" : 0,
        "SUID" : 244,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1065.2307980670244,
        "y" : -3836.5598876185313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "degodolly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "degodolly",
        "SelfLoops" : 0,
        "SUID" : 243,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1044.885232271126,
        "y" : -3569.7149169154063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "richiedg",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "richiedg",
        "SelfLoops" : 0,
        "SUID" : 242,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1144.4107545031816,
        "y" : -3764.3582274622813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "RuekaA",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "RuekaA",
        "SelfLoops" : 0,
        "SUID" : 241,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1137.9513266696245,
        "y" : -3643.2576415247813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CAO916",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CAO916",
        "SelfLoops" : 0,
        "SUID" : 240,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1299.5036023272783,
        "y" : -3826.723095626344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dolphinman47",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dolphinman47",
        "SelfLoops" : 0,
        "SUID" : 239,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 67.0
      },
      "position" : {
        "x" : -1261.229859651497,
        "y" : -3880.7530028529063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "ClosenessCentrality" : 0.48148148148148145,
        "Eccentricity" : 3,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "UCIIllumination",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "UCIIllumination",
        "SelfLoops" : 0,
        "SUID" : 238,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.076923076923077,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1627.2472979412764,
        "y" : -3012.987202376832
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "ClosenessCentrality" : 0.8571428571428571,
        "Eccentricity" : 2,
        "Outdegree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.01818181818181818,
        "Stress" : 612,
        "shared_name" : "UCIHumanities",
        "BetweennessCentrality" : 0.043583535108958835,
        "EdgeCount" : 11,
        "Indegree" : 1,
        "name" : "UCIHumanities",
        "SelfLoops" : 0,
        "SUID" : 237,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.1666666666666667,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.7272727272727273
      },
      "position" : {
        "x" : 1675.2170855389327,
        "y" : -3127.138622970094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.06666666666666667,
        "Stress" : 292,
        "shared_name" : "UCIEnglish",
        "BetweennessCentrality" : 0.02079475858139866,
        "EdgeCount" : 6,
        "Indegree" : 2,
        "name" : "UCIEnglish",
        "SelfLoops" : 0,
        "SUID" : 236,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 1867.5473467694014,
        "y" : -3133.689404220094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ljmu_ceres",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ljmu_ceres",
        "SelfLoops" : 0,
        "SUID" : 235,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1741.2592608319014,
        "y" : -3242.810528487672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "4Olrc",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "4Olrc",
        "SelfLoops" : 0,
        "SUID" : 234,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1700.8510882244796,
        "y" : -2999.6081587977305
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "UCIPat",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "UCIPat",
        "SelfLoops" : 0,
        "SUID" : 233,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1664.246443449089,
        "y" : -3251.5755736536876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jwassers",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jwassers",
        "SelfLoops" : 0,
        "SUID" : 232,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1590.7709490643233,
        "y" : -3204.06055900525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "markwarschauer",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "markwarschauer",
        "SelfLoops" : 0,
        "SUID" : 231,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1572.074843107292,
        "y" : -3082.0225341029063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "gillianrhayes",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "gillianrhayes",
        "SelfLoops" : 0,
        "SUID" : 230,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.0
      },
      "position" : {
        "x" : 1435.7597948895186,
        "y" : -3149.7295653529063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.5,
        "Stress" : 0,
        "shared_name" : "ErikaHayasaki",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "ErikaHayasaki",
        "SelfLoops" : 0,
        "SUID" : 229,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.5
      },
      "position" : {
        "x" : 1782.610945402214,
        "y" : -3090.931378097047
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "amandajswain",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "amandajswain",
        "SelfLoops" : 0,
        "SUID" : 228,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 1767.5708453045577,
        "y" : -3023.5931060023204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.5,
        "Stress" : 0,
        "shared_name" : "MillerTyrus",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "MillerTyrus",
        "SelfLoops" : 0,
        "SUID" : 227,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 8.5
      },
      "position" : {
        "x" : 1781.9282061444014,
        "y" : -3180.0106322474376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "ClosenessCentrality" : 0.46341463414634143,
        "Eccentricity" : 3,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "OCREAL_ESTATE",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "OCREAL_ESTATE",
        "SelfLoops" : 0,
        "SUID" : 217,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.1578947368421053,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 789.9130389080733,
        "y" : -3353.074413985719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ocgreatpark",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ocgreatpark",
        "SelfLoops" : 0,
        "SUID" : 216,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 1039.6509539471358,
        "y" : -3352.132122725953
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.5,
        "Stress" : 0,
        "shared_name" : "MelissaNorthway",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "MelissaNorthway",
        "SelfLoops" : 0,
        "SUID" : 215,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 10.0
      },
      "position" : {
        "x" : 856.9672076092452,
        "y" : -3544.7752806849376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.16666666666666666,
        "Stress" : 316,
        "shared_name" : "FamiliesForward",
        "BetweennessCentrality" : 0.022503916820965673,
        "EdgeCount" : 3,
        "Indegree" : 2,
        "name" : "FamiliesForward",
        "SelfLoops" : 0,
        "SUID" : 214,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.666666666666667
      },
      "position" : {
        "x" : 773.6557757244796,
        "y" : -3508.985790938844
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KatnipEvrgreen",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KatnipEvrgreen",
        "SelfLoops" : 0,
        "SUID" : 213,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 849.9350725994796,
        "y" : -3371.6793334193126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EmmietheKraken",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "EmmietheKraken",
        "SelfLoops" : 0,
        "SUID" : 212,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 782.8079058514327,
        "y" : -3423.382794112672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "T2LA1USA",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "T2LA1USA",
        "SelfLoops" : 0,
        "SUID" : 211,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 919.3259112225264,
        "y" : -3567.9993407435313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "msmichellemar",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "msmichellemar",
        "SelfLoops" : 0,
        "SUID" : 210,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 845.6687762127608,
        "y" : -3300.1680419154063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SmellyDogsMom",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SmellyDogsMom",
        "SelfLoops" : 0,
        "SUID" : 209,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 973.5464007244796,
        "y" : -3514.3281981654063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Jin13639949",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Jin13639949",
        "SelfLoops" : 0,
        "SUID" : 208,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 894.0475298748702,
        "y" : -3494.577404708375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 1728,
        "shared_name" : "UCIPubAffairs",
        "BetweennessCentrality" : 0.12305939324882495,
        "EdgeCount" : 5,
        "Indegree" : 2,
        "name" : "UCIPubAffairs",
        "SelfLoops" : 0,
        "SUID" : 207,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.6
      },
      "position" : {
        "x" : 1193.3668114529341,
        "y" : -3174.1641967005626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kunimi65048763",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kunimi65048763",
        "SelfLoops" : 0,
        "SUID" : 206,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 912.3948504315108,
        "y" : -3286.3043639368907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "OCRunner",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "OCRunner",
        "SelfLoops" : 0,
        "SUID" : 205,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 832.7080523358077,
        "y" : -3460.6665160365
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "AngelicaDanaa",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "AngelicaDanaa",
        "SelfLoops" : 0,
        "SUID" : 204,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 982.6218706951827,
        "y" : -3293.9871642298594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "IrvinePolice",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "IrvinePolice",
        "SelfLoops" : 0,
        "SUID" : 203,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 17.0
      },
      "position" : {
        "x" : 1050.5965105877608,
        "y" : -3472.6780516810313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "ClosenessCentrality" : 0.5217391304347826,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "EliMeye",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "EliMeye",
        "SelfLoops" : 0,
        "SUID" : 202,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9166666666666667,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1607.2299969805986,
        "y" : -959.3012282557384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ProfPeterCole",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ProfPeterCole",
        "SelfLoops" : 0,
        "SUID" : 201,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1716.4617474688798,
        "y" : -1142.1062438197032
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DavidpStein",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DavidpStein",
        "SelfLoops" : 0,
        "SUID" : 200,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1713.0954144610673,
        "y" : -1205.2749755091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MollyTalcott",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MollyTalcott",
        "SelfLoops" : 0,
        "SUID" : 199,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1559.702271760872,
        "y" : -1174.703350753297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "balti_less",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "balti_less",
        "SelfLoops" : 0,
        "SUID" : 198,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1782.7639935626298,
        "y" : -1013.2751815028087
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "UCAFT_UCLA",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "UCAFT_UCLA",
        "SelfLoops" : 0,
        "SUID" : 197,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1544.3572705401689,
        "y" : -1020.8327910609141
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "daniyure",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "daniyure",
        "SelfLoops" : 0,
        "SUID" : 196,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1716.4913800372392,
        "y" : -954.7480380244151
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SmTcontingent",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "SmTcontingent",
        "SelfLoops" : 0,
        "SUID" : 195,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1609.3068707598954,
        "y" : -1139.1764495081798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bulat666",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "bulat666",
        "SelfLoops" : 0,
        "SUID" : 194,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1639.7668316973954,
        "y" : -1203.3481566615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "professor_berry",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "professor_berry",
        "SelfLoops" : 0,
        "SUID" : 193,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1533.7217648638994,
        "y" : -1095.248028487672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "annebailey63",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "annebailey63",
        "SelfLoops" : 0,
        "SUID" : 192,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1793.3403180255204,
        "y" : -1083.5673186488048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "dmnd_the_mpssbl",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "dmnd_the_mpssbl",
        "SelfLoops" : 0,
        "SUID" : 191,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 13.0
      },
      "position" : {
        "x" : -1784.3628094805986,
        "y" : -1151.941143722047
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "andrewkerr",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "andrewkerr",
        "SelfLoops" : 0,
        "SUID" : 190,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -478.96351748841107,
        "y" : -3086.1685912318126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "TrusteeNtuk",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 2,
        "Indegree" : 2,
        "name" : "TrusteeNtuk",
        "SelfLoops" : 0,
        "SUID" : 189,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -302.9976361407548,
        "y" : -3122.3323485560313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "ClosenessCentrality" : 0.34615384615384615,
        "Eccentricity" : 4,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "wesley_verla",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "wesley_verla",
        "SelfLoops" : 0,
        "SUID" : 168,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.888888888888889,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 1887.680769620964,
        "y" : -3956.3765380091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "ClosenessCentrality" : 0.47058823529411764,
        "Eccentricity" : 3,
        "Outdegree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 264,
        "shared_name" : "RalphVClayman",
        "BetweennessCentrality" : 0.018800740635237144,
        "EdgeCount" : 4,
        "Indegree" : 1,
        "name" : "RalphVClayman",
        "SelfLoops" : 0,
        "SUID" : 167,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 2.125,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.25
      },
      "position" : {
        "x" : 1849.3620440350264,
        "y" : -3842.3738524622813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "ClosenessCentrality" : 0.5555555555555556,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 335,
        "shared_name" : "rahuljanaksinha",
        "BetweennessCentrality" : 0.023857000427289558,
        "EdgeCount" : 2,
        "Indegree" : 1,
        "name" : "rahuljanaksinha",
        "SelfLoops" : 0,
        "SUID" : 166,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 1711.1899248944014,
        "y" : -3786.747021407594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "UroAlsyouf",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "UroAlsyouf",
        "SelfLoops" : 0,
        "SUID" : 165,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 1968.596541105339,
        "y" : -3875.6781127161876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lesdeane",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lesdeane",
        "SelfLoops" : 0,
        "SUID" : 164,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : 1942.1516558514327,
        "y" : -3769.3453490443126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 844,
        "shared_name" : "jaimelandmanuci",
        "BetweennessCentrality" : 0.060105398091439964,
        "EdgeCount" : 6,
        "Indegree" : 2,
        "name" : "jaimelandmanuci",
        "SelfLoops" : 0,
        "SUID" : 163,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.3333333333333333
      },
      "position" : {
        "x" : 1555.4228960858077,
        "y" : -3723.729443282594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "ClosenessCentrality" : 0.6666666666666666,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "SolShock",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "SolShock",
        "SelfLoops" : 0,
        "SUID" : 162,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.5,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -727.6522992266923,
        "y" : -2966.1805846400157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "FoodFindersLBC",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "FoodFindersLBC",
        "SelfLoops" : 0,
        "SUID" : 161,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : -632.5869305743486,
        "y" : -3014.904064864625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Sally8229650811",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Sally8229650811",
        "SelfLoops" : 0,
        "SUID" : 160,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -2005.9560711993486,
        "y" : -810.2778746790782
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Animabando",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Animabando",
        "SelfLoops" : 0,
        "SUID" : 159,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -1948.5981000079423,
        "y" : -847.5664412684337
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Gaia10280169",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Gaia10280169",
        "SelfLoops" : 0,
        "SUID" : 158,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -1993.1282513751298,
        "y" : -620.075421065797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MexicoSecuestra",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MexicoSecuestra",
        "SelfLoops" : 0,
        "SUID" : 157,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -1875.9739545001298,
        "y" : -598.2658202357188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "angie_renati",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "angie_renati",
        "SelfLoops" : 0,
        "SUID" : 156,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -2010.383195222786,
        "y" : -713.6792723841563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "victori18964840",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "victori18964840",
        "SelfLoops" : 0,
        "SUID" : 155,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -1815.4213116778642,
        "y" : -647.609844893922
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "MizGiz",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "MizGiz",
        "SelfLoops" : 0,
        "SUID" : 154,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -2049.593644441536,
        "y" : -660.5247924036876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LeviVegan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LeviVegan",
        "SelfLoops" : 0,
        "SUID" : 153,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -1943.2968304766923,
        "y" : -583.0487792200938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "geraldineiris21",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "geraldineiris21",
        "SelfLoops" : 0,
        "SUID" : 152,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -1870.963731111458,
        "y" : -834.4185378260509
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "PurpleApePal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "PurpleApePal",
        "SelfLoops" : 0,
        "SUID" : 151,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -1803.2856610430986,
        "y" : -757.4019286341563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "PhaedraXTeddy",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "PhaedraXTeddy",
        "SelfLoops" : 0,
        "SUID" : 150,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 12.0
      },
      "position" : {
        "x" : -2052.1393597735673,
        "y" : -762.5615966029063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "anthonykuo",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "anthonykuo",
        "SelfLoops" : 0,
        "SUID" : 149,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.0
      },
      "position" : {
        "x" : 670.9409624920577,
        "y" : -3592.399670333375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "ClosenessCentrality" : 0.5263157894736842,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "bhusak",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "bhusak",
        "SelfLoops" : 0,
        "SUID" : 148,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -1.032792390754821,
        "y" : -3349.3704344935313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lbccvikings",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lbccvikings",
        "SelfLoops" : 0,
        "SUID" : 147,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -151.64936953919232,
        "y" : -3355.935742110719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jdo8302",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jdo8302",
        "SelfLoops" : 0,
        "SUID" : 146,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -79.13911563294232,
        "y" : -3406.2266967005626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "counselor_oh",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "counselor_oh",
        "SelfLoops" : 0,
        "SUID" : 145,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -246.49177676575482,
        "y" : -3263.092968673219
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ProfessorVitt",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ProfessorVitt",
        "SelfLoops" : 0,
        "SUID" : 144,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : 2.744429288932679,
        "y" : -3274.917736739625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "fradoo88",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "fradoo88",
        "SelfLoops" : 0,
        "SUID" : 143,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -63.11103946106732,
        "y" : -3341.3413817591563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "andy_r45",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "andy_r45",
        "SelfLoops" : 0,
        "SUID" : 142,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -27.80928164856732,
        "y" : -3203.565197677125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DaMatrix13",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DaMatrix13",
        "SelfLoops" : 0,
        "SUID" : 141,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -230.05861026184857,
        "y" : -3345.8580443568126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "LBCCTraining",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "LBCCTraining",
        "SelfLoops" : 0,
        "SUID" : 140,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 11.0
      },
      "position" : {
        "x" : -161.35591250794232,
        "y" : -3413.8253295130626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "ClosenessCentrality" : 0.5555555555555556,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "drnicolaecrisan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "drnicolaecrisan",
        "SelfLoops" : 0,
        "SUID" : 139,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 1629.5036761151046,
        "y" : -3822.9263426966563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ack12",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ack12",
        "SelfLoops" : 0,
        "SUID" : 138,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 1658.640761076042,
        "y" : -3672.9598509974376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lift_uciurology",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lift_uciurology",
        "SelfLoops" : 0,
        "SUID" : 137,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 1475.3906084881514,
        "y" : -3814.1375853724376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "montypal",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "montypal",
        "SelfLoops" : 0,
        "SUID" : 136,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 1561.902968107292,
        "y" : -3852.3755614466563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "ClosenessCentrality" : 0.5555555555555556,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "BNUEric",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "BNUEric",
        "SelfLoops" : 0,
        "SUID" : 111,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.8,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 1995.0226275311202,
        "y" : -3135.3006560511485
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DrJeffreyWilson",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DrJeffreyWilson",
        "SelfLoops" : 0,
        "SUID" : 110,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 1952.3442828045577,
        "y" : -3225.4849669642344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "taylorweik",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "taylorweik",
        "SelfLoops" : 0,
        "SUID" : 109,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.0
      },
      "position" : {
        "x" : 1955.3492876873702,
        "y" : -3044.0030944056407
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "ClosenessCentrality" : 0.5098039215686275,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "HarrisStuart_LA",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "HarrisStuart_LA",
        "SelfLoops" : 0,
        "SUID" : 108,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.9615384615384615,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 107.49368542296588,
        "y" : -985.282452315797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "ClosenessCentrality" : 1.0,
        "Eccentricity" : 1,
        "Outdegree" : 25,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 875,
        "shared_name" : "csuf",
        "BetweennessCentrality" : 0.508130081300813,
        "EdgeCount" : 26,
        "Indegree" : 1,
        "name" : "csuf",
        "SelfLoops" : 0,
        "SUID" : 107,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 1.0384615384615385
      },
      "position" : {
        "x" : 5.620588956901429,
        "y" : -1031.663830489625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Woaah_Caat",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Woaah_Caat",
        "SelfLoops" : 0,
        "SUID" : 106,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 27.68144863707721,
        "y" : -868.6159789271251
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "iortiz254",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "iortiz254",
        "SelfLoops" : 0,
        "SUID" : 105,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 112.51101368529498,
        "y" : -1052.5387389368907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jayce2fast",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jayce2fast",
        "SelfLoops" : 0,
        "SUID" : 104,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 99.17746227843463,
        "y" : -886.9124266810313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "crystalbibi_14",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "crystalbibi_14",
        "SelfLoops" : 0,
        "SUID" : 103,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 148.41546505553424,
        "y" : -932.542233199586
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CallmeMahi9999",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CallmeMahi9999",
        "SelfLoops" : 0,
        "SUID" : 102,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 156.5215594158858,
        "y" : -1119.1477477259532
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Maririaah",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Maririaah",
        "SelfLoops" : 0,
        "SUID" : 101,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -140.77291995423138,
        "y" : -958.9083373255626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Tuffy_The_Titan",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Tuffy_The_Titan",
        "SelfLoops" : 0,
        "SUID" : 100,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -102.58424502747357,
        "y" : -1157.5176207728282
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "morenaa__98",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "morenaa__98",
        "SelfLoops" : 0,
        "SUID" : 99,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 27.448332487174866,
        "y" : -1138.687481612672
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "KatieSavant",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "KatieSavant",
        "SelfLoops" : 0,
        "SUID" : 98,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 175.39707821471393,
        "y" : -1057.5545470423594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ElizabethMonto",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ElizabethMonto",
        "SelfLoops" : 0,
        "SUID" : 97,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -162.29995852845013,
        "y" : -1039.4576537318126
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "_cgilly",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "_cgilly",
        "SelfLoops" : 0,
        "SUID" : 96,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -50.076447786262634,
        "y" : -885.0129668421641
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "tgi_Jacob127",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "tgi_Jacob127",
        "SelfLoops" : 0,
        "SUID" : 95,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -6.551049531868102,
        "y" : -929.260494918336
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "johana95",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "johana95",
        "SelfLoops" : 0,
        "SUID" : 94,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -0.19654208557903985,
        "y" : -1190.87891838025
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "ellainmaee",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "ellainmaee",
        "SelfLoops" : 0,
        "SUID" : 93,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 60.758925138542054,
        "y" : -935.7140166468516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "DrOseguera",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "DrOseguera",
        "SelfLoops" : 0,
        "SUID" : 92,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -148.13723880188763,
        "y" : -1110.4230467982188
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "JinalSh91320289",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "JinalSh91320289",
        "SelfLoops" : 0,
        "SUID" : 91,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 82.33117550475299,
        "y" : -1107.4828002161876
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CSUFGeology",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CSUFGeology",
        "SelfLoops" : 0,
        "SUID" : 90,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -56.647324861457946,
        "y" : -1202.5374266810313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "csufcnsm",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "csufcnsm",
        "SelfLoops" : 0,
        "SUID" : 89,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -43.94195681946576,
        "y" : -1126.2765013880626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "adamgolub",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "adamgolub",
        "SelfLoops" : 0,
        "SUID" : 88,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -93.76216250794232,
        "y" : -1078.0807311243907
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Sp2020BioAnth",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Sp2020BioAnth",
        "SelfLoops" : 0,
        "SUID" : 87,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 109.82894581420123,
        "y" : -1163.5088622279063
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "kthygld",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "kthygld",
        "SelfLoops" : 0,
        "SUID" : 86,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 61.88642376525104,
        "y" : -1205.2749755091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "csufpd",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "csufpd",
        "SelfLoops" : 0,
        "SUID" : 85,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : 172.67873257262409,
        "y" : -995.5673033900157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CSUFPTS",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CSUFPTS",
        "SelfLoops" : 0,
        "SUID" : 84,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -102.25923282044232,
        "y" : -1011.5015380091563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "OldMacDonald",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "OldMacDonald",
        "SelfLoops" : 0,
        "SUID" : 83,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 26.0
      },
      "position" : {
        "x" : -76.76109439270795,
        "y" : -945.1989257044688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "jocelinocuw",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "jocelinocuw",
        "SelfLoops" : 0,
        "SUID" : 82,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 1170.6487261639327,
        "y" : -3065.0432707972423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "theamandahughes",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "theamandahughes",
        "SelfLoops" : 0,
        "SUID" : 81,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.0
      },
      "position" : {
        "x" : 1294.1636034832686,
        "y" : -3123.8909575648204
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "CalRecycle",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "CalRecycle",
        "SelfLoops" : 0,
        "SUID" : 80,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -150.61872989075482,
        "y" : -2589.465084762086
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "Justinscake",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "Justinscake",
        "SelfLoops" : 0,
        "SUID" : 79,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -242.28560000794232,
        "y" : -2885.698773116578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "lnfernandez2013",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "lnfernandez2013",
        "SelfLoops" : 0,
        "SUID" : 78,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -172.96833926575482,
        "y" : -2848.1297728724376
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "_FritoLai",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "_FritoLai",
        "SelfLoops" : 0,
        "SUID" : 77,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -309.96229678528607,
        "y" : -2739.474102706422
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "teachersarah21",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "teachersarah21",
        "SelfLoops" : 0,
        "SUID" : 76,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -93.46370059387982,
        "y" : -2739.0233123011485
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "trott1073",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "trott1073",
        "SelfLoops" : 0,
        "SUID" : 75,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -264.9268353595048,
        "y" : -2826.911877364625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "artofuprising",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "artofuprising",
        "SelfLoops" : 0,
        "SUID" : 74,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 7.0
      },
      "position" : {
        "x" : -325.66114932434857,
        "y" : -2811.536907882203
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "ClosenessCentrality" : 0.6,
        "Eccentricity" : 2,
        "Outdegree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "othesharon",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 0,
        "name" : "othesharon",
        "SelfLoops" : 0,
        "SUID" : 73,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 1.6666666666666667,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -987.6307843341142,
        "y" : -3054.87696525525
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "persnicketyweas",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "persnicketyweas",
        "SelfLoops" : 0,
        "SUID" : 72,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -1085.084466279915,
        "y" : -2926.2361876673594
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Outdegree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Stress" : 0,
        "shared_name" : "beachgirl_karen",
        "BetweennessCentrality" : 0.0,
        "EdgeCount" : 1,
        "Indegree" : 1,
        "name" : "beachgirl_karen",
        "SelfLoops" : 0,
        "SUID" : 71,
        "IsSingleNode" : false,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.0
      },
      "position" : {
        "x" : -1020.0671094073564,
        "y" : -2837.884075850953
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1806",
        "source" : "936",
        "target" : "935",
        "EdgeBetweenness" : 2760.0,
        "shared_name" : "genereaux2019 (interacts with) HarleyRouda",
        "shared_interaction" : "interacts with",
        "name" : "genereaux2019 (interacts with) HarleyRouda",
        "interaction" : "interacts with",
        "SUID" : 1806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1805",
        "source" : "935",
        "target" : "934",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) eqtr8er",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) eqtr8er",
        "interaction" : "interacts with",
        "SUID" : 1805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1804",
        "source" : "935",
        "target" : "933",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) RedReader5252",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) RedReader5252",
        "interaction" : "interacts with",
        "SUID" : 1804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1803",
        "source" : "935",
        "target" : "932",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) davidpsdem",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) davidpsdem",
        "interaction" : "interacts with",
        "SUID" : 1803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1802",
        "source" : "935",
        "target" : "931",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) SuMoh7",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) SuMoh7",
        "interaction" : "interacts with",
        "SUID" : 1802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1801",
        "source" : "935",
        "target" : "930",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) GVForsyth",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) GVForsyth",
        "interaction" : "interacts with",
        "SUID" : 1801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1800",
        "source" : "935",
        "target" : "929",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) janggolan",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) janggolan",
        "interaction" : "interacts with",
        "SUID" : 1800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1799",
        "source" : "935",
        "target" : "928",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) JuliaKGeorge",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) JuliaKGeorge",
        "interaction" : "interacts with",
        "SUID" : 1799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1798",
        "source" : "935",
        "target" : "927",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) HBnole",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) HBnole",
        "interaction" : "interacts with",
        "SUID" : 1798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1797",
        "source" : "935",
        "target" : "926",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) bjcrochet",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) bjcrochet",
        "interaction" : "interacts with",
        "SUID" : 1797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1796",
        "source" : "935",
        "target" : "925",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) BetteKayOR",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) BetteKayOR",
        "interaction" : "interacts with",
        "SUID" : 1796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1795",
        "source" : "935",
        "target" : "924",
        "EdgeBetweenness" : 4130.0,
        "shared_name" : "HarleyRouda (interacts with) All435Reps",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) All435Reps",
        "interaction" : "interacts with",
        "SUID" : 1795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1794",
        "source" : "935",
        "target" : "923",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) 333Cassandra",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) 333Cassandra",
        "interaction" : "interacts with",
        "SUID" : 1794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1793",
        "source" : "935",
        "target" : "922",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) bloolee98",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) bloolee98",
        "interaction" : "interacts with",
        "SUID" : 1793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1792",
        "source" : "935",
        "target" : "921",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) RichardLBond1",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) RichardLBond1",
        "interaction" : "interacts with",
        "SUID" : 1792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1791",
        "source" : "935",
        "target" : "920",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) mitchellscomet",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) mitchellscomet",
        "interaction" : "interacts with",
        "SUID" : 1791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1790",
        "source" : "935",
        "target" : "919",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) kristine_kenyon",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) kristine_kenyon",
        "interaction" : "interacts with",
        "SUID" : 1790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1789",
        "source" : "935",
        "target" : "918",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) travelingalexis",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) travelingalexis",
        "interaction" : "interacts with",
        "SUID" : 1789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1788",
        "source" : "935",
        "target" : "917",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) HarleyVicQuinn",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) HarleyVicQuinn",
        "interaction" : "interacts with",
        "SUID" : 1788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1787",
        "source" : "935",
        "target" : "916",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) BKiddo0725",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) BKiddo0725",
        "interaction" : "interacts with",
        "SUID" : 1787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1786",
        "source" : "935",
        "target" : "915",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) SocialCivility",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) SocialCivility",
        "interaction" : "interacts with",
        "SUID" : 1786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1785",
        "source" : "935",
        "target" : "914",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) socallance",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) socallance",
        "interaction" : "interacts with",
        "SUID" : 1785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1784",
        "source" : "935",
        "target" : "913",
        "EdgeBetweenness" : 59.0,
        "shared_name" : "HarleyRouda (interacts with) marymredoutey",
        "shared_interaction" : "interacts with",
        "name" : "HarleyRouda (interacts with) marymredoutey",
        "interaction" : "interacts with",
        "SUID" : 1784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1783",
        "source" : "924",
        "target" : "689",
        "EdgeBetweenness" : 45012.0,
        "shared_name" : "All435Reps (interacts with) katieporteroc",
        "shared_interaction" : "interacts with",
        "name" : "All435Reps (interacts with) katieporteroc",
        "interaction" : "interacts with",
        "SUID" : 1783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1782",
        "source" : "924",
        "target" : "688",
        "EdgeBetweenness" : 2046.0,
        "shared_name" : "All435Reps (interacts with) RepGilCisneros",
        "shared_interaction" : "interacts with",
        "name" : "All435Reps (interacts with) RepGilCisneros",
        "interaction" : "interacts with",
        "SUID" : 1782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1781",
        "source" : "912",
        "target" : "911",
        "EdgeBetweenness" : 5136.0,
        "shared_name" : "CarrieHKelly (interacts with) OCDAToddSpitzer",
        "shared_interaction" : "interacts with",
        "name" : "CarrieHKelly (interacts with) OCDAToddSpitzer",
        "interaction" : "interacts with",
        "SUID" : 1781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1780",
        "source" : "912",
        "target" : "910",
        "EdgeBetweenness" : 107.0,
        "shared_name" : "CarrieHKelly (interacts with) msicefan",
        "shared_interaction" : "interacts with",
        "name" : "CarrieHKelly (interacts with) msicefan",
        "interaction" : "interacts with",
        "SUID" : 1780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1779",
        "source" : "911",
        "target" : "909",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) RigoReporting",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) RigoReporting",
        "interaction" : "interacts with",
        "SUID" : 1779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1778",
        "source" : "911",
        "target" : "908",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) Rolandvanking",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) Rolandvanking",
        "interaction" : "interacts with",
        "SUID" : 1778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1777",
        "source" : "911",
        "target" : "907",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) G2G_Wavey",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) G2G_Wavey",
        "interaction" : "interacts with",
        "SUID" : 1777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1776",
        "source" : "911",
        "target" : "906",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) TheDiegoOrtega",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) TheDiegoOrtega",
        "interaction" : "interacts with",
        "SUID" : 1776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1775",
        "source" : "911",
        "target" : "905",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) camanowa",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) camanowa",
        "interaction" : "interacts with",
        "SUID" : 1775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1774",
        "source" : "911",
        "target" : "904",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) dlp59801",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) dlp59801",
        "interaction" : "interacts with",
        "SUID" : 1774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1773",
        "source" : "911",
        "target" : "903",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) 1Marsha9988",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) 1Marsha9988",
        "interaction" : "interacts with",
        "SUID" : 1773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1772",
        "source" : "911",
        "target" : "902",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) DianneMChilds03",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) DianneMChilds03",
        "interaction" : "interacts with",
        "SUID" : 1772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1771",
        "source" : "911",
        "target" : "901",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) LindaClendennen",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) LindaClendennen",
        "interaction" : "interacts with",
        "SUID" : 1771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1770",
        "source" : "911",
        "target" : "900",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) kelzmatelz",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) kelzmatelz",
        "interaction" : "interacts with",
        "SUID" : 1770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1769",
        "source" : "911",
        "target" : "899",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) hufco60",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) hufco60",
        "interaction" : "interacts with",
        "SUID" : 1769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1768",
        "source" : "911",
        "target" : "898",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) AmberP__",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) AmberP__",
        "interaction" : "interacts with",
        "SUID" : 1768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1767",
        "source" : "911",
        "target" : "897",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) TheGreatFeather",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) TheGreatFeather",
        "interaction" : "interacts with",
        "SUID" : 1767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1766",
        "source" : "911",
        "target" : "896",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) LGKITTEN",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) LGKITTEN",
        "interaction" : "interacts with",
        "SUID" : 1766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1765",
        "source" : "911",
        "target" : "895",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) MargotCult45n46",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) MargotCult45n46",
        "interaction" : "interacts with",
        "SUID" : 1765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1764",
        "source" : "911",
        "target" : "894",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) ASylvie7",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) ASylvie7",
        "interaction" : "interacts with",
        "SUID" : 1764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1763",
        "source" : "911",
        "target" : "893",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) ActualDM",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) ActualDM",
        "interaction" : "interacts with",
        "SUID" : 1763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1762",
        "source" : "911",
        "target" : "892",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) robdetf",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) robdetf",
        "interaction" : "interacts with",
        "SUID" : 1762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1761",
        "source" : "911",
        "target" : "891",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) LitlemissDotty",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) LitlemissDotty",
        "interaction" : "interacts with",
        "SUID" : 1761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1760",
        "source" : "911",
        "target" : "890",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) partynxs",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) partynxs",
        "interaction" : "interacts with",
        "SUID" : 1760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1759",
        "source" : "911",
        "target" : "889",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) pjgirl74",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) pjgirl74",
        "interaction" : "interacts with",
        "SUID" : 1759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1758",
        "source" : "911",
        "target" : "888",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) Nunya1230",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) Nunya1230",
        "interaction" : "interacts with",
        "SUID" : 1758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1757",
        "source" : "911",
        "target" : "887",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) JaneneSimon10",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) JaneneSimon10",
        "interaction" : "interacts with",
        "SUID" : 1757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1756",
        "source" : "911",
        "target" : "886",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) EsmeOh96",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) EsmeOh96",
        "interaction" : "interacts with",
        "SUID" : 1756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1755",
        "source" : "911",
        "target" : "885",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) socialpower",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) socialpower",
        "interaction" : "interacts with",
        "SUID" : 1755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1754",
        "source" : "911",
        "target" : "884",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) evelynj_45",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) evelynj_45",
        "interaction" : "interacts with",
        "SUID" : 1754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1753",
        "source" : "911",
        "target" : "883",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) moby_c43",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) moby_c43",
        "interaction" : "interacts with",
        "SUID" : 1753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1752",
        "source" : "911",
        "target" : "882",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) princessvivvian",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) princessvivvian",
        "interaction" : "interacts with",
        "SUID" : 1752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1751",
        "source" : "911",
        "target" : "881",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) janicecampos_",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) janicecampos_",
        "interaction" : "interacts with",
        "SUID" : 1751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1750",
        "source" : "911",
        "target" : "880",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) alma49451161",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) alma49451161",
        "interaction" : "interacts with",
        "SUID" : 1750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1749",
        "source" : "911",
        "target" : "879",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) kristipuhl",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) kristipuhl",
        "interaction" : "interacts with",
        "SUID" : 1749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1748",
        "source" : "911",
        "target" : "878",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) MissinginCalif",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) MissinginCalif",
        "interaction" : "interacts with",
        "SUID" : 1748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1747",
        "source" : "911",
        "target" : "877",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) andreamontillaa",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) andreamontillaa",
        "interaction" : "interacts with",
        "SUID" : 1747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1746",
        "source" : "911",
        "target" : "876",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) briannamariee",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) briannamariee",
        "interaction" : "interacts with",
        "SUID" : 1746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1745",
        "source" : "911",
        "target" : "875",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) DavidSM_24",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) DavidSM_24",
        "interaction" : "interacts with",
        "SUID" : 1745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1744",
        "source" : "911",
        "target" : "874",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) xrod99",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) xrod99",
        "interaction" : "interacts with",
        "SUID" : 1744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1743",
        "source" : "911",
        "target" : "873",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) eneiraaa",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) eneiraaa",
        "interaction" : "interacts with",
        "SUID" : 1743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1742",
        "source" : "911",
        "target" : "872",
        "EdgeBetweenness" : 639.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) _BrittanyMun",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) _BrittanyMun",
        "interaction" : "interacts with",
        "SUID" : 1742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1741",
        "source" : "911",
        "target" : "871",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) maverickgangg",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) maverickgangg",
        "interaction" : "interacts with",
        "SUID" : 1741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1740",
        "source" : "911",
        "target" : "870",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) 92_kherrera",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) 92_kherrera",
        "interaction" : "interacts with",
        "SUID" : 1740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1739",
        "source" : "911",
        "target" : "869",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) SantaAnaPD",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) SantaAnaPD",
        "interaction" : "interacts with",
        "SUID" : 1739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1738",
        "source" : "911",
        "target" : "868",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) captaindaveyp",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) captaindaveyp",
        "interaction" : "interacts with",
        "SUID" : 1738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1737",
        "source" : "911",
        "target" : "867",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) ABC7JulieSone",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) ABC7JulieSone",
        "interaction" : "interacts with",
        "SUID" : 1737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1736",
        "source" : "911",
        "target" : "866",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) BrittneyMB21",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) BrittneyMB21",
        "interaction" : "interacts with",
        "SUID" : 1736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1735",
        "source" : "911",
        "target" : "865",
        "EdgeBetweenness" : 213.0,
        "shared_name" : "OCDAToddSpitzer (interacts with) WaymakersOC",
        "shared_interaction" : "interacts with",
        "name" : "OCDAToddSpitzer (interacts with) WaymakersOC",
        "interaction" : "interacts with",
        "SUID" : 1735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1734",
        "source" : "872",
        "target" : "754",
        "EdgeBetweenness" : 558.0,
        "shared_name" : "_BrittanyMun (interacts with) UCI_OVCHA",
        "shared_interaction" : "interacts with",
        "name" : "_BrittanyMun (interacts with) UCI_OVCHA",
        "interaction" : "interacts with",
        "SUID" : 1734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1733",
        "source" : "864",
        "target" : "863",
        "EdgeBetweenness" : 1064.0,
        "shared_name" : "megagamer5 (interacts with) cityofbrea",
        "shared_interaction" : "interacts with",
        "name" : "megagamer5 (interacts with) cityofbrea",
        "interaction" : "interacts with",
        "SUID" : 1733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1732",
        "source" : "863",
        "target" : "862",
        "EdgeBetweenness" : 1500.0,
        "shared_name" : "cityofbrea (interacts with) EvanCarey86",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) EvanCarey86",
        "interaction" : "interacts with",
        "SUID" : 1732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1731",
        "source" : "863",
        "target" : "861",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cityofbrea (interacts with) BreaPD",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) BreaPD",
        "interaction" : "interacts with",
        "SUID" : 1731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1730",
        "source" : "863",
        "target" : "910",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cityofbrea (interacts with) msicefan",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) msicefan",
        "interaction" : "interacts with",
        "SUID" : 1730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1729",
        "source" : "863",
        "target" : "860",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cityofbrea (interacts with) ARobertSilva",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) ARobertSilva",
        "interaction" : "interacts with",
        "SUID" : 1729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1728",
        "source" : "863",
        "target" : "859",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cityofbrea (interacts with) BreaEM",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) BreaEM",
        "interaction" : "interacts with",
        "SUID" : 1728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1727",
        "source" : "863",
        "target" : "858",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cityofbrea (interacts with) sarno456",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) sarno456",
        "interaction" : "interacts with",
        "SUID" : 1727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1726",
        "source" : "863",
        "target" : "857",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cityofbrea (interacts with) milfvolcom",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) milfvolcom",
        "interaction" : "interacts with",
        "SUID" : 1726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1725",
        "source" : "863",
        "target" : "856",
        "EdgeBetweenness" : 75.0,
        "shared_name" : "cityofbrea (interacts with) davidmartinson",
        "shared_interaction" : "interacts with",
        "name" : "cityofbrea (interacts with) davidmartinson",
        "interaction" : "interacts with",
        "SUID" : 1725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1724",
        "source" : "862",
        "target" : "855",
        "EdgeBetweenness" : 2109.0,
        "shared_name" : "EvanCarey86 (interacts with) City_of_Irvine",
        "shared_interaction" : "interacts with",
        "name" : "EvanCarey86 (interacts with) City_of_Irvine",
        "interaction" : "interacts with",
        "SUID" : 1724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1723",
        "source" : "855",
        "target" : "216",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) ocgreatpark",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) ocgreatpark",
        "interaction" : "interacts with",
        "SUID" : 1723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1722",
        "source" : "855",
        "target" : "215",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) MelissaNorthway",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) MelissaNorthway",
        "interaction" : "interacts with",
        "SUID" : 1722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1721",
        "source" : "855",
        "target" : "214",
        "EdgeBetweenness" : 596.0,
        "shared_name" : "City_of_Irvine (interacts with) FamiliesForward",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) FamiliesForward",
        "interaction" : "interacts with",
        "SUID" : 1721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1720",
        "source" : "855",
        "target" : "213",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) KatnipEvrgreen",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) KatnipEvrgreen",
        "interaction" : "interacts with",
        "SUID" : 1720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1719",
        "source" : "855",
        "target" : "212",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) EmmietheKraken",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) EmmietheKraken",
        "interaction" : "interacts with",
        "SUID" : 1719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1718",
        "source" : "855",
        "target" : "211",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) T2LA1USA",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) T2LA1USA",
        "interaction" : "interacts with",
        "SUID" : 1718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1717",
        "source" : "855",
        "target" : "210",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) msmichellemar",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) msmichellemar",
        "interaction" : "interacts with",
        "SUID" : 1717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1716",
        "source" : "855",
        "target" : "209",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) SmellyDogsMom",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) SmellyDogsMom",
        "interaction" : "interacts with",
        "SUID" : 1716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1715",
        "source" : "855",
        "target" : "208",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) Jin13639949",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) Jin13639949",
        "interaction" : "interacts with",
        "SUID" : 1715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1714",
        "source" : "855",
        "target" : "207",
        "EdgeBetweenness" : 1192.0,
        "shared_name" : "City_of_Irvine (interacts with) UCIPubAffairs",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) UCIPubAffairs",
        "interaction" : "interacts with",
        "SUID" : 1714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1713",
        "source" : "855",
        "target" : "206",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) kunimi65048763",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) kunimi65048763",
        "interaction" : "interacts with",
        "SUID" : 1713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1712",
        "source" : "855",
        "target" : "205",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) OCRunner",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) OCRunner",
        "interaction" : "interacts with",
        "SUID" : 1712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1711",
        "source" : "855",
        "target" : "204",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) AngelicaDanaa",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) AngelicaDanaa",
        "interaction" : "interacts with",
        "SUID" : 1711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1710",
        "source" : "855",
        "target" : "203",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "City_of_Irvine (interacts with) IrvinePolice",
        "shared_interaction" : "interacts with",
        "name" : "City_of_Irvine (interacts with) IrvinePolice",
        "interaction" : "interacts with",
        "SUID" : 1710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1709",
        "source" : "854",
        "target" : "853",
        "EdgeBetweenness" : 567.0,
        "shared_name" : "00sh4a_ (interacts with) ClickThatFollow",
        "shared_interaction" : "interacts with",
        "name" : "00sh4a_ (interacts with) ClickThatFollow",
        "interaction" : "interacts with",
        "SUID" : 1709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1708",
        "source" : "853",
        "target" : "852",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) DujjAT",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) DujjAT",
        "interaction" : "interacts with",
        "SUID" : 1708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1707",
        "source" : "853",
        "target" : "851",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Boyingtonfr",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Boyingtonfr",
        "interaction" : "interacts with",
        "SUID" : 1707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1706",
        "source" : "853",
        "target" : "850",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) genuineyes",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) genuineyes",
        "interaction" : "interacts with",
        "SUID" : 1706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1705",
        "source" : "853",
        "target" : "849",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Am_muhairi",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Am_muhairi",
        "interaction" : "interacts with",
        "SUID" : 1705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1704",
        "source" : "853",
        "target" : "848",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) pakmee",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) pakmee",
        "interaction" : "interacts with",
        "SUID" : 1704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1703",
        "source" : "853",
        "target" : "847",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) favvvvma",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) favvvvma",
        "interaction" : "interacts with",
        "SUID" : 1703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1702",
        "source" : "853",
        "target" : "846",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) sayhello",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) sayhello",
        "interaction" : "interacts with",
        "SUID" : 1702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1701",
        "source" : "853",
        "target" : "845",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) JacksBurner",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) JacksBurner",
        "interaction" : "interacts with",
        "SUID" : 1701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1700",
        "source" : "853",
        "target" : "844",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) 3abm_",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) 3abm_",
        "interaction" : "interacts with",
        "SUID" : 1700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1699",
        "source" : "853",
        "target" : "843",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) zezoghandurah",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) zezoghandurah",
        "interaction" : "interacts with",
        "SUID" : 1699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1698",
        "source" : "853",
        "target" : "842",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Yasminmn_",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Yasminmn_",
        "interaction" : "interacts with",
        "SUID" : 1698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1697",
        "source" : "853",
        "target" : "841",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) ChubberGuard",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) ChubberGuard",
        "interaction" : "interacts with",
        "SUID" : 1697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1696",
        "source" : "853",
        "target" : "840",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) abdulrhmanmas",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) abdulrhmanmas",
        "interaction" : "interacts with",
        "SUID" : 1696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1695",
        "source" : "853",
        "target" : "839",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) 7omoudrajab",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) 7omoudrajab",
        "interaction" : "interacts with",
        "SUID" : 1695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1694",
        "source" : "853",
        "target" : "838",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) danielford77",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) danielford77",
        "interaction" : "interacts with",
        "SUID" : 1694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1693",
        "source" : "853",
        "target" : "837",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) spaekman",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) spaekman",
        "interaction" : "interacts with",
        "SUID" : 1693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1692",
        "source" : "853",
        "target" : "836",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) ChadDavis_1992",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) ChadDavis_1992",
        "interaction" : "interacts with",
        "SUID" : 1692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1691",
        "source" : "853",
        "target" : "835",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) thisiskwangg",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) thisiskwangg",
        "interaction" : "interacts with",
        "SUID" : 1691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1690",
        "source" : "853",
        "target" : "834",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) 0llyMelancholy",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) 0llyMelancholy",
        "interaction" : "interacts with",
        "SUID" : 1690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1689",
        "source" : "853",
        "target" : "833",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) BluePicker90",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) BluePicker90",
        "interaction" : "interacts with",
        "SUID" : 1689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1688",
        "source" : "853",
        "target" : "832",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) vjradiance",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) vjradiance",
        "interaction" : "interacts with",
        "SUID" : 1688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1687",
        "source" : "853",
        "target" : "831",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) geryfesalvo",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) geryfesalvo",
        "interaction" : "interacts with",
        "SUID" : 1687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1686",
        "source" : "853",
        "target" : "830",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Aaron_____Davis",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Aaron_____Davis",
        "interaction" : "interacts with",
        "SUID" : 1686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1685",
        "source" : "853",
        "target" : "829",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Christo50881821",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Christo50881821",
        "interaction" : "interacts with",
        "SUID" : 1685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1684",
        "source" : "853",
        "target" : "828",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) maggiejuang1",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) maggiejuang1",
        "interaction" : "interacts with",
        "SUID" : 1684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1683",
        "source" : "853",
        "target" : "827",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) rf_hypatia",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) rf_hypatia",
        "interaction" : "interacts with",
        "SUID" : 1683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1682",
        "source" : "853",
        "target" : "826",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) JoshHoltz7",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) JoshHoltz7",
        "interaction" : "interacts with",
        "SUID" : 1682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1681",
        "source" : "853",
        "target" : "825",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) bebi_lovely",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) bebi_lovely",
        "interaction" : "interacts with",
        "SUID" : 1681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1680",
        "source" : "853",
        "target" : "824",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) PattyWitrado",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) PattyWitrado",
        "interaction" : "interacts with",
        "SUID" : 1680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1679",
        "source" : "853",
        "target" : "823",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Scrrubsss",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Scrrubsss",
        "interaction" : "interacts with",
        "SUID" : 1679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1678",
        "source" : "853",
        "target" : "822",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Xarathos",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Xarathos",
        "interaction" : "interacts with",
        "SUID" : 1678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1677",
        "source" : "853",
        "target" : "821",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) divinestride",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) divinestride",
        "interaction" : "interacts with",
        "SUID" : 1677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1676",
        "source" : "853",
        "target" : "820",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) cryptoyogi108",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) cryptoyogi108",
        "interaction" : "interacts with",
        "SUID" : 1676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1675",
        "source" : "853",
        "target" : "819",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) KarylynParsons",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) KarylynParsons",
        "interaction" : "interacts with",
        "SUID" : 1675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1674",
        "source" : "853",
        "target" : "818",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) DemetriusDjc",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) DemetriusDjc",
        "interaction" : "interacts with",
        "SUID" : 1674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1673",
        "source" : "853",
        "target" : "817",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) hapapanda_",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) hapapanda_",
        "interaction" : "interacts with",
        "SUID" : 1673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1672",
        "source" : "853",
        "target" : "816",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) NishaniAlways",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) NishaniAlways",
        "interaction" : "interacts with",
        "SUID" : 1672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1671",
        "source" : "853",
        "target" : "815",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) TammyBl06054784",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) TammyBl06054784",
        "interaction" : "interacts with",
        "SUID" : 1671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1670",
        "source" : "853",
        "target" : "814",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) ArayAromaz",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) ArayAromaz",
        "interaction" : "interacts with",
        "SUID" : 1670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1669",
        "source" : "853",
        "target" : "813",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) godzillo_",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) godzillo_",
        "interaction" : "interacts with",
        "SUID" : 1669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1668",
        "source" : "853",
        "target" : "812",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) FromTheShadow16",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) FromTheShadow16",
        "interaction" : "interacts with",
        "SUID" : 1668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1667",
        "source" : "853",
        "target" : "811",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) schristine2315",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) schristine2315",
        "interaction" : "interacts with",
        "SUID" : 1667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1666",
        "source" : "853",
        "target" : "810",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) ArnesonGuides",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) ArnesonGuides",
        "interaction" : "interacts with",
        "SUID" : 1666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1665",
        "source" : "853",
        "target" : "809",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) LcvPw",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) LcvPw",
        "interaction" : "interacts with",
        "SUID" : 1665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1664",
        "source" : "853",
        "target" : "808",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) FbayareaS",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) FbayareaS",
        "interaction" : "interacts with",
        "SUID" : 1664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1663",
        "source" : "853",
        "target" : "807",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) danielwhelan",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) danielwhelan",
        "interaction" : "interacts with",
        "SUID" : 1663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1662",
        "source" : "853",
        "target" : "806",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Rogerma46478074",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Rogerma46478074",
        "interaction" : "interacts with",
        "SUID" : 1662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "source" : "853",
        "target" : "805",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) spmarx",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) spmarx",
        "interaction" : "interacts with",
        "SUID" : 1661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1660",
        "source" : "853",
        "target" : "804",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) MantraToday",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) MantraToday",
        "interaction" : "interacts with",
        "SUID" : 1660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1659",
        "source" : "853",
        "target" : "803",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) yangabbard",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) yangabbard",
        "interaction" : "interacts with",
        "SUID" : 1659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1658",
        "source" : "853",
        "target" : "802",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Chandlergt",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Chandlergt",
        "interaction" : "interacts with",
        "SUID" : 1658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1657",
        "source" : "853",
        "target" : "801",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) HankAnd96259025",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) HankAnd96259025",
        "interaction" : "interacts with",
        "SUID" : 1657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1656",
        "source" : "853",
        "target" : "800",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) 326kanav",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) 326kanav",
        "interaction" : "interacts with",
        "SUID" : 1656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1655",
        "source" : "853",
        "target" : "799",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) ToroDelMar1",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) ToroDelMar1",
        "interaction" : "interacts with",
        "SUID" : 1655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1654",
        "source" : "853",
        "target" : "798",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Hebrewsaurusre1",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Hebrewsaurusre1",
        "interaction" : "interacts with",
        "SUID" : 1654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1653",
        "source" : "853",
        "target" : "797",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) vanguardreview",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) vanguardreview",
        "interaction" : "interacts with",
        "SUID" : 1653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1652",
        "source" : "853",
        "target" : "796",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) badjulio",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) badjulio",
        "interaction" : "interacts with",
        "SUID" : 1652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1651",
        "source" : "853",
        "target" : "795",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) austinm419",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) austinm419",
        "interaction" : "interacts with",
        "SUID" : 1651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1650",
        "source" : "853",
        "target" : "794",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) CaptnAtheist",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) CaptnAtheist",
        "interaction" : "interacts with",
        "SUID" : 1650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1649",
        "source" : "853",
        "target" : "793",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) Emsatthedisco",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) Emsatthedisco",
        "interaction" : "interacts with",
        "SUID" : 1649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1648",
        "source" : "853",
        "target" : "792",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) sloppyjoehotdog",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) sloppyjoehotdog",
        "interaction" : "interacts with",
        "SUID" : 1648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1647",
        "source" : "853",
        "target" : "791",
        "EdgeBetweenness" : 17.0,
        "shared_name" : "ClickThatFollow (interacts with) KamWah888",
        "shared_interaction" : "interacts with",
        "name" : "ClickThatFollow (interacts with) KamWah888",
        "interaction" : "interacts with",
        "SUID" : 1647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1646",
        "source" : "790",
        "target" : "789",
        "EdgeBetweenness" : 1269.0,
        "shared_name" : "NaattuVarthakal (interacts with) TheSCANFndtn",
        "shared_interaction" : "interacts with",
        "name" : "NaattuVarthakal (interacts with) TheSCANFndtn",
        "interaction" : "interacts with",
        "SUID" : 1646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1645",
        "source" : "790",
        "target" : "788",
        "EdgeBetweenness" : 564.0,
        "shared_name" : "NaattuVarthakal (interacts with) TrevorGriffey",
        "shared_interaction" : "interacts with",
        "name" : "NaattuVarthakal (interacts with) TrevorGriffey",
        "interaction" : "interacts with",
        "SUID" : 1645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1644",
        "source" : "790",
        "target" : "787",
        "EdgeBetweenness" : 564.0,
        "shared_name" : "NaattuVarthakal (interacts with) alexsapps",
        "shared_interaction" : "interacts with",
        "name" : "NaattuVarthakal (interacts with) alexsapps",
        "interaction" : "interacts with",
        "SUID" : 1644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1643",
        "source" : "789",
        "target" : "786",
        "EdgeBetweenness" : 186.0,
        "shared_name" : "TheSCANFndtn (interacts with) Dr_Gretch",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) Dr_Gretch",
        "interaction" : "interacts with",
        "SUID" : 1643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1642",
        "source" : "789",
        "target" : "785",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) SeniorTypes",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) SeniorTypes",
        "interaction" : "interacts with",
        "SUID" : 1642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1641",
        "source" : "789",
        "target" : "784",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) InaJaffeNPR",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) InaJaffeNPR",
        "interaction" : "interacts with",
        "SUID" : 1641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1640",
        "source" : "789",
        "target" : "783",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) NORCNews",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) NORCNews",
        "interaction" : "interacts with",
        "SUID" : 1640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1639",
        "source" : "789",
        "target" : "782",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) HollywdHealth",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) HollywdHealth",
        "interaction" : "interacts with",
        "SUID" : 1639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1638",
        "source" : "789",
        "target" : "781",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) DrJasonLee",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) DrJasonLee",
        "interaction" : "interacts with",
        "SUID" : 1638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1637",
        "source" : "789",
        "target" : "780",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) johnahartford",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) johnahartford",
        "interaction" : "interacts with",
        "SUID" : 1637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1636",
        "source" : "789",
        "target" : "779",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) posttaseniors",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) posttaseniors",
        "interaction" : "interacts with",
        "SUID" : 1636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1635",
        "source" : "789",
        "target" : "778",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) FamDocDon",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) FamDocDon",
        "interaction" : "interacts with",
        "SUID" : 1635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1634",
        "source" : "789",
        "target" : "777",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) DrAnkurB",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) DrAnkurB",
        "interaction" : "interacts with",
        "SUID" : 1634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1633",
        "source" : "789",
        "target" : "776",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) AdiraFound",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) AdiraFound",
        "interaction" : "interacts with",
        "SUID" : 1633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1632",
        "source" : "789",
        "target" : "775",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) CentersSenior",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) CentersSenior",
        "interaction" : "interacts with",
        "SUID" : 1632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1631",
        "source" : "789",
        "target" : "774",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) SFTechCouncil",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) SFTechCouncil",
        "interaction" : "interacts with",
        "SUID" : 1631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1630",
        "source" : "789",
        "target" : "773",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) capolenick",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) capolenick",
        "interaction" : "interacts with",
        "SUID" : 1630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1629",
        "source" : "789",
        "target" : "772",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) iamamyherr",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) iamamyherr",
        "interaction" : "interacts with",
        "SUID" : 1629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1628",
        "source" : "789",
        "target" : "771",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) MaryDNaylor",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) MaryDNaylor",
        "interaction" : "interacts with",
        "SUID" : 1628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1627",
        "source" : "789",
        "target" : "770",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) PennNCTH",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) PennNCTH",
        "interaction" : "interacts with",
        "SUID" : 1627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1626",
        "source" : "789",
        "target" : "769",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) The_PPAL",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) The_PPAL",
        "interaction" : "interacts with",
        "SUID" : 1626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1625",
        "source" : "789",
        "target" : "768",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) DrBruce_TSF",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) DrBruce_TSF",
        "interaction" : "interacts with",
        "SUID" : 1625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1624",
        "source" : "789",
        "target" : "767",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) MichaelWinship",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) MichaelWinship",
        "interaction" : "interacts with",
        "SUID" : 1624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1623",
        "source" : "789",
        "target" : "766",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) ThatVDOVault",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) ThatVDOVault",
        "interaction" : "interacts with",
        "SUID" : 1623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1622",
        "source" : "789",
        "target" : "765",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) Yoloaging",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) Yoloaging",
        "interaction" : "interacts with",
        "SUID" : 1622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1621",
        "source" : "789",
        "target" : "764",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) WestHealth",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) WestHealth",
        "interaction" : "interacts with",
        "SUID" : 1621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1620",
        "source" : "789",
        "target" : "763",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) shelleylyford",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) shelleylyford",
        "interaction" : "interacts with",
        "SUID" : 1620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1619",
        "source" : "789",
        "target" : "762",
        "EdgeBetweenness" : 93.0,
        "shared_name" : "TheSCANFndtn (interacts with) mari_nicholson",
        "shared_interaction" : "interacts with",
        "name" : "TheSCANFndtn (interacts with) mari_nicholson",
        "interaction" : "interacts with",
        "SUID" : 1619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1618",
        "source" : "788",
        "target" : "201",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) ProfPeterCole",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) ProfPeterCole",
        "interaction" : "interacts with",
        "SUID" : 1618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1617",
        "source" : "788",
        "target" : "200",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) DavidpStein",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) DavidpStein",
        "interaction" : "interacts with",
        "SUID" : 1617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1616",
        "source" : "788",
        "target" : "199",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) MollyTalcott",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) MollyTalcott",
        "interaction" : "interacts with",
        "SUID" : 1616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1615",
        "source" : "788",
        "target" : "198",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) balti_less",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) balti_less",
        "interaction" : "interacts with",
        "SUID" : 1615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1614",
        "source" : "788",
        "target" : "197",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) UCAFT_UCLA",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) UCAFT_UCLA",
        "interaction" : "interacts with",
        "SUID" : 1614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1613",
        "source" : "788",
        "target" : "196",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) daniyure",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) daniyure",
        "interaction" : "interacts with",
        "SUID" : 1613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1612",
        "source" : "788",
        "target" : "195",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) SmTcontingent",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) SmTcontingent",
        "interaction" : "interacts with",
        "SUID" : 1612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1611",
        "source" : "788",
        "target" : "194",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) bulat666",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) bulat666",
        "interaction" : "interacts with",
        "SUID" : 1611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1610",
        "source" : "788",
        "target" : "193",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) professor_berry",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) professor_berry",
        "interaction" : "interacts with",
        "SUID" : 1610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "source" : "788",
        "target" : "192",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) annebailey63",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) annebailey63",
        "interaction" : "interacts with",
        "SUID" : 1609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1608",
        "source" : "788",
        "target" : "191",
        "EdgeBetweenness" : 98.0,
        "shared_name" : "TrevorGriffey (interacts with) dmnd_the_mpssbl",
        "shared_interaction" : "interacts with",
        "name" : "TrevorGriffey (interacts with) dmnd_the_mpssbl",
        "interaction" : "interacts with",
        "SUID" : 1608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1607",
        "source" : "787",
        "target" : "160",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) Sally8229650811",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) Sally8229650811",
        "interaction" : "interacts with",
        "SUID" : 1607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1606",
        "source" : "787",
        "target" : "159",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) Animabando",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) Animabando",
        "interaction" : "interacts with",
        "SUID" : 1606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1605",
        "source" : "787",
        "target" : "158",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) Gaia10280169",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) Gaia10280169",
        "interaction" : "interacts with",
        "SUID" : 1605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1604",
        "source" : "787",
        "target" : "157",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) MexicoSecuestra",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) MexicoSecuestra",
        "interaction" : "interacts with",
        "SUID" : 1604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1603",
        "source" : "787",
        "target" : "156",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) angie_renati",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) angie_renati",
        "interaction" : "interacts with",
        "SUID" : 1603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1602",
        "source" : "787",
        "target" : "155",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) victori18964840",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) victori18964840",
        "interaction" : "interacts with",
        "SUID" : 1602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1601",
        "source" : "787",
        "target" : "154",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) MizGiz",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) MizGiz",
        "interaction" : "interacts with",
        "SUID" : 1601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1600",
        "source" : "787",
        "target" : "153",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) LeviVegan",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) LeviVegan",
        "interaction" : "interacts with",
        "SUID" : 1600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1599",
        "source" : "787",
        "target" : "152",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) geraldineiris21",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) geraldineiris21",
        "interaction" : "interacts with",
        "SUID" : 1599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1598",
        "source" : "787",
        "target" : "151",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) PurpleApePal",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) PurpleApePal",
        "interaction" : "interacts with",
        "SUID" : 1598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1597",
        "source" : "787",
        "target" : "150",
        "EdgeBetweenness" : 91.0,
        "shared_name" : "alexsapps (interacts with) PhaedraXTeddy",
        "shared_interaction" : "interacts with",
        "name" : "alexsapps (interacts with) PhaedraXTeddy",
        "interaction" : "interacts with",
        "SUID" : 1597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1596",
        "source" : "786",
        "target" : "761",
        "EdgeBetweenness" : 136.0,
        "shared_name" : "Dr_Gretch (interacts with) amymyork2",
        "shared_interaction" : "interacts with",
        "name" : "Dr_Gretch (interacts with) amymyork2",
        "interaction" : "interacts with",
        "SUID" : 1596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1595",
        "source" : "786",
        "target" : "772",
        "EdgeBetweenness" : 43.0,
        "shared_name" : "Dr_Gretch (interacts with) iamamyherr",
        "shared_interaction" : "interacts with",
        "name" : "Dr_Gretch (interacts with) iamamyherr",
        "interaction" : "interacts with",
        "SUID" : 1595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1594",
        "source" : "760",
        "target" : "759",
        "EdgeBetweenness" : 272.0,
        "shared_name" : "harrisonplam (interacts with) UCIrvineSOM",
        "shared_interaction" : "interacts with",
        "name" : "harrisonplam (interacts with) UCIrvineSOM",
        "interaction" : "interacts with",
        "SUID" : 1594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1593",
        "source" : "759",
        "target" : "758",
        "EdgeBetweenness" : 31.0,
        "shared_name" : "UCIrvineSOM (interacts with) UCIrvineSurgery",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineSOM (interacts with) UCIrvineSurgery",
        "interaction" : "interacts with",
        "SUID" : 1593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1592",
        "source" : "759",
        "target" : "757",
        "EdgeBetweenness" : 465.0,
        "shared_name" : "UCIrvineSOM (interacts with) ucinursing",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineSOM (interacts with) ucinursing",
        "interaction" : "interacts with",
        "SUID" : 1592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1591",
        "source" : "757",
        "target" : "756",
        "EdgeBetweenness" : 546.0,
        "shared_name" : "ucinursing (interacts with) UCIrvineHealth",
        "shared_interaction" : "interacts with",
        "name" : "ucinursing (interacts with) UCIrvineHealth",
        "interaction" : "interacts with",
        "SUID" : 1591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1590",
        "source" : "757",
        "target" : "755",
        "EdgeBetweenness" : 42.0,
        "shared_name" : "ucinursing (interacts with) ucipeds",
        "shared_interaction" : "interacts with",
        "name" : "ucinursing (interacts with) ucipeds",
        "interaction" : "interacts with",
        "SUID" : 1590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1589",
        "source" : "756",
        "target" : "755",
        "EdgeBetweenness" : 120.0,
        "shared_name" : "UCIrvineHealth (interacts with) ucipeds",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) ucipeds",
        "interaction" : "interacts with",
        "SUID" : 1589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1588",
        "source" : "756",
        "target" : "754",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "UCIrvineHealth (interacts with) UCI_OVCHA",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) UCI_OVCHA",
        "interaction" : "interacts with",
        "SUID" : 1588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1587",
        "source" : "756",
        "target" : "872",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "UCIrvineHealth (interacts with) _BrittanyMun",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) _BrittanyMun",
        "interaction" : "interacts with",
        "SUID" : 1587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1586",
        "source" : "756",
        "target" : "753",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "UCIrvineHealth (interacts with) ucimath",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) ucimath",
        "interaction" : "interacts with",
        "SUID" : 1586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1585",
        "source" : "756",
        "target" : "752",
        "EdgeBetweenness" : 810.0,
        "shared_name" : "UCIrvineHealth (interacts with) UCIrvine",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) UCIrvine",
        "interaction" : "interacts with",
        "SUID" : 1585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1584",
        "source" : "756",
        "target" : "751",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "UCIrvineHealth (interacts with) nowvoyagertravl",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) nowvoyagertravl",
        "interaction" : "interacts with",
        "SUID" : 1584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1583",
        "source" : "756",
        "target" : "750",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "UCIrvineHealth (interacts with) CoyoteDucks54",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) CoyoteDucks54",
        "interaction" : "interacts with",
        "SUID" : 1583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1582",
        "source" : "756",
        "target" : "749",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "UCIrvineHealth (interacts with) q22q17",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) q22q17",
        "interaction" : "interacts with",
        "SUID" : 1582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1581",
        "source" : "756",
        "target" : "748",
        "EdgeBetweenness" : 162.0,
        "shared_name" : "UCIrvineHealth (interacts with) GoDucks910",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvineHealth (interacts with) GoDucks910",
        "interaction" : "interacts with",
        "SUID" : 1581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1580",
        "source" : "754",
        "target" : "755",
        "EdgeBetweenness" : 397.0,
        "shared_name" : "UCI_OVCHA (interacts with) ucipeds",
        "shared_interaction" : "interacts with",
        "name" : "UCI_OVCHA (interacts with) ucipeds",
        "interaction" : "interacts with",
        "SUID" : 1580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1579",
        "source" : "752",
        "target" : "207",
        "EdgeBetweenness" : 1112.0,
        "shared_name" : "UCIrvine (interacts with) UCIPubAffairs",
        "shared_interaction" : "interacts with",
        "name" : "UCIrvine (interacts with) UCIPubAffairs",
        "interaction" : "interacts with",
        "SUID" : 1579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1578",
        "source" : "747",
        "target" : "746",
        "EdgeBetweenness" : 55205.0,
        "shared_name" : "Csomethingelse (interacts with) RepBarragan",
        "shared_interaction" : "interacts with",
        "name" : "Csomethingelse (interacts with) RepBarragan",
        "interaction" : "interacts with",
        "SUID" : 1578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1577",
        "source" : "746",
        "target" : "745",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) PoliticalBee",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) PoliticalBee",
        "interaction" : "interacts with",
        "SUID" : 1577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1576",
        "source" : "746",
        "target" : "744",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) MesMitch",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) MesMitch",
        "interaction" : "interacts with",
        "SUID" : 1576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1575",
        "source" : "746",
        "target" : "743",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) SLT_3",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) SLT_3",
        "interaction" : "interacts with",
        "SUID" : 1575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1574",
        "source" : "746",
        "target" : "742",
        "EdgeBetweenness" : 33495.0,
        "shared_name" : "RepBarragan (interacts with) tomasrabago1",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) tomasrabago1",
        "interaction" : "interacts with",
        "SUID" : 1574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1573",
        "source" : "746",
        "target" : "741",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) EnergyCommerce",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) EnergyCommerce",
        "interaction" : "interacts with",
        "SUID" : 1573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1572",
        "source" : "746",
        "target" : "740",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) DanLimmert",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) DanLimmert",
        "interaction" : "interacts with",
        "SUID" : 1572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1571",
        "source" : "746",
        "target" : "739",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) delgadodaphne",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) delgadodaphne",
        "interaction" : "interacts with",
        "SUID" : 1571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1570",
        "source" : "746",
        "target" : "738",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) DaraLieb",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) DaraLieb",
        "interaction" : "interacts with",
        "SUID" : 1570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1569",
        "source" : "746",
        "target" : "737",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) minter01",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) minter01",
        "interaction" : "interacts with",
        "SUID" : 1569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1568",
        "source" : "746",
        "target" : "736",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) Evcoc54",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) Evcoc54",
        "interaction" : "interacts with",
        "SUID" : 1568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1567",
        "source" : "746",
        "target" : "735",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) clandersen",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) clandersen",
        "interaction" : "interacts with",
        "SUID" : 1567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1566",
        "source" : "746",
        "target" : "734",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) UniteBlue",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) UniteBlue",
        "interaction" : "interacts with",
        "SUID" : 1566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1565",
        "source" : "746",
        "target" : "733",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) joy31608",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) joy31608",
        "interaction" : "interacts with",
        "SUID" : 1565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1564",
        "source" : "746",
        "target" : "924",
        "EdgeBetweenness" : 42630.0,
        "shared_name" : "RepBarragan (interacts with) All435Reps",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) All435Reps",
        "interaction" : "interacts with",
        "SUID" : 1564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1563",
        "source" : "746",
        "target" : "732",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) oregon_zoe",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) oregon_zoe",
        "interaction" : "interacts with",
        "SUID" : 1563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1562",
        "source" : "746",
        "target" : "731",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) pelon_0914",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) pelon_0914",
        "interaction" : "interacts with",
        "SUID" : 1562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1561",
        "source" : "746",
        "target" : "730",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) BusyBes",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) BusyBes",
        "interaction" : "interacts with",
        "SUID" : 1561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1560",
        "source" : "746",
        "target" : "729",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) CocoaSwann",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) CocoaSwann",
        "interaction" : "interacts with",
        "SUID" : 1560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1559",
        "source" : "746",
        "target" : "728",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) RepBonnie",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) RepBonnie",
        "interaction" : "interacts with",
        "SUID" : 1559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1558",
        "source" : "746",
        "target" : "727",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) Djama18291981",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) Djama18291981",
        "interaction" : "interacts with",
        "SUID" : 1558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1557",
        "source" : "746",
        "target" : "726",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) JanuaryHandl",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) JanuaryHandl",
        "interaction" : "interacts with",
        "SUID" : 1557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1556",
        "source" : "746",
        "target" : "725",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) SpoaSteph",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) SpoaSteph",
        "interaction" : "interacts with",
        "SUID" : 1556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1555",
        "source" : "746",
        "target" : "724",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) juant_info",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) juant_info",
        "interaction" : "interacts with",
        "SUID" : 1555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1554",
        "source" : "746",
        "target" : "723",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) DahHipster",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) DahHipster",
        "interaction" : "interacts with",
        "SUID" : 1554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1553",
        "source" : "746",
        "target" : "722",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) IMPEACH_putin",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) IMPEACH_putin",
        "interaction" : "interacts with",
        "SUID" : 1553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1552",
        "source" : "746",
        "target" : "721",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) JuanHinojosAZ",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) JuanHinojosAZ",
        "interaction" : "interacts with",
        "SUID" : 1552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1551",
        "source" : "746",
        "target" : "720",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) sabinenamba",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) sabinenamba",
        "interaction" : "interacts with",
        "SUID" : 1551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1550",
        "source" : "746",
        "target" : "719",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) dumpbloatus",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) dumpbloatus",
        "interaction" : "interacts with",
        "SUID" : 1550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1549",
        "source" : "746",
        "target" : "718",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) eeyoresmother",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) eeyoresmother",
        "interaction" : "interacts with",
        "SUID" : 1549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1548",
        "source" : "746",
        "target" : "717",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) Viccimn",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) Viccimn",
        "interaction" : "interacts with",
        "SUID" : 1548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1547",
        "source" : "746",
        "target" : "716",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) chelbeans",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) chelbeans",
        "interaction" : "interacts with",
        "SUID" : 1547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1546",
        "source" : "746",
        "target" : "715",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) aliskander81",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) aliskander81",
        "interaction" : "interacts with",
        "SUID" : 1546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1545",
        "source" : "746",
        "target" : "714",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) AhnJungGeun888",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) AhnJungGeun888",
        "interaction" : "interacts with",
        "SUID" : 1545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1544",
        "source" : "746",
        "target" : "713",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) IncanSusan",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) IncanSusan",
        "interaction" : "interacts with",
        "SUID" : 1544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1543",
        "source" : "746",
        "target" : "712",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) MelindaTolley",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) MelindaTolley",
        "interaction" : "interacts with",
        "SUID" : 1543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1542",
        "source" : "746",
        "target" : "711",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) JaymieRose",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) JaymieRose",
        "interaction" : "interacts with",
        "SUID" : 1542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1541",
        "source" : "746",
        "target" : "710",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) JakeSpectre89",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) JakeSpectre89",
        "interaction" : "interacts with",
        "SUID" : 1541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1540",
        "source" : "746",
        "target" : "709",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) LucyMFel",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) LucyMFel",
        "interaction" : "interacts with",
        "SUID" : 1540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1539",
        "source" : "746",
        "target" : "708",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) Violetkim",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) Violetkim",
        "interaction" : "interacts with",
        "SUID" : 1539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1538",
        "source" : "746",
        "target" : "707",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) Blur15357148",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) Blur15357148",
        "interaction" : "interacts with",
        "SUID" : 1538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1537",
        "source" : "746",
        "target" : "706",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) RepBobbyRush",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) RepBobbyRush",
        "interaction" : "interacts with",
        "SUID" : 1537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1536",
        "source" : "746",
        "target" : "705",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) DavidOCarterCA",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) DavidOCarterCA",
        "interaction" : "interacts with",
        "SUID" : 1536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1535",
        "source" : "746",
        "target" : "704",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) prime_bee",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) prime_bee",
        "interaction" : "interacts with",
        "SUID" : 1535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1534",
        "source" : "746",
        "target" : "746",
        "EdgeBetweenness" : 0.0,
        "shared_name" : "RepBarragan (interacts with) RepBarragan",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) RepBarragan",
        "interaction" : "interacts with",
        "SUID" : 1534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1533",
        "source" : "746",
        "target" : "703",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) penndragonArt",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) penndragonArt",
        "interaction" : "interacts with",
        "SUID" : 1533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1532",
        "source" : "746",
        "target" : "702",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) Chercher08",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) Chercher08",
        "interaction" : "interacts with",
        "SUID" : 1532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1531",
        "source" : "746",
        "target" : "701",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) m0nicuuhh",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) m0nicuuhh",
        "interaction" : "interacts with",
        "SUID" : 1531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1530",
        "source" : "746",
        "target" : "700",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) DefendOurFuture",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) DefendOurFuture",
        "interaction" : "interacts with",
        "SUID" : 1530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1529",
        "source" : "746",
        "target" : "699",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) JHF719",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) JHF719",
        "interaction" : "interacts with",
        "SUID" : 1529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1528",
        "source" : "746",
        "target" : "698",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) ecowarrior350",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) ecowarrior350",
        "interaction" : "interacts with",
        "SUID" : 1528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1527",
        "source" : "746",
        "target" : "697",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) SEEC",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) SEEC",
        "interaction" : "interacts with",
        "SUID" : 1527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1526",
        "source" : "746",
        "target" : "696",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) dwatchnews",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) dwatchnews",
        "interaction" : "interacts with",
        "SUID" : 1526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1525",
        "source" : "746",
        "target" : "695",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) harviolet",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) harviolet",
        "interaction" : "interacts with",
        "SUID" : 1525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1524",
        "source" : "746",
        "target" : "694",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) AnnaMHargrave",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) AnnaMHargrave",
        "interaction" : "interacts with",
        "SUID" : 1524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1523",
        "source" : "746",
        "target" : "693",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) pinky_or_brain",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) pinky_or_brain",
        "interaction" : "interacts with",
        "SUID" : 1523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1522",
        "source" : "746",
        "target" : "692",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) SayHere1st_Last",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) SayHere1st_Last",
        "interaction" : "interacts with",
        "SUID" : 1522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1521",
        "source" : "746",
        "target" : "691",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) MattDernoga",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) MattDernoga",
        "interaction" : "interacts with",
        "SUID" : 1521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1520",
        "source" : "746",
        "target" : "690",
        "EdgeBetweenness" : 609.0,
        "shared_name" : "RepBarragan (interacts with) Starbright489",
        "shared_interaction" : "interacts with",
        "name" : "RepBarragan (interacts with) Starbright489",
        "interaction" : "interacts with",
        "SUID" : 1520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1519",
        "source" : "742",
        "target" : "662",
        "EdgeBetweenness" : 2715.0,
        "shared_name" : "tomasrabago1 (interacts with) LBEconDev",
        "shared_interaction" : "interacts with",
        "name" : "tomasrabago1 (interacts with) LBEconDev",
        "interaction" : "interacts with",
        "SUID" : 1519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1518",
        "source" : "742",
        "target" : "661",
        "EdgeBetweenness" : 34390.0,
        "shared_name" : "tomasrabago1 (interacts with) LongBeachMayor",
        "shared_interaction" : "interacts with",
        "name" : "tomasrabago1 (interacts with) LongBeachMayor",
        "interaction" : "interacts with",
        "SUID" : 1518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1517",
        "source" : "742",
        "target" : "660",
        "EdgeBetweenness" : 5430.0,
        "shared_name" : "tomasrabago1 (interacts with) SupJaniceHahn",
        "shared_interaction" : "interacts with",
        "name" : "tomasrabago1 (interacts with) SupJaniceHahn",
        "interaction" : "interacts with",
        "SUID" : 1517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1516",
        "source" : "742",
        "target" : "659",
        "EdgeBetweenness" : 6335.0,
        "shared_name" : "tomasrabago1 (interacts with) RobertGarciaLB",
        "shared_interaction" : "interacts with",
        "name" : "tomasrabago1 (interacts with) RobertGarciaLB",
        "interaction" : "interacts with",
        "SUID" : 1516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1515",
        "source" : "689",
        "target" : "303",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) MikePhilbrick2",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) MikePhilbrick2",
        "interaction" : "interacts with",
        "SUID" : 1515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1514",
        "source" : "689",
        "target" : "302",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) CharlieInUtah",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) CharlieInUtah",
        "interaction" : "interacts with",
        "SUID" : 1514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1513",
        "source" : "689",
        "target" : "301",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) CharlesPumilia",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) CharlesPumilia",
        "interaction" : "interacts with",
        "SUID" : 1513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1512",
        "source" : "689",
        "target" : "300",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) Stone1ML",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) Stone1ML",
        "interaction" : "interacts with",
        "SUID" : 1512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1511",
        "source" : "689",
        "target" : "299",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) 1jasliz",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) 1jasliz",
        "interaction" : "interacts with",
        "SUID" : 1511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1510",
        "source" : "689",
        "target" : "298",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) AnnieMartin5353",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) AnnieMartin5353",
        "interaction" : "interacts with",
        "SUID" : 1510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1509",
        "source" : "689",
        "target" : "297",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) BradStarks",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) BradStarks",
        "interaction" : "interacts with",
        "SUID" : 1509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1508",
        "source" : "689",
        "target" : "296",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) Kane007",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) Kane007",
        "interaction" : "interacts with",
        "SUID" : 1508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1507",
        "source" : "689",
        "target" : "295",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) zannerina",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) zannerina",
        "interaction" : "interacts with",
        "SUID" : 1507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1506",
        "source" : "689",
        "target" : "294",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) frankie5563",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) frankie5563",
        "interaction" : "interacts with",
        "SUID" : 1506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1505",
        "source" : "689",
        "target" : "293",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) AaarUci",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) AaarUci",
        "interaction" : "interacts with",
        "SUID" : 1505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1504",
        "source" : "689",
        "target" : "292",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) genevieveisgg",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) genevieveisgg",
        "interaction" : "interacts with",
        "SUID" : 1504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1503",
        "source" : "689",
        "target" : "291",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) StacyBierlein",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) StacyBierlein",
        "interaction" : "interacts with",
        "SUID" : 1503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1502",
        "source" : "689",
        "target" : "290",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) DeidreFolkman",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) DeidreFolkman",
        "interaction" : "interacts with",
        "SUID" : 1502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1501",
        "source" : "689",
        "target" : "289",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) HearMeRoar53881",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) HearMeRoar53881",
        "interaction" : "interacts with",
        "SUID" : 1501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1500",
        "source" : "689",
        "target" : "288",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) LTSwrite",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) LTSwrite",
        "interaction" : "interacts with",
        "SUID" : 1500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1499",
        "source" : "689",
        "target" : "287",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) halest793",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) halest793",
        "interaction" : "interacts with",
        "SUID" : 1499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1498",
        "source" : "689",
        "target" : "286",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) JNicole1979",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) JNicole1979",
        "interaction" : "interacts with",
        "SUID" : 1498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1497",
        "source" : "689",
        "target" : "285",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) diamondnill1",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) diamondnill1",
        "interaction" : "interacts with",
        "SUID" : 1497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1496",
        "source" : "689",
        "target" : "284",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) kerrterrpg",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) kerrterrpg",
        "interaction" : "interacts with",
        "SUID" : 1496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1495",
        "source" : "689",
        "target" : "283",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) WeTheSisters",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) WeTheSisters",
        "interaction" : "interacts with",
        "SUID" : 1495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1494",
        "source" : "689",
        "target" : "282",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) LolaGLR",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) LolaGLR",
        "interaction" : "interacts with",
        "SUID" : 1494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1493",
        "source" : "689",
        "target" : "281",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) bjack417",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) bjack417",
        "interaction" : "interacts with",
        "SUID" : 1493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1492",
        "source" : "689",
        "target" : "280",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) kellyswanholm",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) kellyswanholm",
        "interaction" : "interacts with",
        "SUID" : 1492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1491",
        "source" : "689",
        "target" : "279",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) annmorse101",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) annmorse101",
        "interaction" : "interacts with",
        "SUID" : 1491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1490",
        "source" : "689",
        "target" : "278",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) BBrynteson",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) BBrynteson",
        "interaction" : "interacts with",
        "SUID" : 1490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1489",
        "source" : "689",
        "target" : "277",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) tessady",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) tessady",
        "interaction" : "interacts with",
        "SUID" : 1489,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1488",
        "source" : "689",
        "target" : "276",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) lynnmarks",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) lynnmarks",
        "interaction" : "interacts with",
        "SUID" : 1488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1487",
        "source" : "689",
        "target" : "275",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) NoraWD",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) NoraWD",
        "interaction" : "interacts with",
        "SUID" : 1487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1486",
        "source" : "689",
        "target" : "274",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) phyllis20",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) phyllis20",
        "interaction" : "interacts with",
        "SUID" : 1486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1485",
        "source" : "689",
        "target" : "273",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) CindyAcuff",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) CindyAcuff",
        "interaction" : "interacts with",
        "SUID" : 1485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1484",
        "source" : "689",
        "target" : "272",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) lebibyc",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) lebibyc",
        "interaction" : "interacts with",
        "SUID" : 1484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1483",
        "source" : "689",
        "target" : "271",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) perrymeade",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) perrymeade",
        "interaction" : "interacts with",
        "SUID" : 1483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1482",
        "source" : "689",
        "target" : "270",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) sempercuriosa",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) sempercuriosa",
        "interaction" : "interacts with",
        "SUID" : 1482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1481",
        "source" : "689",
        "target" : "269",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) LoveForAll24",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) LoveForAll24",
        "interaction" : "interacts with",
        "SUID" : 1481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1480",
        "source" : "689",
        "target" : "268",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) DanielRossSala1",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) DanielRossSala1",
        "interaction" : "interacts with",
        "SUID" : 1480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1479",
        "source" : "689",
        "target" : "267",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) pscrip",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) pscrip",
        "interaction" : "interacts with",
        "SUID" : 1479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1478",
        "source" : "689",
        "target" : "266",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) MrFrankV",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) MrFrankV",
        "interaction" : "interacts with",
        "SUID" : 1478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1477",
        "source" : "689",
        "target" : "265",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) mattfromCal1",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) mattfromCal1",
        "interaction" : "interacts with",
        "SUID" : 1477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1476",
        "source" : "689",
        "target" : "264",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) aIysawang",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) aIysawang",
        "interaction" : "interacts with",
        "SUID" : 1476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1475",
        "source" : "689",
        "target" : "263",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) Gilly79413339",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) Gilly79413339",
        "interaction" : "interacts with",
        "SUID" : 1475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1474",
        "source" : "689",
        "target" : "262",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) mlmetz5612",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) mlmetz5612",
        "interaction" : "interacts with",
        "SUID" : 1474,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1473",
        "source" : "689",
        "target" : "261",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) Cali4niaCarolyn",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) Cali4niaCarolyn",
        "interaction" : "interacts with",
        "SUID" : 1473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1472",
        "source" : "689",
        "target" : "260",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) mlighty60",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) mlighty60",
        "interaction" : "interacts with",
        "SUID" : 1472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1471",
        "source" : "689",
        "target" : "259",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) earthmother634",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) earthmother634",
        "interaction" : "interacts with",
        "SUID" : 1471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1470",
        "source" : "689",
        "target" : "258",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) posybunny",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) posybunny",
        "interaction" : "interacts with",
        "SUID" : 1470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1469",
        "source" : "689",
        "target" : "257",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) VickySchulte6",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) VickySchulte6",
        "interaction" : "interacts with",
        "SUID" : 1469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1468",
        "source" : "689",
        "target" : "256",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) GlambertInKY",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) GlambertInKY",
        "interaction" : "interacts with",
        "SUID" : 1468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1467",
        "source" : "689",
        "target" : "255",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) Lepidolite19",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) Lepidolite19",
        "interaction" : "interacts with",
        "SUID" : 1467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1466",
        "source" : "689",
        "target" : "254",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) lilxicanita",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) lilxicanita",
        "interaction" : "interacts with",
        "SUID" : 1466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1465",
        "source" : "689",
        "target" : "253",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) Motherjones38",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) Motherjones38",
        "interaction" : "interacts with",
        "SUID" : 1465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1464",
        "source" : "689",
        "target" : "252",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) nickdean707",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) nickdean707",
        "interaction" : "interacts with",
        "SUID" : 1464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1463",
        "source" : "689",
        "target" : "251",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) two_sixty_three",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) two_sixty_three",
        "interaction" : "interacts with",
        "SUID" : 1463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1462",
        "source" : "689",
        "target" : "250",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) ForwardAgenda",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) ForwardAgenda",
        "interaction" : "interacts with",
        "SUID" : 1462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1461",
        "source" : "689",
        "target" : "249",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) plzhelpmypony",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) plzhelpmypony",
        "interaction" : "interacts with",
        "SUID" : 1461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1460",
        "source" : "689",
        "target" : "248",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) mchastang84",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) mchastang84",
        "interaction" : "interacts with",
        "SUID" : 1460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1459",
        "source" : "689",
        "target" : "247",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) flybone_robin",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) flybone_robin",
        "interaction" : "interacts with",
        "SUID" : 1459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1458",
        "source" : "689",
        "target" : "246",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) Monkeys2Fly",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) Monkeys2Fly",
        "interaction" : "interacts with",
        "SUID" : 1458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "source" : "689",
        "target" : "245",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) pfb360",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) pfb360",
        "interaction" : "interacts with",
        "SUID" : 1457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1456",
        "source" : "689",
        "target" : "244",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) AdamExler",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) AdamExler",
        "interaction" : "interacts with",
        "SUID" : 1456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1455",
        "source" : "689",
        "target" : "243",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) degodolly",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) degodolly",
        "interaction" : "interacts with",
        "SUID" : 1455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1454",
        "source" : "689",
        "target" : "242",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) richiedg",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) richiedg",
        "interaction" : "interacts with",
        "SUID" : 1454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1453",
        "source" : "689",
        "target" : "241",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) RuekaA",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) RuekaA",
        "interaction" : "interacts with",
        "SUID" : 1453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1452",
        "source" : "689",
        "target" : "240",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) CAO916",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) CAO916",
        "interaction" : "interacts with",
        "SUID" : 1452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1451",
        "source" : "689",
        "target" : "239",
        "EdgeBetweenness" : 886.0,
        "shared_name" : "katieporteroc (interacts with) dolphinman47",
        "shared_interaction" : "interacts with",
        "name" : "katieporteroc (interacts with) dolphinman47",
        "interaction" : "interacts with",
        "SUID" : 1451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1450",
        "source" : "688",
        "target" : "72",
        "EdgeBetweenness" : 1201.0,
        "shared_name" : "RepGilCisneros (interacts with) persnicketyweas",
        "shared_interaction" : "interacts with",
        "name" : "RepGilCisneros (interacts with) persnicketyweas",
        "interaction" : "interacts with",
        "SUID" : 1450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1449",
        "source" : "688",
        "target" : "71",
        "EdgeBetweenness" : 1201.0,
        "shared_name" : "RepGilCisneros (interacts with) beachgirl_karen",
        "shared_interaction" : "interacts with",
        "name" : "RepGilCisneros (interacts with) beachgirl_karen",
        "interaction" : "interacts with",
        "SUID" : 1449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1448",
        "source" : "687",
        "target" : "686",
        "EdgeBetweenness" : 4800.0,
        "shared_name" : "lbpd_volunteers (interacts with) LBHealthDept",
        "shared_interaction" : "interacts with",
        "name" : "lbpd_volunteers (interacts with) LBHealthDept",
        "interaction" : "interacts with",
        "SUID" : 1448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1447",
        "source" : "686",
        "target" : "685",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) LBDisasterPrep",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) LBDisasterPrep",
        "interaction" : "interacts with",
        "SUID" : 1447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1446",
        "source" : "686",
        "target" : "684",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) Southland_CU",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) Southland_CU",
        "interaction" : "interacts with",
        "SUID" : 1446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1445",
        "source" : "686",
        "target" : "683",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) JRsagittarius",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) JRsagittarius",
        "interaction" : "interacts with",
        "SUID" : 1445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1444",
        "source" : "686",
        "target" : "682",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) McBealism1024",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) McBealism1024",
        "interaction" : "interacts with",
        "SUID" : 1444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1443",
        "source" : "686",
        "target" : "681",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) longbeachcall",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) longbeachcall",
        "interaction" : "interacts with",
        "SUID" : 1443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1442",
        "source" : "686",
        "target" : "680",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) natalierdrgzxx",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) natalierdrgzxx",
        "interaction" : "interacts with",
        "SUID" : 1442,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1441",
        "source" : "686",
        "target" : "679",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) LBTV3",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) LBTV3",
        "interaction" : "interacts with",
        "SUID" : 1441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1440",
        "source" : "686",
        "target" : "678",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) yjmpix",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) yjmpix",
        "interaction" : "interacts with",
        "SUID" : 1440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1439",
        "source" : "686",
        "target" : "677",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) AlvcaKris",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) AlvcaKris",
        "interaction" : "interacts with",
        "SUID" : 1439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1438",
        "source" : "686",
        "target" : "676",
        "EdgeBetweenness" : 1788.0,
        "shared_name" : "LBHealthDept (interacts with) RoseParkLB",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) RoseParkLB",
        "interaction" : "interacts with",
        "SUID" : 1438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1437",
        "source" : "686",
        "target" : "675",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) jrentro7",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) jrentro7",
        "interaction" : "interacts with",
        "SUID" : 1437,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1436",
        "source" : "686",
        "target" : "674",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) NerdFajuto",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) NerdFajuto",
        "interaction" : "interacts with",
        "SUID" : 1436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1435",
        "source" : "686",
        "target" : "673",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) KirkNason",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) KirkNason",
        "interaction" : "interacts with",
        "SUID" : 1435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1434",
        "source" : "686",
        "target" : "672",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) LBMayorsFund4Ed",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) LBMayorsFund4Ed",
        "interaction" : "interacts with",
        "SUID" : 1434,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1433",
        "source" : "686",
        "target" : "671",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) lara_adam_m",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) lara_adam_m",
        "interaction" : "interacts with",
        "SUID" : 1433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1432",
        "source" : "686",
        "target" : "670",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) hzlalice",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) hzlalice",
        "interaction" : "interacts with",
        "SUID" : 1432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1431",
        "source" : "686",
        "target" : "669",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) bames_jrolin",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) bames_jrolin",
        "interaction" : "interacts with",
        "SUID" : 1431,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1430",
        "source" : "686",
        "target" : "668",
        "EdgeBetweenness" : 1192.0,
        "shared_name" : "LBHealthDept (interacts with) LongBeachCity",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) LongBeachCity",
        "interaction" : "interacts with",
        "SUID" : 1430,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1429",
        "source" : "686",
        "target" : "667",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) PhoenixArielle",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) PhoenixArielle",
        "interaction" : "interacts with",
        "SUID" : 1429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1428",
        "source" : "686",
        "target" : "666",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) AGuzmanLopez",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) AGuzmanLopez",
        "interaction" : "interacts with",
        "SUID" : 1428,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "source" : "686",
        "target" : "665",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) LBSchoolNurses",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) LBSchoolNurses",
        "interaction" : "interacts with",
        "SUID" : 1427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1426",
        "source" : "686",
        "target" : "664",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) Mrsjayknee",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) Mrsjayknee",
        "interaction" : "interacts with",
        "SUID" : 1426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1425",
        "source" : "686",
        "target" : "663",
        "EdgeBetweenness" : 298.0,
        "shared_name" : "LBHealthDept (interacts with) CounselorHamlet",
        "shared_interaction" : "interacts with",
        "name" : "LBHealthDept (interacts with) CounselorHamlet",
        "interaction" : "interacts with",
        "SUID" : 1425,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1424",
        "source" : "676",
        "target" : "306",
        "EdgeBetweenness" : 1278.0,
        "shared_name" : "RoseParkLB (interacts with) MaryZendejasLB",
        "shared_interaction" : "interacts with",
        "name" : "RoseParkLB (interacts with) MaryZendejasLB",
        "interaction" : "interacts with",
        "SUID" : 1424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1423",
        "source" : "676",
        "target" : "305",
        "EdgeBetweenness" : 852.0,
        "shared_name" : "RoseParkLB (interacts with) LongBeachFresh",
        "shared_interaction" : "interacts with",
        "name" : "RoseParkLB (interacts with) LongBeachFresh",
        "interaction" : "interacts with",
        "SUID" : 1423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1422",
        "source" : "668",
        "target" : "494",
        "EdgeBetweenness" : 1497.0,
        "shared_name" : "LongBeachCity (interacts with) LBCityAuditor",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachCity (interacts with) LBCityAuditor",
        "interaction" : "interacts with",
        "SUID" : 1422,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1421",
        "source" : "668",
        "target" : "493",
        "EdgeBetweenness" : 2994.0,
        "shared_name" : "LongBeachCity (interacts with) TheCCLB",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachCity (interacts with) TheCCLB",
        "interaction" : "interacts with",
        "SUID" : 1421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1420",
        "source" : "662",
        "target" : "661",
        "EdgeBetweenness" : 3312.0,
        "shared_name" : "LBEconDev (interacts with) LongBeachMayor",
        "shared_interaction" : "interacts with",
        "name" : "LBEconDev (interacts with) LongBeachMayor",
        "interaction" : "interacts with",
        "SUID" : 1420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1419",
        "source" : "662",
        "target" : "668",
        "EdgeBetweenness" : 2178.0,
        "shared_name" : "LBEconDev (interacts with) LongBeachCity",
        "shared_interaction" : "interacts with",
        "name" : "LBEconDev (interacts with) LongBeachCity",
        "interaction" : "interacts with",
        "SUID" : 1419,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1418",
        "source" : "661",
        "target" : "669",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) bames_jrolin",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) bames_jrolin",
        "interaction" : "interacts with",
        "SUID" : 1418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1417",
        "source" : "661",
        "target" : "546",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) ccald1014",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) ccald1014",
        "interaction" : "interacts with",
        "SUID" : 1417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1416",
        "source" : "661",
        "target" : "545",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) EvaMa02543471",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) EvaMa02543471",
        "interaction" : "interacts with",
        "SUID" : 1416,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1415",
        "source" : "661",
        "target" : "668",
        "EdgeBetweenness" : 2170.0,
        "shared_name" : "LongBeachMayor (interacts with) LongBeachCity",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) LongBeachCity",
        "interaction" : "interacts with",
        "SUID" : 1415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1414",
        "source" : "661",
        "target" : "544",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) jennpruitt3",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) jennpruitt3",
        "interaction" : "interacts with",
        "SUID" : 1414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "source" : "661",
        "target" : "543",
        "EdgeBetweenness" : 13044.0,
        "shared_name" : "LongBeachMayor (interacts with) LBSchools",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) LBSchools",
        "interaction" : "interacts with",
        "SUID" : 1413,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1412",
        "source" : "661",
        "target" : "542",
        "EdgeBetweenness" : 11957.0,
        "shared_name" : "LongBeachMayor (interacts with) longbeachbobby",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) longbeachbobby",
        "interaction" : "interacts with",
        "SUID" : 1412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1411",
        "source" : "661",
        "target" : "541",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) Alma_LBC",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) Alma_LBC",
        "interaction" : "interacts with",
        "SUID" : 1411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1410",
        "source" : "661",
        "target" : "540",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) RaCuevas",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) RaCuevas",
        "interaction" : "interacts with",
        "SUID" : 1410,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1409",
        "source" : "661",
        "target" : "539",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) ReynoldsDoGood",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) ReynoldsDoGood",
        "interaction" : "interacts with",
        "SUID" : 1409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1408",
        "source" : "661",
        "target" : "538",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) TimMajka",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) TimMajka",
        "interaction" : "interacts with",
        "SUID" : 1408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1407",
        "source" : "661",
        "target" : "537",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) LawleyWindy",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) LawleyWindy",
        "interaction" : "interacts with",
        "SUID" : 1407,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1406",
        "source" : "661",
        "target" : "536",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) kathrynwith5",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) kathrynwith5",
        "interaction" : "interacts with",
        "SUID" : 1406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1405",
        "source" : "661",
        "target" : "535",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) trigonis30",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) trigonis30",
        "interaction" : "interacts with",
        "SUID" : 1405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1404",
        "source" : "661",
        "target" : "534",
        "EdgeBetweenness" : 1087.0,
        "shared_name" : "LongBeachMayor (interacts with) mstaylorboone",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachMayor (interacts with) mstaylorboone",
        "interaction" : "interacts with",
        "SUID" : 1404,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "660",
        "target" : "551",
        "EdgeBetweenness" : 1333.0,
        "shared_name" : "SupJaniceHahn (interacts with) qniteowl",
        "shared_interaction" : "interacts with",
        "name" : "SupJaniceHahn (interacts with) qniteowl",
        "interaction" : "interacts with",
        "SUID" : 1403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1402",
        "source" : "660",
        "target" : "550",
        "EdgeBetweenness" : 1333.0,
        "shared_name" : "SupJaniceHahn (interacts with) socalifrose",
        "shared_interaction" : "interacts with",
        "name" : "SupJaniceHahn (interacts with) socalifrose",
        "interaction" : "interacts with",
        "SUID" : 1402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1401",
        "source" : "660",
        "target" : "549",
        "EdgeBetweenness" : 1333.0,
        "shared_name" : "SupJaniceHahn (interacts with) hennylion",
        "shared_interaction" : "interacts with",
        "name" : "SupJaniceHahn (interacts with) hennylion",
        "interaction" : "interacts with",
        "SUID" : 1401,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1400",
        "source" : "660",
        "target" : "548",
        "EdgeBetweenness" : 1333.0,
        "shared_name" : "SupJaniceHahn (interacts with) LACountyBOS",
        "shared_interaction" : "interacts with",
        "name" : "SupJaniceHahn (interacts with) LACountyBOS",
        "interaction" : "interacts with",
        "SUID" : 1400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1399",
        "source" : "660",
        "target" : "547",
        "EdgeBetweenness" : 1333.0,
        "shared_name" : "SupJaniceHahn (interacts with) CoachDenele",
        "shared_interaction" : "interacts with",
        "name" : "SupJaniceHahn (interacts with) CoachDenele",
        "interaction" : "interacts with",
        "SUID" : 1399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1398",
        "source" : "659",
        "target" : "79",
        "EdgeBetweenness" : 991.0,
        "shared_name" : "RobertGarciaLB (interacts with) Justinscake",
        "shared_interaction" : "interacts with",
        "name" : "RobertGarciaLB (interacts with) Justinscake",
        "interaction" : "interacts with",
        "SUID" : 1398,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1397",
        "source" : "659",
        "target" : "78",
        "EdgeBetweenness" : 991.0,
        "shared_name" : "RobertGarciaLB (interacts with) lnfernandez2013",
        "shared_interaction" : "interacts with",
        "name" : "RobertGarciaLB (interacts with) lnfernandez2013",
        "interaction" : "interacts with",
        "SUID" : 1397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1396",
        "source" : "659",
        "target" : "77",
        "EdgeBetweenness" : 991.0,
        "shared_name" : "RobertGarciaLB (interacts with) _FritoLai",
        "shared_interaction" : "interacts with",
        "name" : "RobertGarciaLB (interacts with) _FritoLai",
        "interaction" : "interacts with",
        "SUID" : 1396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1395",
        "source" : "659",
        "target" : "76",
        "EdgeBetweenness" : 991.0,
        "shared_name" : "RobertGarciaLB (interacts with) teachersarah21",
        "shared_interaction" : "interacts with",
        "name" : "RobertGarciaLB (interacts with) teachersarah21",
        "interaction" : "interacts with",
        "SUID" : 1395,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1394",
        "source" : "659",
        "target" : "75",
        "EdgeBetweenness" : 991.0,
        "shared_name" : "RobertGarciaLB (interacts with) trott1073",
        "shared_interaction" : "interacts with",
        "name" : "RobertGarciaLB (interacts with) trott1073",
        "interaction" : "interacts with",
        "SUID" : 1394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1393",
        "source" : "659",
        "target" : "74",
        "EdgeBetweenness" : 991.0,
        "shared_name" : "RobertGarciaLB (interacts with) artofuprising",
        "shared_interaction" : "interacts with",
        "name" : "RobertGarciaLB (interacts with) artofuprising",
        "interaction" : "interacts with",
        "SUID" : 1393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1392",
        "source" : "658",
        "target" : "657",
        "EdgeBetweenness" : 1344.0,
        "shared_name" : "BlinstrubJ (interacts with) IUSD",
        "shared_interaction" : "interacts with",
        "name" : "BlinstrubJ (interacts with) IUSD",
        "interaction" : "interacts with",
        "SUID" : 1392,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1391",
        "source" : "657",
        "target" : "656",
        "EdgeBetweenness" : 2220.0,
        "shared_name" : "IUSD (interacts with) daybird77",
        "shared_interaction" : "interacts with",
        "name" : "IUSD (interacts with) daybird77",
        "interaction" : "interacts with",
        "SUID" : 1391,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1390",
        "source" : "657",
        "target" : "655",
        "EdgeBetweenness" : 111.0,
        "shared_name" : "IUSD (interacts with) IHSVaqueros",
        "shared_interaction" : "interacts with",
        "name" : "IUSD (interacts with) IHSVaqueros",
        "interaction" : "interacts with",
        "SUID" : 1390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1389",
        "source" : "657",
        "target" : "654",
        "EdgeBetweenness" : 111.0,
        "shared_name" : "IUSD (interacts with) DrBrentFreeze",
        "shared_interaction" : "interacts with",
        "name" : "IUSD (interacts with) DrBrentFreeze",
        "interaction" : "interacts with",
        "SUID" : 1389,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1388",
        "source" : "657",
        "target" : "653",
        "EdgeBetweenness" : 111.0,
        "shared_name" : "IUSD (interacts with) jwilliamsiusd",
        "shared_interaction" : "interacts with",
        "name" : "IUSD (interacts with) jwilliamsiusd",
        "interaction" : "interacts with",
        "SUID" : 1388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1387",
        "source" : "656",
        "target" : "855",
        "EdgeBetweenness" : 3135.0,
        "shared_name" : "daybird77 (interacts with) City_of_Irvine",
        "shared_interaction" : "interacts with",
        "name" : "daybird77 (interacts with) City_of_Irvine",
        "interaction" : "interacts with",
        "SUID" : 1387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1345",
        "source" : "610",
        "target" : "609",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "JanFrye (interacts with) SquireJames",
        "shared_interaction" : "interacts with",
        "name" : "JanFrye (interacts with) SquireJames",
        "interaction" : "interacts with",
        "SUID" : 1345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1344",
        "source" : "609",
        "target" : "608",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) EMIBORINGYOU",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) EMIBORINGYOU",
        "interaction" : "interacts with",
        "SUID" : 1344,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1343",
        "source" : "609",
        "target" : "607",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) godless2020",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) godless2020",
        "interaction" : "interacts with",
        "SUID" : 1343,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1342",
        "source" : "609",
        "target" : "606",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) weshouldallcare",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) weshouldallcare",
        "interaction" : "interacts with",
        "SUID" : 1342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1341",
        "source" : "609",
        "target" : "605",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) JerseyKidPicks",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) JerseyKidPicks",
        "interaction" : "interacts with",
        "SUID" : 1341,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1340",
        "source" : "609",
        "target" : "604",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) edgar_eduarte",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) edgar_eduarte",
        "interaction" : "interacts with",
        "SUID" : 1340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1339",
        "source" : "609",
        "target" : "603",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) suznu",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) suznu",
        "interaction" : "interacts with",
        "SUID" : 1339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1338",
        "source" : "609",
        "target" : "602",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) HOOPSnix",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) HOOPSnix",
        "interaction" : "interacts with",
        "SUID" : 1338,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1337",
        "source" : "609",
        "target" : "601",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) monstro_fan",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) monstro_fan",
        "interaction" : "interacts with",
        "SUID" : 1337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1336",
        "source" : "609",
        "target" : "600",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) FBattels",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) FBattels",
        "interaction" : "interacts with",
        "SUID" : 1336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1335",
        "source" : "609",
        "target" : "599",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) bazookajoet",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) bazookajoet",
        "interaction" : "interacts with",
        "SUID" : 1335,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1334",
        "source" : "609",
        "target" : "598",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Jmontel99",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Jmontel99",
        "interaction" : "interacts with",
        "SUID" : 1334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1333",
        "source" : "609",
        "target" : "597",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) DeplorableMi17",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) DeplorableMi17",
        "interaction" : "interacts with",
        "SUID" : 1333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1332",
        "source" : "609",
        "target" : "596",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Gregory__Adams",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Gregory__Adams",
        "interaction" : "interacts with",
        "SUID" : 1332,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1331",
        "source" : "609",
        "target" : "595",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) yung817lo",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) yung817lo",
        "interaction" : "interacts with",
        "SUID" : 1331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1330",
        "source" : "609",
        "target" : "594",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) SorinaDurante",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) SorinaDurante",
        "interaction" : "interacts with",
        "SUID" : 1330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "source" : "609",
        "target" : "593",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) trinketchase",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) trinketchase",
        "interaction" : "interacts with",
        "SUID" : 1329,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1328",
        "source" : "609",
        "target" : "592",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Angie74720660",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Angie74720660",
        "interaction" : "interacts with",
        "SUID" : 1328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1327",
        "source" : "609",
        "target" : "591",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) beaglebabe48",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) beaglebabe48",
        "interaction" : "interacts with",
        "SUID" : 1327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1326",
        "source" : "609",
        "target" : "590",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) betty_rindal",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) betty_rindal",
        "interaction" : "interacts with",
        "SUID" : 1326,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1325",
        "source" : "609",
        "target" : "589",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) UGHExpressions",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) UGHExpressions",
        "interaction" : "interacts with",
        "SUID" : 1325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1324",
        "source" : "609",
        "target" : "588",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) gonshorowski",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) gonshorowski",
        "interaction" : "interacts with",
        "SUID" : 1324,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1323",
        "source" : "609",
        "target" : "587",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) contentguru69",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) contentguru69",
        "interaction" : "interacts with",
        "SUID" : 1323,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1322",
        "source" : "609",
        "target" : "586",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Eagleriver4J",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Eagleriver4J",
        "interaction" : "interacts with",
        "SUID" : 1322,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1321",
        "source" : "609",
        "target" : "585",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Sheindie",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Sheindie",
        "interaction" : "interacts with",
        "SUID" : 1321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1320",
        "source" : "609",
        "target" : "584",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) pedsscrub",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) pedsscrub",
        "interaction" : "interacts with",
        "SUID" : 1320,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1319",
        "source" : "609",
        "target" : "583",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) TradingInCB1",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) TradingInCB1",
        "interaction" : "interacts with",
        "SUID" : 1319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1318",
        "source" : "609",
        "target" : "582",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Wewoka3",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Wewoka3",
        "interaction" : "interacts with",
        "SUID" : 1318,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1317",
        "source" : "609",
        "target" : "581",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) herewegokids7",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) herewegokids7",
        "interaction" : "interacts with",
        "SUID" : 1317,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1316",
        "source" : "609",
        "target" : "580",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Avaguesenseofun",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Avaguesenseofun",
        "interaction" : "interacts with",
        "SUID" : 1316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1315",
        "source" : "609",
        "target" : "579",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) AWKathy11",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) AWKathy11",
        "interaction" : "interacts with",
        "SUID" : 1315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1314",
        "source" : "609",
        "target" : "578",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) vearleavni",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) vearleavni",
        "interaction" : "interacts with",
        "SUID" : 1314,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1313",
        "source" : "609",
        "target" : "577",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) enlightnup",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) enlightnup",
        "interaction" : "interacts with",
        "SUID" : 1313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1312",
        "source" : "609",
        "target" : "576",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) radar210",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) radar210",
        "interaction" : "interacts with",
        "SUID" : 1312,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1311",
        "source" : "609",
        "target" : "575",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) sharbycreek",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) sharbycreek",
        "interaction" : "interacts with",
        "SUID" : 1311,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1310",
        "source" : "609",
        "target" : "574",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) MDYankeefan1",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) MDYankeefan1",
        "interaction" : "interacts with",
        "SUID" : 1310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1309",
        "source" : "609",
        "target" : "573",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) JoPhinney2",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) JoPhinney2",
        "interaction" : "interacts with",
        "SUID" : 1309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1308",
        "source" : "609",
        "target" : "572",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) NovemberMatters",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) NovemberMatters",
        "interaction" : "interacts with",
        "SUID" : 1308,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1307",
        "source" : "609",
        "target" : "571",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) AmandaE02423971",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) AmandaE02423971",
        "interaction" : "interacts with",
        "SUID" : 1307,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1306",
        "source" : "609",
        "target" : "570",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) Missy_Kidd",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) Missy_Kidd",
        "interaction" : "interacts with",
        "SUID" : 1306,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1305",
        "source" : "609",
        "target" : "569",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) BooyahBoyz",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) BooyahBoyz",
        "interaction" : "interacts with",
        "SUID" : 1305,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1304",
        "source" : "609",
        "target" : "568",
        "EdgeBetweenness" : 44.0,
        "shared_name" : "SquireJames (interacts with) unitedintreble",
        "shared_interaction" : "interacts with",
        "name" : "SquireJames (interacts with) unitedintreble",
        "interaction" : "interacts with",
        "SUID" : 1304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1303",
        "source" : "567",
        "target" : "566",
        "EdgeBetweenness" : 352.0,
        "shared_name" : "CSUDHNSO (interacts with) DominguezHills",
        "shared_interaction" : "interacts with",
        "name" : "CSUDHNSO (interacts with) DominguezHills",
        "interaction" : "interacts with",
        "SUID" : 1303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1302",
        "source" : "566",
        "target" : "565",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) ASICSUDH",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) ASICSUDH",
        "interaction" : "interacts with",
        "SUID" : 1302,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1301",
        "source" : "566",
        "target" : "564",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) csudhteddytoro",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) csudhteddytoro",
        "interaction" : "interacts with",
        "SUID" : 1301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1300",
        "source" : "566",
        "target" : "563",
        "EdgeBetweenness" : 135.0,
        "shared_name" : "DominguezHills (interacts with) majackmon",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) majackmon",
        "interaction" : "interacts with",
        "SUID" : 1300,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1299",
        "source" : "566",
        "target" : "562",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) chuybaca",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) chuybaca",
        "interaction" : "interacts with",
        "SUID" : 1299,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1298",
        "source" : "566",
        "target" : "561",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) Toni_Molle",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) Toni_Molle",
        "interaction" : "interacts with",
        "SUID" : 1298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1297",
        "source" : "566",
        "target" : "560",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) calstate",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) calstate",
        "interaction" : "interacts with",
        "SUID" : 1297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1296",
        "source" : "566",
        "target" : "559",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) CSUDHExRel",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) CSUDHExRel",
        "interaction" : "interacts with",
        "SUID" : 1296,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1295",
        "source" : "566",
        "target" : "558",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) theekbradshaw",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) theekbradshaw",
        "interaction" : "interacts with",
        "SUID" : 1295,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1294",
        "source" : "566",
        "target" : "557",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) yDominguezHills",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) yDominguezHills",
        "interaction" : "interacts with",
        "SUID" : 1294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1293",
        "source" : "566",
        "target" : "556",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) esmeralina3",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) esmeralina3",
        "interaction" : "interacts with",
        "SUID" : 1293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1292",
        "source" : "566",
        "target" : "555",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) CSUDHCalFresh",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) CSUDHCalFresh",
        "interaction" : "interacts with",
        "SUID" : 1292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1291",
        "source" : "566",
        "target" : "554",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) adaycsu",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) adaycsu",
        "interaction" : "interacts with",
        "SUID" : 1291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1290",
        "source" : "566",
        "target" : "553",
        "EdgeBetweenness" : 45.0,
        "shared_name" : "DominguezHills (interacts with) sea_science_sam",
        "shared_interaction" : "interacts with",
        "name" : "DominguezHills (interacts with) sea_science_sam",
        "interaction" : "interacts with",
        "SUID" : 1290,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1289",
        "source" : "563",
        "target" : "308",
        "EdgeBetweenness" : 154.0,
        "shared_name" : "majackmon (interacts with) PresConoley",
        "shared_interaction" : "interacts with",
        "name" : "majackmon (interacts with) PresConoley",
        "interaction" : "interacts with",
        "SUID" : 1289,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1288",
        "source" : "552",
        "target" : "660",
        "EdgeBetweenness" : 2040.0,
        "shared_name" : "LACountyDHR (interacts with) SupJaniceHahn",
        "shared_interaction" : "interacts with",
        "name" : "LACountyDHR (interacts with) SupJaniceHahn",
        "interaction" : "interacts with",
        "SUID" : 1288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1287",
        "source" : "543",
        "target" : "492",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) MrsLongBeachLB",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) MrsLongBeachLB",
        "interaction" : "interacts with",
        "SUID" : 1287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1286",
        "source" : "543",
        "target" : "491",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) cgomez61D",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) cgomez61D",
        "interaction" : "interacts with",
        "SUID" : 1286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1285",
        "source" : "543",
        "target" : "490",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) shopgirlatsando",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) shopgirlatsando",
        "interaction" : "interacts with",
        "SUID" : 1285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1284",
        "source" : "543",
        "target" : "489",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) senorhdz",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) senorhdz",
        "interaction" : "interacts with",
        "SUID" : 1284,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1283",
        "source" : "543",
        "target" : "488",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) SBStitching",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) SBStitching",
        "interaction" : "interacts with",
        "SUID" : 1283,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1282",
        "source" : "543",
        "target" : "487",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) myrnasword17",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) myrnasword17",
        "interaction" : "interacts with",
        "SUID" : 1282,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1281",
        "source" : "543",
        "target" : "486",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) LeonerPerez",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) LeonerPerez",
        "interaction" : "interacts with",
        "SUID" : 1281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1280",
        "source" : "543",
        "target" : "485",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) LBSchoolsTV",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) LBSchoolsTV",
        "interaction" : "interacts with",
        "SUID" : 1280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1279",
        "source" : "543",
        "target" : "484",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) megankerr",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) megankerr",
        "interaction" : "interacts with",
        "SUID" : 1279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1278",
        "source" : "543",
        "target" : "483",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) SteinbergJinky",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) SteinbergJinky",
        "interaction" : "interacts with",
        "SUID" : 1278,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "source" : "543",
        "target" : "482",
        "EdgeBetweenness" : 1413.0,
        "shared_name" : "LBSchools (interacts with) AcademyPowell",
        "shared_interaction" : "interacts with",
        "name" : "LBSchools (interacts with) AcademyPowell",
        "interaction" : "interacts with",
        "SUID" : 1277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1276",
        "source" : "542",
        "target" : "481",
        "EdgeBetweenness" : 14120.0,
        "shared_name" : "longbeachbobby (interacts with) LBCityCollege",
        "shared_interaction" : "interacts with",
        "name" : "longbeachbobby (interacts with) LBCityCollege",
        "interaction" : "interacts with",
        "SUID" : 1276,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1230",
        "source" : "493",
        "target" : "80",
        "EdgeBetweenness" : 1810.0,
        "shared_name" : "TheCCLB (interacts with) CalRecycle",
        "shared_interaction" : "interacts with",
        "name" : "TheCCLB (interacts with) CalRecycle",
        "interaction" : "interacts with",
        "SUID" : 1230,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "481",
        "target" : "189",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) TrusteeNtuk",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) TrusteeNtuk",
        "interaction" : "interacts with",
        "SUID" : 1229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1228",
        "source" : "481",
        "target" : "147",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) lbccvikings",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) lbccvikings",
        "interaction" : "interacts with",
        "SUID" : 1228,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1227",
        "source" : "481",
        "target" : "146",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) jdo8302",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) jdo8302",
        "interaction" : "interacts with",
        "SUID" : 1227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1226",
        "source" : "481",
        "target" : "145",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) counselor_oh",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) counselor_oh",
        "interaction" : "interacts with",
        "SUID" : 1226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1225",
        "source" : "481",
        "target" : "144",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) ProfessorVitt",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) ProfessorVitt",
        "interaction" : "interacts with",
        "SUID" : 1225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1224",
        "source" : "481",
        "target" : "143",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) fradoo88",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) fradoo88",
        "interaction" : "interacts with",
        "SUID" : 1224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "source" : "481",
        "target" : "142",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) andy_r45",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) andy_r45",
        "interaction" : "interacts with",
        "SUID" : 1223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1222",
        "source" : "481",
        "target" : "141",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) DaMatrix13",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) DaMatrix13",
        "interaction" : "interacts with",
        "SUID" : 1222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1221",
        "source" : "481",
        "target" : "140",
        "EdgeBetweenness" : 1962.0,
        "shared_name" : "LBCityCollege (interacts with) LBCCTraining",
        "shared_interaction" : "interacts with",
        "name" : "LBCityCollege (interacts with) LBCCTraining",
        "interaction" : "interacts with",
        "SUID" : 1221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1220",
        "source" : "480",
        "target" : "479",
        "EdgeBetweenness" : 44204.0,
        "shared_name" : "ancydana (interacts with) toozurnt",
        "shared_interaction" : "interacts with",
        "name" : "ancydana (interacts with) toozurnt",
        "interaction" : "interacts with",
        "SUID" : 1220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1219",
        "source" : "479",
        "target" : "478",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) perla_flores_pf",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) perla_flores_pf",
        "interaction" : "interacts with",
        "SUID" : 1219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1218",
        "source" : "479",
        "target" : "477",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ghostliegh",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ghostliegh",
        "interaction" : "interacts with",
        "SUID" : 1218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "source" : "479",
        "target" : "476",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ariana_papi",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ariana_papi",
        "interaction" : "interacts with",
        "SUID" : 1217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1216",
        "source" : "479",
        "target" : "475",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) HeyMrKarma",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) HeyMrKarma",
        "interaction" : "interacts with",
        "SUID" : 1216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1215",
        "source" : "479",
        "target" : "474",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) mayrapollo4",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) mayrapollo4",
        "interaction" : "interacts with",
        "SUID" : 1215,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1214",
        "source" : "479",
        "target" : "473",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) k0nnichiwaneko",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) k0nnichiwaneko",
        "interaction" : "interacts with",
        "SUID" : 1214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1213",
        "source" : "479",
        "target" : "472",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) youarelovely95",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) youarelovely95",
        "interaction" : "interacts with",
        "SUID" : 1213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1212",
        "source" : "479",
        "target" : "471",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ncityquin",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ncityquin",
        "interaction" : "interacts with",
        "SUID" : 1212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "source" : "479",
        "target" : "470",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) lilyyxm",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) lilyyxm",
        "interaction" : "interacts with",
        "SUID" : 1211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1210",
        "source" : "479",
        "target" : "469",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) sydneyrfrank",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) sydneyrfrank",
        "interaction" : "interacts with",
        "SUID" : 1210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1209",
        "source" : "479",
        "target" : "468",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) DrewTosch",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) DrewTosch",
        "interaction" : "interacts with",
        "SUID" : 1209,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1208",
        "source" : "479",
        "target" : "467",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Shes_RuRuu",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Shes_RuRuu",
        "interaction" : "interacts with",
        "SUID" : 1208,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1207",
        "source" : "479",
        "target" : "466",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) KaitlynMelgoza",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) KaitlynMelgoza",
        "interaction" : "interacts with",
        "SUID" : 1207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1206",
        "source" : "479",
        "target" : "465",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) knuckifyoubuckb",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) knuckifyoubuckb",
        "interaction" : "interacts with",
        "SUID" : 1206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "source" : "479",
        "target" : "464",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) sol_pythonissam",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) sol_pythonissam",
        "interaction" : "interacts with",
        "SUID" : 1205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1204",
        "source" : "479",
        "target" : "463",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) rejuvenatedcat",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) rejuvenatedcat",
        "interaction" : "interacts with",
        "SUID" : 1204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1203",
        "source" : "479",
        "target" : "462",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) DanteSignorelli",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) DanteSignorelli",
        "interaction" : "interacts with",
        "SUID" : 1203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1202",
        "source" : "479",
        "target" : "461",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) caite_coal",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) caite_coal",
        "interaction" : "interacts with",
        "SUID" : 1202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1201",
        "source" : "479",
        "target" : "460",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) blinkotwinko",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) blinkotwinko",
        "interaction" : "interacts with",
        "SUID" : 1201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1200",
        "source" : "479",
        "target" : "459",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) MissObtas",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) MissObtas",
        "interaction" : "interacts with",
        "SUID" : 1200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1199",
        "source" : "479",
        "target" : "458",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) claudiat1997",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) claudiat1997",
        "interaction" : "interacts with",
        "SUID" : 1199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1198",
        "source" : "479",
        "target" : "457",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) kieleevans",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) kieleevans",
        "interaction" : "interacts with",
        "SUID" : 1198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1197",
        "source" : "479",
        "target" : "456",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Rayperez88",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Rayperez88",
        "interaction" : "interacts with",
        "SUID" : 1197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1196",
        "source" : "479",
        "target" : "455",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Iridescent_Rose",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Iridescent_Rose",
        "interaction" : "interacts with",
        "SUID" : 1196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "source" : "479",
        "target" : "454",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) AB_Owl",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) AB_Owl",
        "interaction" : "interacts with",
        "SUID" : 1195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1194",
        "source" : "479",
        "target" : "453",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) SophieStarshine",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) SophieStarshine",
        "interaction" : "interacts with",
        "SUID" : 1194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "source" : "479",
        "target" : "452",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) reneeweeenie",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) reneeweeenie",
        "interaction" : "interacts with",
        "SUID" : 1193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1192",
        "source" : "479",
        "target" : "451",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) curlytoplex",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) curlytoplex",
        "interaction" : "interacts with",
        "SUID" : 1192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1191",
        "source" : "479",
        "target" : "450",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ayemevo",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ayemevo",
        "interaction" : "interacts with",
        "SUID" : 1191,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1190",
        "source" : "479",
        "target" : "449",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ayelookitsBRADY",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ayelookitsBRADY",
        "interaction" : "interacts with",
        "SUID" : 1190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1189",
        "source" : "479",
        "target" : "448",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) maniawentz",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) maniawentz",
        "interaction" : "interacts with",
        "SUID" : 1189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1188",
        "source" : "479",
        "target" : "447",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) jheiny_doeyy",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) jheiny_doeyy",
        "interaction" : "interacts with",
        "SUID" : 1188,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "source" : "479",
        "target" : "446",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) iqranoor1D",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) iqranoor1D",
        "interaction" : "interacts with",
        "SUID" : 1187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1186",
        "source" : "479",
        "target" : "445",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) KNOWASONG",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) KNOWASONG",
        "interaction" : "interacts with",
        "SUID" : 1186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "source" : "479",
        "target" : "444",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) laylay123123",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) laylay123123",
        "interaction" : "interacts with",
        "SUID" : 1185,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1184",
        "source" : "479",
        "target" : "443",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) rowzee_b",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) rowzee_b",
        "interaction" : "interacts with",
        "SUID" : 1184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "source" : "479",
        "target" : "442",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) livdelro10",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) livdelro10",
        "interaction" : "interacts with",
        "SUID" : 1183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1182",
        "source" : "479",
        "target" : "441",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) NostalgicVinyls",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) NostalgicVinyls",
        "interaction" : "interacts with",
        "SUID" : 1182,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "source" : "479",
        "target" : "440",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) atrocioous",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) atrocioous",
        "interaction" : "interacts with",
        "SUID" : 1181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1180",
        "source" : "479",
        "target" : "439",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Aestheticbangt4",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Aestheticbangt4",
        "interaction" : "interacts with",
        "SUID" : 1180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "source" : "479",
        "target" : "438",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ElfGrove",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ElfGrove",
        "interaction" : "interacts with",
        "SUID" : 1179,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1178",
        "source" : "479",
        "target" : "667",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) PhoenixArielle",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) PhoenixArielle",
        "interaction" : "interacts with",
        "SUID" : 1178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "source" : "479",
        "target" : "437",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) brown_enchilada",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) brown_enchilada",
        "interaction" : "interacts with",
        "SUID" : 1177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1176",
        "source" : "479",
        "target" : "436",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) bmorrisseyxo",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) bmorrisseyxo",
        "interaction" : "interacts with",
        "SUID" : 1176,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "source" : "479",
        "target" : "435",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) jennperez828",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) jennperez828",
        "interaction" : "interacts with",
        "SUID" : 1175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1174",
        "source" : "479",
        "target" : "434",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) wild_flowerbaby",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) wild_flowerbaby",
        "interaction" : "interacts with",
        "SUID" : 1174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1173",
        "source" : "479",
        "target" : "433",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Mighterbump",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Mighterbump",
        "interaction" : "interacts with",
        "SUID" : 1173,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1172",
        "source" : "479",
        "target" : "432",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) dudeitsrosie_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) dudeitsrosie_",
        "interaction" : "interacts with",
        "SUID" : 1172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "source" : "479",
        "target" : "431",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) kylaakakess",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) kylaakakess",
        "interaction" : "interacts with",
        "SUID" : 1171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1170",
        "source" : "479",
        "target" : "430",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) DALIZZZL",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) DALIZZZL",
        "interaction" : "interacts with",
        "SUID" : 1170,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "source" : "479",
        "target" : "429",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) melonpuerto",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) melonpuerto",
        "interaction" : "interacts with",
        "SUID" : 1169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1168",
        "source" : "479",
        "target" : "428",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) dani_miyerah98",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) dani_miyerah98",
        "interaction" : "interacts with",
        "SUID" : 1168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "source" : "479",
        "target" : "427",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) janinearratia",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) janinearratia",
        "interaction" : "interacts with",
        "SUID" : 1167,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1166",
        "source" : "479",
        "target" : "426",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) THEEBrittney",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) THEEBrittney",
        "interaction" : "interacts with",
        "SUID" : 1166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1165",
        "source" : "479",
        "target" : "425",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) xoxo_ayleenn",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) xoxo_ayleenn",
        "interaction" : "interacts with",
        "SUID" : 1165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "source" : "479",
        "target" : "424",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Chon_95",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Chon_95",
        "interaction" : "interacts with",
        "SUID" : 1164,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "source" : "479",
        "target" : "423",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) kate_zendejas",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) kate_zendejas",
        "interaction" : "interacts with",
        "SUID" : 1163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1162",
        "source" : "479",
        "target" : "422",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) azhanique__",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) azhanique__",
        "interaction" : "interacts with",
        "SUID" : 1162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "source" : "479",
        "target" : "421",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) josepalma127",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) josepalma127",
        "interaction" : "interacts with",
        "SUID" : 1161,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1160",
        "source" : "479",
        "target" : "420",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) coolcatcaro",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) coolcatcaro",
        "interaction" : "interacts with",
        "SUID" : 1160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "source" : "479",
        "target" : "419",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) dumbomato",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) dumbomato",
        "interaction" : "interacts with",
        "SUID" : 1159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1158",
        "source" : "479",
        "target" : "418",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Ninjanyiah16",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Ninjanyiah16",
        "interaction" : "interacts with",
        "SUID" : 1158,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "source" : "479",
        "target" : "417",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Xo_Jenzziee_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Xo_Jenzziee_",
        "interaction" : "interacts with",
        "SUID" : 1157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1156",
        "source" : "479",
        "target" : "416",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) catbroooks",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) catbroooks",
        "interaction" : "interacts with",
        "SUID" : 1156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "source" : "479",
        "target" : "415",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) maexrene",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) maexrene",
        "interaction" : "interacts with",
        "SUID" : 1155,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1154",
        "source" : "479",
        "target" : "414",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) mistyhennelly",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) mistyhennelly",
        "interaction" : "interacts with",
        "SUID" : 1154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "source" : "479",
        "target" : "413",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) meilaniyatco",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) meilaniyatco",
        "interaction" : "interacts with",
        "SUID" : 1153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1152",
        "source" : "479",
        "target" : "412",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) briannugh14",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) briannugh14",
        "interaction" : "interacts with",
        "SUID" : 1152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "479",
        "target" : "411",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ohmymonteen",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ohmymonteen",
        "interaction" : "interacts with",
        "SUID" : 1151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1150",
        "source" : "479",
        "target" : "410",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) _LXVIII",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) _LXVIII",
        "interaction" : "interacts with",
        "SUID" : 1150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "source" : "479",
        "target" : "409",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) msangiesegura",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) msangiesegura",
        "interaction" : "interacts with",
        "SUID" : 1149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1148",
        "source" : "479",
        "target" : "408",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) S__Clough",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) S__Clough",
        "interaction" : "interacts with",
        "SUID" : 1148,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "source" : "479",
        "target" : "407",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) jackie_r08",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) jackie_r08",
        "interaction" : "interacts with",
        "SUID" : 1147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1146",
        "source" : "479",
        "target" : "406",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ngleon95",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ngleon95",
        "interaction" : "interacts with",
        "SUID" : 1146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "479",
        "target" : "405",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) swanfaery",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) swanfaery",
        "interaction" : "interacts with",
        "SUID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1144",
        "source" : "479",
        "target" : "404",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) teabyrosie",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) teabyrosie",
        "interaction" : "interacts with",
        "SUID" : 1144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "source" : "479",
        "target" : "403",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ewwitsirina",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ewwitsirina",
        "interaction" : "interacts with",
        "SUID" : 1143,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1142",
        "source" : "479",
        "target" : "402",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) inmanlauren",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) inmanlauren",
        "interaction" : "interacts with",
        "SUID" : 1142,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "source" : "479",
        "target" : "401",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) victorheras352",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) victorheras352",
        "interaction" : "interacts with",
        "SUID" : 1141,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1140",
        "source" : "479",
        "target" : "400",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) _abigail_irene_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) _abigail_irene_",
        "interaction" : "interacts with",
        "SUID" : 1140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "479",
        "target" : "399",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) VILNILLA",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) VILNILLA",
        "interaction" : "interacts with",
        "SUID" : 1139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1138",
        "source" : "479",
        "target" : "398",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) EARBlSCUlTS",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) EARBlSCUlTS",
        "interaction" : "interacts with",
        "SUID" : 1138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "source" : "479",
        "target" : "397",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ohhhh_nicole",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ohhhh_nicole",
        "interaction" : "interacts with",
        "SUID" : 1137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1136",
        "source" : "479",
        "target" : "396",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) sh0vonn",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) sh0vonn",
        "interaction" : "interacts with",
        "SUID" : 1136,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "source" : "479",
        "target" : "395",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) braxtynn_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) braxtynn_",
        "interaction" : "interacts with",
        "SUID" : 1135,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1134",
        "source" : "479",
        "target" : "394",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) nyacosmet",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) nyacosmet",
        "interaction" : "interacts with",
        "SUID" : 1134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "source" : "479",
        "target" : "393",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) SeanMatsukawa",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) SeanMatsukawa",
        "interaction" : "interacts with",
        "SUID" : 1133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1132",
        "source" : "479",
        "target" : "392",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) sarahmccanny",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) sarahmccanny",
        "interaction" : "interacts with",
        "SUID" : 1132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "479",
        "target" : "391",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Jaaaadeeee18",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Jaaaadeeee18",
        "interaction" : "interacts with",
        "SUID" : 1131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1130",
        "source" : "479",
        "target" : "390",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) OGstussyington",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) OGstussyington",
        "interaction" : "interacts with",
        "SUID" : 1130,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "source" : "479",
        "target" : "389",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) McDaPiCk",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) McDaPiCk",
        "interaction" : "interacts with",
        "SUID" : 1129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1128",
        "source" : "479",
        "target" : "388",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) shamsa_samiya",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) shamsa_samiya",
        "interaction" : "interacts with",
        "SUID" : 1128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "479",
        "target" : "387",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) sarynaaa_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) sarynaaa_",
        "interaction" : "interacts with",
        "SUID" : 1127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1126",
        "source" : "479",
        "target" : "386",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) browneyedhoneyy",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) browneyedhoneyy",
        "interaction" : "interacts with",
        "SUID" : 1126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "source" : "479",
        "target" : "385",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) rinnieie",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) rinnieie",
        "interaction" : "interacts with",
        "SUID" : 1125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1124",
        "source" : "479",
        "target" : "384",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) AcaciaEgo",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) AcaciaEgo",
        "interaction" : "interacts with",
        "SUID" : 1124,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "source" : "479",
        "target" : "383",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) cafedekoya",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) cafedekoya",
        "interaction" : "interacts with",
        "SUID" : 1123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1122",
        "source" : "479",
        "target" : "382",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) yeampp",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) yeampp",
        "interaction" : "interacts with",
        "SUID" : 1122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "479",
        "target" : "381",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) umnayadevushka",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) umnayadevushka",
        "interaction" : "interacts with",
        "SUID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1120",
        "source" : "479",
        "target" : "380",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) FixxieeYeshh",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) FixxieeYeshh",
        "interaction" : "interacts with",
        "SUID" : 1120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "source" : "479",
        "target" : "379",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Goon_Donovan23",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Goon_Donovan23",
        "interaction" : "interacts with",
        "SUID" : 1119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1118",
        "source" : "479",
        "target" : "378",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) viaxshine_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) viaxshine_",
        "interaction" : "interacts with",
        "SUID" : 1118,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "source" : "479",
        "target" : "377",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) jjlejetpain",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) jjlejetpain",
        "interaction" : "interacts with",
        "SUID" : 1117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1116",
        "source" : "479",
        "target" : "376",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) astroreefer",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) astroreefer",
        "interaction" : "interacts with",
        "SUID" : 1116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "479",
        "target" : "375",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Luv_yuhz",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Luv_yuhz",
        "interaction" : "interacts with",
        "SUID" : 1115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1114",
        "source" : "479",
        "target" : "374",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) taylorjeanexox",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) taylorjeanexox",
        "interaction" : "interacts with",
        "SUID" : 1114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "source" : "479",
        "target" : "373",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) TwoHispanic",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) TwoHispanic",
        "interaction" : "interacts with",
        "SUID" : 1113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "479",
        "target" : "372",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) tbabii142",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) tbabii142",
        "interaction" : "interacts with",
        "SUID" : 1112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "479",
        "target" : "371",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) karlitazway_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) karlitazway_",
        "interaction" : "interacts with",
        "SUID" : 1111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1110",
        "source" : "479",
        "target" : "370",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) justlynes",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) justlynes",
        "interaction" : "interacts with",
        "SUID" : 1110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "479",
        "target" : "369",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) r_stefany25",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) r_stefany25",
        "interaction" : "interacts with",
        "SUID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1108",
        "source" : "479",
        "target" : "368",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) curlyyonce",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) curlyyonce",
        "interaction" : "interacts with",
        "SUID" : 1108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "479",
        "target" : "367",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) samnoefab",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) samnoefab",
        "interaction" : "interacts with",
        "SUID" : 1107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "479",
        "target" : "366",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) _elizettg",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) _elizettg",
        "interaction" : "interacts with",
        "SUID" : 1106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "source" : "479",
        "target" : "365",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) toriansharri",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) toriansharri",
        "interaction" : "interacts with",
        "SUID" : 1105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1104",
        "source" : "479",
        "target" : "364",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) CadiaAlexander",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) CadiaAlexander",
        "interaction" : "interacts with",
        "SUID" : 1104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "479",
        "target" : "363",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) XOXO_Yeni",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) XOXO_Yeni",
        "interaction" : "interacts with",
        "SUID" : 1103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1102",
        "source" : "479",
        "target" : "362",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) xsimplyruby",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) xsimplyruby",
        "interaction" : "interacts with",
        "SUID" : 1102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "479",
        "target" : "361",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Dy_Lejoi",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Dy_Lejoi",
        "interaction" : "interacts with",
        "SUID" : 1101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "source" : "479",
        "target" : "360",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) meraizzlee",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) meraizzlee",
        "interaction" : "interacts with",
        "SUID" : 1100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "479",
        "target" : "359",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) danaaeelaishaa",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) danaaeelaishaa",
        "interaction" : "interacts with",
        "SUID" : 1099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "source" : "479",
        "target" : "358",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) juliololololol",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) juliololololol",
        "interaction" : "interacts with",
        "SUID" : 1098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "source" : "479",
        "target" : "357",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) KevenG310",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) KevenG310",
        "interaction" : "interacts with",
        "SUID" : 1097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1096",
        "source" : "479",
        "target" : "356",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ator2403",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ator2403",
        "interaction" : "interacts with",
        "SUID" : 1096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "479",
        "target" : "355",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) jaackkayy",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) jaackkayy",
        "interaction" : "interacts with",
        "SUID" : 1095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "source" : "479",
        "target" : "354",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) giselxromero",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) giselxromero",
        "interaction" : "interacts with",
        "SUID" : 1094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "source" : "479",
        "target" : "353",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) simplet0nnn",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) simplet0nnn",
        "interaction" : "interacts with",
        "SUID" : 1093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1092",
        "source" : "479",
        "target" : "352",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ashlexlameass",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ashlexlameass",
        "interaction" : "interacts with",
        "SUID" : 1092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "479",
        "target" : "351",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) axgelaa",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) axgelaa",
        "interaction" : "interacts with",
        "SUID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1090",
        "source" : "479",
        "target" : "350",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) jazmyne_17",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) jazmyne_17",
        "interaction" : "interacts with",
        "SUID" : 1090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "source" : "479",
        "target" : "349",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) eroj7",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) eroj7",
        "interaction" : "interacts with",
        "SUID" : 1089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "source" : "479",
        "target" : "348",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) mo_xuanyun",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) mo_xuanyun",
        "interaction" : "interacts with",
        "SUID" : 1088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "479",
        "target" : "347",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ashhh_leeey_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ashhh_leeey_",
        "interaction" : "interacts with",
        "SUID" : 1087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "479",
        "target" : "346",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) myia_papayaaa",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) myia_papayaaa",
        "interaction" : "interacts with",
        "SUID" : 1086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "479",
        "target" : "345",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Laniii_valencia",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Laniii_valencia",
        "interaction" : "interacts with",
        "SUID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1084",
        "source" : "479",
        "target" : "344",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) celestiall18",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) celestiall18",
        "interaction" : "interacts with",
        "SUID" : 1084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "479",
        "target" : "343",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) bexxalo",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) bexxalo",
        "interaction" : "interacts with",
        "SUID" : 1083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1082",
        "source" : "479",
        "target" : "342",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) capracity",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) capracity",
        "interaction" : "interacts with",
        "SUID" : 1082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "source" : "479",
        "target" : "341",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) angelicaalexis_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) angelicaalexis_",
        "interaction" : "interacts with",
        "SUID" : 1081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "479",
        "target" : "340",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) deanjoys",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) deanjoys",
        "interaction" : "interacts with",
        "SUID" : 1080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "479",
        "target" : "339",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) __Cinnabunns",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) __Cinnabunns",
        "interaction" : "interacts with",
        "SUID" : 1079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1078",
        "source" : "479",
        "target" : "338",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) garcia_dessire",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) garcia_dessire",
        "interaction" : "interacts with",
        "SUID" : 1078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "source" : "479",
        "target" : "337",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) h2henderson",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) h2henderson",
        "interaction" : "interacts with",
        "SUID" : 1077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "479",
        "target" : "336",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) DestinyFletch13",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) DestinyFletch13",
        "interaction" : "interacts with",
        "SUID" : 1076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "479",
        "target" : "335",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) savannah_frenes",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) savannah_frenes",
        "interaction" : "interacts with",
        "SUID" : 1075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "source" : "479",
        "target" : "334",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) WichotheArtist",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) WichotheArtist",
        "interaction" : "interacts with",
        "SUID" : 1074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "479",
        "target" : "333",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ryuusea_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ryuusea_",
        "interaction" : "interacts with",
        "SUID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1072",
        "source" : "479",
        "target" : "332",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) FknCrls",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) FknCrls",
        "interaction" : "interacts with",
        "SUID" : 1072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "479",
        "target" : "331",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) imanikirksy",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) imanikirksy",
        "interaction" : "interacts with",
        "SUID" : 1071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1070",
        "source" : "479",
        "target" : "330",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) elysemariev",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) elysemariev",
        "interaction" : "interacts with",
        "SUID" : 1070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "source" : "479",
        "target" : "329",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) perfectpree",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) perfectpree",
        "interaction" : "interacts with",
        "SUID" : 1069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1068",
        "source" : "479",
        "target" : "328",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) keywilliamss",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) keywilliamss",
        "interaction" : "interacts with",
        "SUID" : 1068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "479",
        "target" : "327",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) brendiittaaaa",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) brendiittaaaa",
        "interaction" : "interacts with",
        "SUID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1066",
        "source" : "479",
        "target" : "326",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) ssimosa_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) ssimosa_",
        "interaction" : "interacts with",
        "SUID" : 1066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "479",
        "target" : "325",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) hannah_peskoff5",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) hannah_peskoff5",
        "interaction" : "interacts with",
        "SUID" : 1065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "source" : "479",
        "target" : "324",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) jorge_huertao",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) jorge_huertao",
        "interaction" : "interacts with",
        "SUID" : 1064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "479",
        "target" : "323",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) rebe_duraan",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) rebe_duraan",
        "interaction" : "interacts with",
        "SUID" : 1063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1062",
        "source" : "479",
        "target" : "322",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) gaymomm",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) gaymomm",
        "interaction" : "interacts with",
        "SUID" : 1062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "479",
        "target" : "321",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) awwdawg",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) awwdawg",
        "interaction" : "interacts with",
        "SUID" : 1061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1060",
        "source" : "479",
        "target" : "320",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) Ya_sammm",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) Ya_sammm",
        "interaction" : "interacts with",
        "SUID" : 1060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "479",
        "target" : "319",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) EL_DUCkYZ",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) EL_DUCkYZ",
        "interaction" : "interacts with",
        "SUID" : 1059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1058",
        "source" : "479",
        "target" : "318",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) sunflowersugarx",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) sunflowersugarx",
        "interaction" : "interacts with",
        "SUID" : 1058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "479",
        "target" : "317",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) __oatmilk",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) __oatmilk",
        "interaction" : "interacts with",
        "SUID" : 1057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1056",
        "source" : "479",
        "target" : "316",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) babymaebee",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) babymaebee",
        "interaction" : "interacts with",
        "SUID" : 1056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "479",
        "target" : "315",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) _osnapitzjess",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) _osnapitzjess",
        "interaction" : "interacts with",
        "SUID" : 1055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1054",
        "source" : "479",
        "target" : "314",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) desslyy_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) desslyy_",
        "interaction" : "interacts with",
        "SUID" : 1054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "source" : "479",
        "target" : "313",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) bbydiosaa",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) bbydiosaa",
        "interaction" : "interacts with",
        "SUID" : 1053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "479",
        "target" : "312",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) TheLifeOfMich_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) TheLifeOfMich_",
        "interaction" : "interacts with",
        "SUID" : 1052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "source" : "479",
        "target" : "311",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) cheesymacaroni_",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) cheesymacaroni_",
        "interaction" : "interacts with",
        "SUID" : 1051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1050",
        "source" : "479",
        "target" : "310",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) camacho_248",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) camacho_248",
        "interaction" : "interacts with",
        "SUID" : 1050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "479",
        "target" : "309",
        "EdgeBetweenness" : 511.0,
        "shared_name" : "toozurnt (interacts with) amayrannni",
        "shared_interaction" : "interacts with",
        "name" : "toozurnt (interacts with) amayrannni",
        "interaction" : "interacts with",
        "SUID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1048",
        "source" : "308",
        "target" : "561",
        "EdgeBetweenness" : 56.0,
        "shared_name" : "PresConoley (interacts with) Toni_Molle",
        "shared_interaction" : "interacts with",
        "name" : "PresConoley (interacts with) Toni_Molle",
        "interaction" : "interacts with",
        "SUID" : 1048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "308",
        "target" : "560",
        "EdgeBetweenness" : 56.0,
        "shared_name" : "PresConoley (interacts with) calstate",
        "shared_interaction" : "interacts with",
        "name" : "PresConoley (interacts with) calstate",
        "interaction" : "interacts with",
        "SUID" : 1047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1046",
        "source" : "308",
        "target" : "307",
        "EdgeBetweenness" : 101.0,
        "shared_name" : "PresConoley (interacts with) CSULB",
        "shared_interaction" : "interacts with",
        "name" : "PresConoley (interacts with) CSULB",
        "interaction" : "interacts with",
        "SUID" : 1046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "source" : "306",
        "target" : "190",
        "EdgeBetweenness" : 450.0,
        "shared_name" : "MaryZendejasLB (interacts with) andrewkerr",
        "shared_interaction" : "interacts with",
        "name" : "MaryZendejasLB (interacts with) andrewkerr",
        "interaction" : "interacts with",
        "SUID" : 1045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1044",
        "source" : "306",
        "target" : "189",
        "EdgeBetweenness" : 450.0,
        "shared_name" : "MaryZendejasLB (interacts with) TrusteeNtuk",
        "shared_interaction" : "interacts with",
        "name" : "MaryZendejasLB (interacts with) TrusteeNtuk",
        "interaction" : "interacts with",
        "SUID" : 1044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "305",
        "target" : "161",
        "EdgeBetweenness" : 764.0,
        "shared_name" : "LongBeachFresh (interacts with) FoodFindersLBC",
        "shared_interaction" : "interacts with",
        "name" : "LongBeachFresh (interacts with) FoodFindersLBC",
        "interaction" : "interacts with",
        "SUID" : 1043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "source" : "304",
        "target" : "689",
        "EdgeBetweenness" : 1188.0,
        "shared_name" : "ToniRagusa (interacts with) katieporteroc",
        "shared_interaction" : "interacts with",
        "name" : "ToniRagusa (interacts with) katieporteroc",
        "interaction" : "interacts with",
        "SUID" : 1042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "source" : "238",
        "target" : "237",
        "EdgeBetweenness" : 663.0,
        "shared_name" : "UCIIllumination (interacts with) UCIHumanities",
        "shared_interaction" : "interacts with",
        "name" : "UCIIllumination (interacts with) UCIHumanities",
        "interaction" : "interacts with",
        "SUID" : 1041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1040",
        "source" : "237",
        "target" : "236",
        "EdgeBetweenness" : 300.0,
        "shared_name" : "UCIHumanities (interacts with) UCIEnglish",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) UCIEnglish",
        "interaction" : "interacts with",
        "SUID" : 1040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "237",
        "target" : "235",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) ljmu_ceres",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) ljmu_ceres",
        "interaction" : "interacts with",
        "SUID" : 1039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1038",
        "source" : "237",
        "target" : "234",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) 4Olrc",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) 4Olrc",
        "interaction" : "interacts with",
        "SUID" : 1038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "237",
        "target" : "233",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) UCIPat",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) UCIPat",
        "interaction" : "interacts with",
        "SUID" : 1037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1036",
        "source" : "237",
        "target" : "232",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) jwassers",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) jwassers",
        "interaction" : "interacts with",
        "SUID" : 1036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "source" : "237",
        "target" : "231",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) markwarschauer",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) markwarschauer",
        "interaction" : "interacts with",
        "SUID" : 1035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "237",
        "target" : "230",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) gillianrhayes",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) gillianrhayes",
        "interaction" : "interacts with",
        "SUID" : 1034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "source" : "237",
        "target" : "229",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) ErikaHayasaki",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) ErikaHayasaki",
        "interaction" : "interacts with",
        "SUID" : 1033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "source" : "237",
        "target" : "228",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) amandajswain",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) amandajswain",
        "interaction" : "interacts with",
        "SUID" : 1032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "237",
        "target" : "227",
        "EdgeBetweenness" : 100.0,
        "shared_name" : "UCIHumanities (interacts with) MillerTyrus",
        "shared_interaction" : "interacts with",
        "name" : "UCIHumanities (interacts with) MillerTyrus",
        "interaction" : "interacts with",
        "SUID" : 1031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "source" : "236",
        "target" : "110",
        "EdgeBetweenness" : 171.0,
        "shared_name" : "UCIEnglish (interacts with) DrJeffreyWilson",
        "shared_interaction" : "interacts with",
        "name" : "UCIEnglish (interacts with) DrJeffreyWilson",
        "interaction" : "interacts with",
        "SUID" : 1030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "236",
        "target" : "229",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "UCIEnglish (interacts with) ErikaHayasaki",
        "shared_interaction" : "interacts with",
        "name" : "UCIEnglish (interacts with) ErikaHayasaki",
        "interaction" : "interacts with",
        "SUID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "source" : "236",
        "target" : "227",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "UCIEnglish (interacts with) MillerTyrus",
        "shared_interaction" : "interacts with",
        "name" : "UCIEnglish (interacts with) MillerTyrus",
        "interaction" : "interacts with",
        "SUID" : 1028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "source" : "236",
        "target" : "109",
        "EdgeBetweenness" : 171.0,
        "shared_name" : "UCIEnglish (interacts with) taylorweik",
        "shared_interaction" : "interacts with",
        "name" : "UCIEnglish (interacts with) taylorweik",
        "interaction" : "interacts with",
        "SUID" : 1027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "217",
        "target" : "855",
        "EdgeBetweenness" : 399.0,
        "shared_name" : "OCREAL_ESTATE (interacts with) City_of_Irvine",
        "shared_interaction" : "interacts with",
        "name" : "OCREAL_ESTATE (interacts with) City_of_Irvine",
        "interaction" : "interacts with",
        "SUID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "source" : "215",
        "target" : "214",
        "EdgeBetweenness" : 36.0,
        "shared_name" : "MelissaNorthway (interacts with) FamiliesForward",
        "shared_interaction" : "interacts with",
        "name" : "MelissaNorthway (interacts with) FamiliesForward",
        "interaction" : "interacts with",
        "SUID" : 1024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "source" : "214",
        "target" : "149",
        "EdgeBetweenness" : 333.0,
        "shared_name" : "FamiliesForward (interacts with) anthonykuo",
        "shared_interaction" : "interacts with",
        "name" : "FamiliesForward (interacts with) anthonykuo",
        "interaction" : "interacts with",
        "SUID" : 1023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "source" : "207",
        "target" : "82",
        "EdgeBetweenness" : 582.0,
        "shared_name" : "UCIPubAffairs (interacts with) jocelinocuw",
        "shared_interaction" : "interacts with",
        "name" : "UCIPubAffairs (interacts with) jocelinocuw",
        "interaction" : "interacts with",
        "SUID" : 1022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "source" : "207",
        "target" : "230",
        "EdgeBetweenness" : 582.0,
        "shared_name" : "UCIPubAffairs (interacts with) gillianrhayes",
        "shared_interaction" : "interacts with",
        "name" : "UCIPubAffairs (interacts with) gillianrhayes",
        "interaction" : "interacts with",
        "SUID" : 1021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1020",
        "source" : "207",
        "target" : "81",
        "EdgeBetweenness" : 582.0,
        "shared_name" : "UCIPubAffairs (interacts with) theamandahughes",
        "shared_interaction" : "interacts with",
        "name" : "UCIPubAffairs (interacts with) theamandahughes",
        "interaction" : "interacts with",
        "SUID" : 1020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "202",
        "target" : "788",
        "EdgeBetweenness" : 72.0,
        "shared_name" : "EliMeye (interacts with) TrevorGriffey",
        "shared_interaction" : "interacts with",
        "name" : "EliMeye (interacts with) TrevorGriffey",
        "interaction" : "interacts with",
        "SUID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "168",
        "target" : "167",
        "EdgeBetweenness" : 297.0,
        "shared_name" : "wesley_verla (interacts with) RalphVClayman",
        "shared_interaction" : "interacts with",
        "name" : "wesley_verla (interacts with) RalphVClayman",
        "interaction" : "interacts with",
        "SUID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "998",
        "source" : "167",
        "target" : "166",
        "EdgeBetweenness" : 402.0,
        "shared_name" : "RalphVClayman (interacts with) rahuljanaksinha",
        "shared_interaction" : "interacts with",
        "name" : "RalphVClayman (interacts with) rahuljanaksinha",
        "interaction" : "interacts with",
        "SUID" : 998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "source" : "167",
        "target" : "165",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "RalphVClayman (interacts with) UroAlsyouf",
        "shared_interaction" : "interacts with",
        "name" : "RalphVClayman (interacts with) UroAlsyouf",
        "interaction" : "interacts with",
        "SUID" : 997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "996",
        "source" : "167",
        "target" : "164",
        "EdgeBetweenness" : 67.0,
        "shared_name" : "RalphVClayman (interacts with) lesdeane",
        "shared_interaction" : "interacts with",
        "name" : "RalphVClayman (interacts with) lesdeane",
        "interaction" : "interacts with",
        "SUID" : 996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "166",
        "target" : "163",
        "EdgeBetweenness" : 490.0,
        "shared_name" : "rahuljanaksinha (interacts with) jaimelandmanuci",
        "shared_interaction" : "interacts with",
        "name" : "rahuljanaksinha (interacts with) jaimelandmanuci",
        "interaction" : "interacts with",
        "SUID" : 995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "994",
        "source" : "163",
        "target" : "138",
        "EdgeBetweenness" : 235.0,
        "shared_name" : "jaimelandmanuci (interacts with) ack12",
        "shared_interaction" : "interacts with",
        "name" : "jaimelandmanuci (interacts with) ack12",
        "interaction" : "interacts with",
        "SUID" : 994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "source" : "163",
        "target" : "856",
        "EdgeBetweenness" : 235.0,
        "shared_name" : "jaimelandmanuci (interacts with) davidmartinson",
        "shared_interaction" : "interacts with",
        "name" : "jaimelandmanuci (interacts with) davidmartinson",
        "interaction" : "interacts with",
        "SUID" : 993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "992",
        "source" : "163",
        "target" : "137",
        "EdgeBetweenness" : 235.0,
        "shared_name" : "jaimelandmanuci (interacts with) lift_uciurology",
        "shared_interaction" : "interacts with",
        "name" : "jaimelandmanuci (interacts with) lift_uciurology",
        "interaction" : "interacts with",
        "SUID" : 992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "163",
        "target" : "136",
        "EdgeBetweenness" : 235.0,
        "shared_name" : "jaimelandmanuci (interacts with) montypal",
        "shared_interaction" : "interacts with",
        "name" : "jaimelandmanuci (interacts with) montypal",
        "interaction" : "interacts with",
        "SUID" : 991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "990",
        "source" : "162",
        "target" : "305",
        "EdgeBetweenness" : 632.0,
        "shared_name" : "SolShock (interacts with) LongBeachFresh",
        "shared_interaction" : "interacts with",
        "name" : "SolShock (interacts with) LongBeachFresh",
        "interaction" : "interacts with",
        "SUID" : 990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "source" : "148",
        "target" : "481",
        "EdgeBetweenness" : 2550.0,
        "shared_name" : "bhusak (interacts with) LBCityCollege",
        "shared_interaction" : "interacts with",
        "name" : "bhusak (interacts with) LBCityCollege",
        "interaction" : "interacts with",
        "SUID" : 989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "988",
        "source" : "139",
        "target" : "163",
        "EdgeBetweenness" : 565.0,
        "shared_name" : "drnicolaecrisan (interacts with) jaimelandmanuci",
        "shared_interaction" : "interacts with",
        "name" : "drnicolaecrisan (interacts with) jaimelandmanuci",
        "interaction" : "interacts with",
        "SUID" : 988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "964",
        "source" : "111",
        "target" : "236",
        "EdgeBetweenness" : 115.0,
        "shared_name" : "BNUEric (interacts with) UCIEnglish",
        "shared_interaction" : "interacts with",
        "name" : "BNUEric (interacts with) UCIEnglish",
        "interaction" : "interacts with",
        "SUID" : 964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "source" : "108",
        "target" : "107",
        "EdgeBetweenness" : 910.0,
        "shared_name" : "HarrisStuart_LA (interacts with) csuf",
        "shared_interaction" : "interacts with",
        "name" : "HarrisStuart_LA (interacts with) csuf",
        "interaction" : "interacts with",
        "SUID" : 963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "962",
        "source" : "107",
        "target" : "106",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) Woaah_Caat",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) Woaah_Caat",
        "interaction" : "interacts with",
        "SUID" : 962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "source" : "107",
        "target" : "105",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) iortiz254",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) iortiz254",
        "interaction" : "interacts with",
        "SUID" : 961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "960",
        "source" : "107",
        "target" : "104",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) jayce2fast",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) jayce2fast",
        "interaction" : "interacts with",
        "SUID" : 960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "107",
        "target" : "103",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) crystalbibi_14",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) crystalbibi_14",
        "interaction" : "interacts with",
        "SUID" : 959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "958",
        "source" : "107",
        "target" : "102",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) CallmeMahi9999",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) CallmeMahi9999",
        "interaction" : "interacts with",
        "SUID" : 958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "source" : "107",
        "target" : "101",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) Maririaah",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) Maririaah",
        "interaction" : "interacts with",
        "SUID" : 957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "956",
        "source" : "107",
        "target" : "100",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) Tuffy_The_Titan",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) Tuffy_The_Titan",
        "interaction" : "interacts with",
        "SUID" : 956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "source" : "107",
        "target" : "99",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) morenaa__98",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) morenaa__98",
        "interaction" : "interacts with",
        "SUID" : 955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "954",
        "source" : "107",
        "target" : "98",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) KatieSavant",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) KatieSavant",
        "interaction" : "interacts with",
        "SUID" : 954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "107",
        "target" : "97",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) ElizabethMonto",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) ElizabethMonto",
        "interaction" : "interacts with",
        "SUID" : 953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "952",
        "source" : "107",
        "target" : "96",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) _cgilly",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) _cgilly",
        "interaction" : "interacts with",
        "SUID" : 952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "107",
        "target" : "95",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) tgi_Jacob127",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) tgi_Jacob127",
        "interaction" : "interacts with",
        "SUID" : 951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "950",
        "source" : "107",
        "target" : "94",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) johana95",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) johana95",
        "interaction" : "interacts with",
        "SUID" : 950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "source" : "107",
        "target" : "93",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) ellainmaee",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) ellainmaee",
        "interaction" : "interacts with",
        "SUID" : 949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "948",
        "source" : "107",
        "target" : "92",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) DrOseguera",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) DrOseguera",
        "interaction" : "interacts with",
        "SUID" : 948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "107",
        "target" : "91",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) JinalSh91320289",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) JinalSh91320289",
        "interaction" : "interacts with",
        "SUID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "946",
        "source" : "107",
        "target" : "90",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) CSUFGeology",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) CSUFGeology",
        "interaction" : "interacts with",
        "SUID" : 946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "source" : "107",
        "target" : "553",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) sea_science_sam",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) sea_science_sam",
        "interaction" : "interacts with",
        "SUID" : 945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "944",
        "source" : "107",
        "target" : "89",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) csufcnsm",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) csufcnsm",
        "interaction" : "interacts with",
        "SUID" : 944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "source" : "107",
        "target" : "88",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) adamgolub",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) adamgolub",
        "interaction" : "interacts with",
        "SUID" : 943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "942",
        "source" : "107",
        "target" : "87",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) Sp2020BioAnth",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) Sp2020BioAnth",
        "interaction" : "interacts with",
        "SUID" : 942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "source" : "107",
        "target" : "86",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) kthygld",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) kthygld",
        "interaction" : "interacts with",
        "SUID" : 941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "940",
        "source" : "107",
        "target" : "85",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) csufpd",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) csufpd",
        "interaction" : "interacts with",
        "SUID" : 940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "source" : "107",
        "target" : "84",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) CSUFPTS",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) CSUFPTS",
        "interaction" : "interacts with",
        "SUID" : 939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "source" : "107",
        "target" : "83",
        "EdgeBetweenness" : 71.0,
        "shared_name" : "csuf (interacts with) OldMacDonald",
        "shared_interaction" : "interacts with",
        "name" : "csuf (interacts with) OldMacDonald",
        "interaction" : "interacts with",
        "SUID" : 938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "source" : "73",
        "target" : "688",
        "EdgeBetweenness" : 1005.0,
        "shared_name" : "othesharon (interacts with) RepGilCisneros",
        "shared_interaction" : "interacts with",
        "name" : "othesharon (interacts with) RepGilCisneros",
        "interaction" : "interacts with",
        "SUID" : 937,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}